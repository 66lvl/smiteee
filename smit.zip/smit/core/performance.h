#pragma once
#include "../imgui/imgui.h"
#include "../ui/theme.h"
#include <chrono>
#include <array>
#include <algorithm>

// Render-thread-only CPU measurements; no UObject references, disk writes or GPU waits.
namespace Performance
{
    enum class Part { Frame, Input, State, AutoPick, Cooldowns, ESP, Aim, Map, Camera, Dagger, UI, GpuWait, Submit, Count };
    inline constexpr int Count = static_cast<int>(Part::Count);
    inline constexpr const char* Names[Count] = {"Overlay CPU total", "Controller snapshot", "Session / pending skin", "Auto Pick service", "Cooldown Hub", "ESP", "Combat", "Map", "Camera", "Auto Dagger", "Menu / watermark", "DX12 fence wait", "ImGui submission"};
    using Clock = std::chrono::steady_clock;
    inline bool enabled = false;
    inline bool showOverlay = true;
    inline std::array<double, Count> current{}, sums{}, peaks{}, average{}, maximum{};
    inline unsigned frames = 0;
    inline bool hasReport = false;
    inline auto windowStart = Clock::now();
    inline void Reset()
    {
        current = {}; sums = {}; peaks = {}; average = {}; maximum = {};
        frames = 0; hasReport = false; windowStart = Clock::now();
    }
    struct Scope
    {
        Part part; bool active; Clock::time_point start{};
        explicit Scope(Part p) : part(p), active(enabled) { if (active) start = Clock::now(); }
        ~Scope()
        {
            if (active && enabled)
                current[static_cast<int>(part)] += std::chrono::duration<double, std::milli>(Clock::now()-start).count();
        }
    };
    struct Frame
    {
        Frame() { current = {}; }
        ~Frame()
        {
            if (!enabled) return;
            ++frames;
            for (int i=0; i<Count; ++i) { sums[i] += current[i]; peaks[i] = std::max(peaks[i], current[i]); }
            const auto now = Clock::now();
            if (now-windowStart < std::chrono::seconds(1)) return;
            for (int i=0; i<Count; ++i) { average[i] = sums[i]/frames; maximum[i] = peaks[i]; }
            sums = {}; peaks = {}; frames = 0; windowStart = now; hasReport = true;
        }
    };
    template<class F> inline void Measure(Part p, F&& f) { Scope scope(p); f(); }
    inline void Controls()
    {
        UITheme::BeginCard("performance_controls",UITheme::Icon::Info,"Performance diagnostics (CPU)");
        if(UITheme::CheckboxRow("Enable timing",&enabled))Reset();
        UITheme::CheckboxRow("Show timing overlay",&showOverlay);
        UITheme::InfoText("Enable timing, close the menu, wait 5 seconds and take a screenshot. Timings are CPU time per frame, not GPU time or total game frametime.");
        UITheme::EndCard();
    }
    inline void DrawOverlay()
    {
        if (!enabled || !showOverlay) return;
        ImGui::SetNextWindowPos({16.f,80.f}, ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.94f);
        if (ImGui::Begin("ALWAYSLOSE CPU timings", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoSavedSettings))
        {
            ImGui::Text("Present callbacks: %.0f FPS (not a GPU measurement)", ImGui::GetIO().Framerate);
            if (!hasReport) ImGui::TextUnformatted("Collecting samples...");
            if (ImGui::BeginTable("timings", 3, ImGuiTableFlags_RowBg))
            {
                ImGui::TableSetupColumn("CPU section"); ImGui::TableSetupColumn("Avg ms/frame"); ImGui::TableSetupColumn("Max ms/frame"); ImGui::TableHeadersRow();
                for (int i=0;i<Count;++i)
                {
                    ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(Names[i]);
                    ImGui::TableNextColumn(); ImGui::Text("%.3f",average[i]);
                    ImGui::TableNextColumn(); ImGui::Text("%.3f",maximum[i]);
                }
                ImGui::EndTable();
            }
            ImGui::TextUnformatted("1-second windows. Sections overlap with total; do not add rows.");
            ImGui::TextUnformatted("0.000 may mean disabled or too small to display.");
        }
        ImGui::End();
    }
}
