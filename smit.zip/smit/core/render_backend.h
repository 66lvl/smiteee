#pragma once

namespace RenderBackend
{
    enum class Api
    {
        None,
        DX11,
        DX12
    };

    Api PromptOnInject();
    void SetSelected(Api api);
    Api GetSelected();
}
