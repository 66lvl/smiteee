#include "hooks.h"
#include "renderer.h"
#include "menu_diagnostics.h"
#include "render_backend.h"
#include "../ui/menu.h"
#include <MinHook.h>
#include <d3d11.h>
#include <d3d12.h>
#include <dxgi1_4.h>
#include <wrl/client.h>
#include <cstdio>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")

namespace Hooks
{
    std::function<void()>  OnPresent;
    ID3D12Device*          g_Device        = nullptr;
    ID3D12CommandQueue*    g_CommandQueue  = nullptr;
    ID3D11Device*          g_Device11      = nullptr;
    ID3D11DeviceContext*   g_Context11     = nullptr;
    IDXGISwapChain*        g_SwapChain     = nullptr;
    HWND                   g_hWnd          = nullptr;
    UINT                   g_BufferCount   = 0;
    size_t                 g_CommandQueueOffset = 0;

    using Present_t   = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT);
    static Present_t   oPresent   = nullptr;
    using Present1_t = HRESULT(WINAPI*)(IDXGISwapChain1*,UINT,UINT,const DXGI_PRESENT_PARAMETERS*);
    static Present1_t oPresent1 = nullptr;
    static void* g_Present1Target = nullptr;
    static bool  g_RendererReady = false;
    static bool  g_MismatchWarned = false;

    using GetRawInputData_t = UINT(WINAPI*)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
    using GetRawInputBuffer_t = UINT(WINAPI*)(PRAWINPUT, PUINT, UINT);
    static GetRawInputData_t   oGetRawInputData   = nullptr;
    static GetRawInputBuffer_t oGetRawInputBuffer = nullptr;

    static void SanitizeRawMouse(RAWINPUT& raw)
    {
        if (raw.header.dwType != RIM_TYPEMOUSE)
            return;

        raw.data.mouse.lLastX     = 0;
        raw.data.mouse.lLastY     = 0;
        raw.data.mouse.usButtonFlags = 0;
        raw.data.mouse.usButtonData  = 0;
    }

    static UINT WINAPI hkGetRawInputData(HRAWINPUT hRawInput, UINT uiCommand, LPVOID pData,
                                         PUINT pcbSize, UINT cbSizeHeader)
    {
        const UINT ret = oGetRawInputData(hRawInput, uiCommand, pData, pcbSize, cbSizeHeader);
        if (Menu::WantsInput() && ret != static_cast<UINT>(-1) &&
            uiCommand == RID_INPUT && pData)
        {
            SanitizeRawMouse(*static_cast<RAWINPUT*>(pData));
        }
        return ret;
    }

    static UINT WINAPI hkGetRawInputBuffer(PRAWINPUT pData, PUINT pcbSize, UINT cbSizeHeader)
    {
        const UINT ret = oGetRawInputBuffer(pData, pcbSize, cbSizeHeader);
        if (!Menu::WantsInput() || ret == static_cast<UINT>(-1) || ret == 0 || !pData)
            return ret;

        for (UINT i = 0; i < ret; ++i)
            SanitizeRawMouse(pData[i]);
        return ret;
    }

    static void InstallInputHooks()
    {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (!user32)
            return;

        void* pData = reinterpret_cast<void*>(GetProcAddress(user32, "GetRawInputData"));
        if (pData &&
            MH_CreateHook(pData, &hkGetRawInputData,
                          reinterpret_cast<void**>(&oGetRawInputData)) == MH_OK)
        {
            MH_EnableHook(pData);
        }

        void* pBuffer = reinterpret_cast<void*>(GetProcAddress(user32, "GetRawInputBuffer"));
        if (pBuffer &&
            MH_CreateHook(pBuffer, &hkGetRawInputBuffer,
                          reinterpret_cast<void**>(&oGetRawInputBuffer)) == MH_OK)
        {
            MH_EnableHook(pBuffer);
        }
    }

    // ---------------------------------------------------------------
    //  Present hook — called every frame on the render thread.
    //  First call: capture swapchain + hwnd, init renderer.
    //  Every call: run the render callback.
    // ---------------------------------------------------------------
    static bool TryCaptureDx11Device(IDXGISwapChain* pSwap)
    {
        Microsoft::WRL::ComPtr<ID3D11Device> device;
        if (FAILED(pSwap->GetDevice(IID_PPV_ARGS(&device))) || !device)
            return false;

        device->GetImmediateContext(&g_Context11);
        if (!g_Context11)
            return false;

        g_Device11 = device.Detach();
        printf("[*] hkPresent: Captured D3D11 Device: 0x%p\n", g_Device11);
        return true;
    }

    static bool TryCaptureDx12Device(IDXGISwapChain* pSwap)
    {
        HRESULT hr = pSwap->GetDevice(IID_PPV_ARGS(&g_Device));
        if (FAILED(hr) || !g_Device)
        {
            printf("[-] hkPresent: Failed to retrieve D3D12 Device! HRESULT: 0x%X\n", hr);
            return false;
        }

        printf("[*] hkPresent: Retrieved D3D12 Device: 0x%p\n", g_Device);

        if (g_CommandQueueOffset != 0)
        {
            const uintptr_t base = reinterpret_cast<uintptr_t>(pSwap);
            ID3D12CommandQueue** ppQueue =
                reinterpret_cast<ID3D12CommandQueue**>(base + g_CommandQueueOffset);
            if (ppQueue && *ppQueue)
            {
                g_CommandQueue = *ppQueue;
                printf("[*] hkPresent: Resolved CommandQueue: 0x%p\n", g_CommandQueue);
            }
            else
            {
                printf("[-] hkPresent: Failed to resolve CommandQueue from SwapChain!\n");
            }
        }

        return g_Device && g_CommandQueue;
    }

    static void ShowBackendMismatch(RenderBackend::Api expected)
    {
        if (g_MismatchWarned)
            return;
        g_MismatchWarned = true;
        const wchar_t* expectedText =
            expected == RenderBackend::Api::DX11 ? L"DirectX 11" : L"DirectX 12";
        wchar_t msg[512]{};
        swprintf_s(msg,
                   L"You selected %s at inject, but the game swap chain looks like the other mode.\r\n\r\n"
                   L"Change the in-game DirectX setting or re-inject and pick the matching option.",
                   expectedText);
        MessageBoxW(nullptr, msg, L"Trainer — DirectX mismatch", MB_TOPMOST | MB_ICONWARNING | MB_OK);
    }

    static void RenderSafe()
    {
        __try {
            Renderer::Render();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) { RenderSafety::Exception(GetExceptionCode()); }
    }

    static void TryInitRendererFromPresent(IDXGISwapChain* pSwap)
    {
        if (!g_SwapChain)
        {
            DXGI_SWAP_CHAIN_DESC desc{};
            pSwap->GetDesc(&desc);
            g_hWnd        = desc.OutputWindow;
            g_BufferCount = desc.BufferCount;
            if (g_BufferCount == 0)
                g_BufferCount = 2;
            g_SwapChain   = pSwap;
            printf("[*] hkPresent: Captured SwapChain: 0x%p\n", pSwap);
            printf("[*] hkPresent: HWND: 0x%p, BufferCount: %u\n", g_hWnd, g_BufferCount);
        }

        const RenderBackend::Api backend = RenderBackend::GetSelected();
        bool readyToInit = false;

        if (backend == RenderBackend::Api::DX11)
        {
            if (!g_Device11 && !TryCaptureDx11Device(pSwap))
                ShowBackendMismatch(RenderBackend::Api::DX11);
            readyToInit = g_Device11 && g_Context11 && g_SwapChain && g_hWnd;
        }
        else if (backend == RenderBackend::Api::DX12)
        {
            if (!g_Device || !g_CommandQueue)
            {
                ID3D11Device* probe11 = nullptr;
                if (SUCCEEDED(pSwap->GetDevice(IID_PPV_ARGS(&probe11))) && probe11)
                {
                    probe11->Release();
                    ShowBackendMismatch(RenderBackend::Api::DX12);
                }
                else
                {
                    TryCaptureDx12Device(pSwap);
                }
            }
            readyToInit = g_Device && g_CommandQueue && g_SwapChain && g_hWnd;
        }

        if (readyToInit)
        {
            printf("[*] hkPresent: Initializing renderer...\n");
            if (Renderer::Initialize())
            {
                g_RendererReady = true;
                printf("[+] hkPresent: Renderer initialized.\n");
            }
            else
            {
                printf("[-] hkPresent: Renderer::Initialize() failed!\n");
            }
        }
    }

    static void RenderFromPresentation(IDXGISwapChain* pSwap, UINT flags)
    {
        // Test-only calls must not capture a swapchain or run the overlay.
        if (flags & DXGI_PRESENT_TEST) return;

        if (!g_RendererReady && !RenderSafety::halted.load()) {
            TryInitRendererFromPresent(pSwap);
        }
        if (g_RendererReady && pSwap==g_SwapChain && !RenderSafety::halted.load()) {
            RenderSafe();
        }
    }

    static HRESULT WINAPI hkPresent(IDXGISwapChain* pSwap, UINT sync, UINT flags)
    {

        RenderSafety::PresentScope scope;
        if (scope.outer) {
            RenderFromPresentation(pSwap,flags);
        }
        const HRESULT result = oPresent(pSwap,sync,flags);
        return result;
    }

    static HRESULT WINAPI hkPresent1(IDXGISwapChain1* pSwap, UINT sync, UINT flags, const DXGI_PRESENT_PARAMETERS* parameters)
    {

        RenderSafety::PresentScope scope;
        if (scope.outer) {
            RenderFromPresentation(static_cast<IDXGISwapChain*>(pSwap),flags);
        }
        // All original dirty/scroll parameters and flags are forwarded unchanged.
        const HRESULT result = oPresent1(pSwap,sync,flags,parameters);
        return result;
    }

    // ---------------------------------------------------------------
    //  Read Present vtable slot 8 from a dummy swapchain.
    //  Uses a separate temporary device so we don't pollute g_Device.
    //  Scans the dummy swapchain to find the offset of its CommandQueue pointer.
    // ---------------------------------------------------------------
    static void* GetPresentVtable()
    {
        Microsoft::WRL::ComPtr<ID3D12Device> tmpDev;
        if (FAILED(D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0,
                                      IID_PPV_ARGS(&tmpDev))))
            return nullptr;

        Microsoft::WRL::ComPtr<ID3D12CommandQueue> tmpQueue;
        D3D12_COMMAND_QUEUE_DESC qd{};
        qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        if (FAILED(tmpDev->CreateCommandQueue(&qd, IID_PPV_ARGS(&tmpQueue))))
            return nullptr;

        Microsoft::WRL::ComPtr<IDXGIFactory4> factory;
        if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory))))
            return nullptr;

        HWND hwnd = CreateWindowExW(0, L"STATIC", L"tmp",
                                    WS_POPUP, 0, 0, 8, 8,
                                    nullptr, nullptr, nullptr, nullptr);
        if (!hwnd) return nullptr;

        DXGI_SWAP_CHAIN_DESC1 scd{};
        scd.BufferCount     = 2;
        scd.Width  = scd.Height = 8;
        scd.Format          = DXGI_FORMAT_R8G8B8A8_UNORM;
        scd.SwapEffect      = DXGI_SWAP_EFFECT_FLIP_DISCARD;
        scd.SampleDesc.Count= 1;

        Microsoft::WRL::ComPtr<IDXGISwapChain1> sc;
        HRESULT hr = factory->CreateSwapChainForHwnd(
            tmpQueue.Get(), hwnd, &scd, nullptr, nullptr, &sc);
        DestroyWindow(hwnd);
        if (FAILED(hr)) return nullptr;

        // Slot 8 = IDXGISwapChain::Present
        void* pPresent = (*reinterpret_cast<void***>(sc.Get()))[8];
        // IDXGISwapChain1::Present1 is vtable slot 22 (SDK interface order).
        g_Present1Target = (*reinterpret_cast<void***>(sc.Get()))[22];

        // Scan dummy swapchain to locate the command queue pointer offset
        Microsoft::WRL::ComPtr<IDXGISwapChain3> sc3;
        if (SUCCEEDED(sc->QueryInterface(IID_PPV_ARGS(&sc3))))
        {
            const uintptr_t swapAddr = reinterpret_cast<uintptr_t>(sc3.Get());
            const uintptr_t queueAddr = reinterpret_cast<uintptr_t>(tmpQueue.Get());
            const size_t scanSize = 0x200; // scan first 512 bytes
            for (size_t off = 0; off + sizeof(void*) <= scanSize; off += sizeof(void*))
            {
                uintptr_t candidate = *(uintptr_t*)(swapAddr + off);
                if (candidate == queueAddr)
                {
                    g_CommandQueueOffset = off;
                    printf("[+] GetPresentVtable: Scanned CommandQueue offset in SwapChain: 0x%zX\n", off);
                    break;
                }
            }
        }

        return pPresent;
    }

    // ---------------------------------------------------------------
    //  Install hooks
    // ---------------------------------------------------------------
    bool Initialize()
    {
        if (MH_Initialize() != MH_OK)
        {
            printf("[-] Hooks::Initialize: MH_Initialize failed!\n");
            return false;
        }

        void* pPresent = GetPresentVtable();
        if (!pPresent)
        {
            printf("[-] Hooks::Initialize: Failed to retrieve Present vtable pointer!\n");
            return false;
        }
        printf("[+] Hooks::Initialize: Found Present at 0x%p\n", pPresent);

        if (MH_CreateHook(pPresent, &hkPresent,
                          reinterpret_cast<void**>(&oPresent)) != MH_OK)
        {
            printf("[-] Hooks::Initialize: Failed to create Present hook!\n");
            return false;
        }

        if (!g_Present1Target || g_Present1Target==pPresent) {
            std::printf("[-] Present1 target missing/aliased; initialization stopped\n");
            MH_RemoveHook(pPresent); MH_Uninitialize(); return false;
        }
        const MH_STATUS create1 = MH_CreateHook(g_Present1Target,&hkPresent1,reinterpret_cast<void**>(&oPresent1));
        if (create1 != MH_OK) {
            std::printf("[-] Present1 hook create failed status=%d\n",static_cast<int>(create1));
            MH_RemoveHook(pPresent); MH_Uninitialize(); return false;
        }
        std::printf("[+] Present1 target=%p; enabling both hooks\n",g_Present1Target);
        const MH_STATUS queue0 = MH_QueueEnableHook(pPresent);
        const MH_STATUS queue1 = MH_QueueEnableHook(g_Present1Target);
        bool ok = queue0==MH_OK && queue1==MH_OK && MH_ApplyQueued()==MH_OK;
        if (!ok) {
            MH_DisableHook(MH_ALL_HOOKS); MH_Uninitialize();
        }
        if (ok)
        {
            InstallInputHooks();
            printf("[+] Hooks::Initialize: MinHook hooks enabled successfully.\n");
        }
        else
        {
            printf("[-] Hooks::Initialize: Failed to enable MinHook hooks!\n");
        }
        return ok;
    }

    void Shutdown()
    {
        MH_DisableHook(MH_ALL_HOOKS);
        MH_Uninitialize();
        printf("[+] Hooks::Shutdown: Hooks disabled and uninitialized.\n");
    }
}
