#pragma once

// Lean SDK include header: replaces monolithic CppSDK/SDK.hpp (6566 files)
// with only the packages actually used across the project.

#include "../CppSDK/SDK/Basic.hpp"
#include "../CppSDK/SDK/CoreUObject_classes.hpp"
#include "../CppSDK/SDK/Engine_classes.hpp"
#include "../CppSDK/SDK/GameplayAbilities_classes.hpp"
#include "../CppSDK/SDK/BanPickDraftCommon_classes.hpp"
#include "../CppSDK/SDK/Hemingway_classes.hpp"
#include "../CppSDK/SDK/HemingwayUI_classes.hpp"

// Blueprint classes referenced across features
#include "../CppSDK/SDK/BP_Aladdin_ArenaManagerSingleton_classes.hpp"
#include "../CppSDK/SDK/BP_BattleStandard_Pickup_classes.hpp"
#include "../CppSDK/SDK/BP_Interactable_classes.hpp"
#include "../CppSDK/SDK/BP_Interactable_TargetDummy_classes.hpp"
#include "../CppSDK/SDK/BP_Interactable_TowerPortals_classes.hpp"
#include "../CppSDK/SDK/BP_JoustGameState_classes.hpp"
#include "../CppSDK/SDK/BP_InteractableComponent_classes.hpp"
