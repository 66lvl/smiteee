#pragma once
#include <string>
#include <unordered_map>
#include "smite_sdk.h"

namespace PawnFilter
{
    struct Classification
    {
        bool isMinion       = false;
        bool isTower        = false;
        bool isPhoenix      = false;
        bool isTitan        = false;
        bool isBuff         = false;
        bool isAbilityDeployable = false;
        bool isNPC          = false;
        bool isCharacter    = false;
        bool isHero         = false;
        bool isPlayer       = false;
        bool skipUnknownNpc = false;
        std::string baseName;
    };

    Classification Classify(SDK::AActor* actor);
    bool IsAlivePawn(SDK::AActor* actor);
    bool IsHeroPawn(SDK::AActor* actor, Classification* out = nullptr);

    enum class EspCategory : int
    {
        Skip = 0,
        EnemyGod,
        AllyGod,
        Minion,
        Jungle,
        Structure
    };

    EspCategory EspCategoryFor(SDK::AActor* actor,
                               SDK::AActor* localActor,
                               bool showEnemyGods,
                               bool showAllyGods,
                               bool showMinions,
                               bool showJungle,
                               bool showStructures);

    void ClearSessionCaches();
}
