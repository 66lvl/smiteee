#include "pawn_filter.h"
#include "sdk_helpers.h"
#include <cctype>

namespace PawnFilter
{
    static std::unordered_map<std::string, bool> s_unknownNpcVisibility;

    static std::string UpperName(SDK::AActor* actor)
    {
        return Helpers::SafeGetActorName(actor);
    }

    static std::string StripNumericSuffix(const std::string& nameUpper)
    {
        std::string baseName = nameUpper;
        size_t lastUnd = baseName.find_last_of('_');
        if (lastUnd != std::string::npos && lastUnd + 1 < baseName.size())
        {
            bool allDigits = true;
            for (size_t i = lastUnd + 1; i < baseName.size(); ++i)
            {
                if (baseName[i] < '0' || baseName[i] > '9')
                {
                    allDigits = false;
                    break;
                }
            }
            if (allDigits)
                baseName = baseName.substr(0, lastUnd);
        }
        return baseName;
    }

    static bool HasAbilityDeployablePattern(const std::string& nameUpper)
    {
        const char* patterns[] = { "_A01_", "_A02_", "_A03_", "_A04_" };
        for (const char* pat : patterns)
        {
            if (nameUpper.find(pat) != std::string::npos)
                return true;
        }
        const char* suffixes[] = { "_A01", "_A02", "_A03", "_A04" };
        for (const char* suf : suffixes)
        {
            size_t pos = nameUpper.rfind(suf);
            if (pos != std::string::npos && (pos + 4 == nameUpper.size()))
                return true;
        }
        return false;
    }

    Classification Classify(SDK::AActor* actor)
    {
        Classification c{};
        if (!actor) return c;

        std::string nameUpper = UpperName(actor);
        c.baseName = StripNumericSuffix(nameUpper);

        c.isNPC = (nameUpper.find("NPC") != std::string::npos);
        c.isMinion = (nameUpper.find("MINION") != std::string::npos);
        c.isTower = (nameUpper.find("TOWER") != std::string::npos ||
                     nameUpper.find("TURRET") != std::string::npos);
        c.isPhoenix = (nameUpper.find("PHOENIX") != std::string::npos);
        c.isTitan = (nameUpper.find("TITAN") != std::string::npos ||
                     nameUpper.find("TITIAN") != std::string::npos);

        bool isBuffName = (nameUpper.find("BUFF") != std::string::npos ||
                           nameUpper.find("JUNGLE") != std::string::npos ||
                           nameUpper.find("CAMP") != std::string::npos);
        if (nameUpper.find("FURY") != std::string::npos ||
            nameUpper.find("GIANT") != std::string::npos ||
            nameUpper.find("MANCER") != std::string::npos ||
            nameUpper.find("APOPHIS") != std::string::npos)
        {
            isBuffName = true;
        }

        c.isAbilityDeployable = HasAbilityDeployablePattern(nameUpper);
        c.isBuff = isBuffName;

        if (c.isNPC &&
            !(c.isMinion || c.isTower || c.isPhoenix || c.isTitan || c.isBuff || c.isAbilityDeployable))
        {
            auto it = s_unknownNpcVisibility.find(c.baseName);
            if (it == s_unknownNpcVisibility.end())
            {
                s_unknownNpcVisibility[c.baseName] = true;
                it = s_unknownNpcVisibility.find(c.baseName);
            }
            if (it->second)
                c.isBuff = true;
            else
                c.skipUnknownNpc = true;
        }

        if (c.isNPC && !(c.isMinion || c.isTower || c.isPhoenix || c.isTitan || c.isBuff))
            c.isBuff = true;

        if (c.isAbilityDeployable)
            c.isBuff = true;

        c.isCharacter = Helpers::SafeIsA(actor, SDK::ACharacter::StaticClass());
        c.isHero = c.isCharacter &&
                   !(c.isMinion || c.isTower || c.isPhoenix || c.isTitan || c.isBuff);
        c.isPlayer = !c.isNPC;
        return c;
    }

    bool IsHeroPawn(SDK::AActor* actor, Classification* out)
    {
        if (!actor || !IsAlivePawn(actor))
            return false;

        Classification c = Classify(actor);
        if (out) *out = c;
        if (c.skipUnknownNpc)
            return false;
        return c.isHero;
    }

    bool IsAlivePawn(SDK::AActor* actor)
    {
        __try {
            if (!actor) return false;
            if (actor->IsA(SDK::AHWCharacter_Base::StaticClass()))
            {
                auto* ch = static_cast<SDK::AHWCharacter_Base*>(actor);
                if (ch->IsDead() || ch->GetHealth() <= 0.f)
                    return false;
            }
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }

    EspCategory EspCategoryFor(SDK::AActor* actor,
                               SDK::AActor* localActor,
                               bool showEnemyGods,
                               bool showAllyGods,
                               bool showMinions,
                               bool showJungle,
                               bool showStructures)
    {
        if (!actor || !IsAlivePawn(actor))
            return EspCategory::Skip;

        Classification c = Classify(actor);
        if (c.skipUnknownNpc)
            return EspCategory::Skip;

        if (Helpers::SafeIsA(actor, SDK::AHWCharacter_Base::StaticClass()))
        {
            auto* ch = static_cast<SDK::AHWCharacter_Base*>(actor);
            if (ch->IsAMinion())
            {
                if (showMinions)
                    return EspCategory::Minion;
                return EspCategory::Skip;
            }
            if (showJungle && (ch->IsAJungleMonster() || ch->IsAJungleBoss()))
                return EspCategory::Jungle;
        }

        if (c.isHero)
        {
            SDK::ETeamAttitude att = Helpers::GetTeamAttitude(localActor, actor);
            if (att == SDK::ETeamAttitude::Hostile && showEnemyGods)
                return EspCategory::EnemyGod;
            if (att == SDK::ETeamAttitude::Friendly && showAllyGods)
                return EspCategory::AllyGod;
            return EspCategory::Skip;
        }

        if (c.isMinion && showMinions)
            return EspCategory::Minion;

        if (c.isBuff && showJungle)
            return EspCategory::Jungle;

        if ((c.isTower || c.isPhoenix || c.isTitan) && showStructures)
            return EspCategory::Structure;

        return EspCategory::Skip;
    }

    void ClearSessionCaches()
    {
        s_unknownNpcVisibility.clear();
    }
}
