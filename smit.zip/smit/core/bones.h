#pragma once

#include <string>
#include "../imgui/imgui.h"
#include "smite_sdk.h"

namespace Bones
{
    bool IsImportantBone(const std::string& boneName);
    bool ComputeBoundingBox(SDK::AHWCharacter_Base* ch,
                            float& bx, float& by, float& bw, float& bh);
    void DrawFilteredSkeleton(ImDrawList* dl,
                              SDK::AHWCharacter_Base* ch,
                              ImU32 lineColor);
    SDK::FVector GetAimPoint(SDK::AHWCharacter_Base* ch, int aimBone);
}
