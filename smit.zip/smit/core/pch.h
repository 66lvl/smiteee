#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <Windows.h>
#include <d3d11.h>
#include <d3d12.h>
#include <dxgi.h>
#include <string>
#include <string_view>
#include <vector>
#include <chrono>
#include <memory>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cfloat>

#include "imgui.h"
#include "smite_sdk.h"
