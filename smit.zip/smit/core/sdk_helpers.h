#pragma once
#include <Windows.h>
#include <cstdint>
#include <cfloat>
#include <cmath>
#include <string>
#include <vector>
#include "smite_sdk.h"
#include "../imgui/imgui.h"

namespace Helpers
{
    // ---------------------------------------------------------------
    //  Safe pointer access — returns nullptr / 0 / empty on failure
    // ---------------------------------------------------------------

    inline bool IsValidPtr(const void* ptr)
    {
        return ptr != nullptr &&
            !IsBadReadPtr(ptr, sizeof(uintptr_t));
    }

    inline bool SafeIsA(SDK::UObject* obj, SDK::UClass* cls)
    {
        __try {
            if (!obj || !cls || !IsValidPtr(obj) || !IsValidPtr(cls))
                return false;
            return obj->IsA(cls);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }

    inline SDK::APawn* SafeGetPawnFromPC(SDK::APlayerController* pc)
    {
        SDK::APawn* pawn = nullptr;
        __try {
            pawn = pc ? pc->K2_GetPawn() : nullptr;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return pawn;
    }

    template<typename T>
    inline T SafeRead(const T* ptr, T fallback = T{})
    {
        __try {
            if (IsValidPtr(ptr))
                return *ptr;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return fallback;
    }

    // ---------------------------------------------------------------
    //  Get UWorld → GWorld
    // ---------------------------------------------------------------
    inline SDK::UWorld* GetWorld()
    {
        __try {
            return SDK::UWorld::GetWorld();
        } __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    inline float GetServerWorldTimeSeconds()
    {
        __try {
            auto* world = GetWorld();
            if (!world || !world->GameState || !Helpers::IsValidPtr(world->GameState))
                return 0.f;
            return static_cast<float>(world->GameState->GetServerWorldTimeSeconds());
        } __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    inline float GetWorldTimeSeconds()
    {
        __try {
            auto* world = GetWorld();
            if (!world) return 0.f;
            float t = static_cast<float>(SDK::UGameplayStatics::GetTimeSeconds(world));
            if (t > 0.f)
                return t;
            return GetServerWorldTimeSeconds();
        } __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    // ---------------------------------------------------------------
    //  Get local PlayerController
    // ---------------------------------------------------------------
    inline SDK::APlayerController* GetLocalPC()
    {
        __try {
            auto* world = GetWorld();
            if (!world) return nullptr;
            return world->OwningGameInstance ? world->OwningGameInstance->LocalPlayers.IsValidIndex(0)
                ? world->OwningGameInstance->LocalPlayers[0]->PlayerController : nullptr : nullptr;
        } __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ---------------------------------------------------------------
    //  Get local SMITE PlayerController
    // ---------------------------------------------------------------
    inline SDK::AHWPlayerController* GetHWPC()
    {
        return static_cast<SDK::AHWPlayerController*>(GetLocalPC());
    }

    // ---------------------------------------------------------------
    //  Get local pawn as character
    // ---------------------------------------------------------------
    inline SDK::AHWCharacter_Base* GetLocalChar()
    {
        __try {
            auto* pc = GetHWPC();
            if (!pc) return nullptr;
            auto* pawn = pc->K2_GetPawn();
            if (!pawn) return nullptr;
            if (!pawn->IsA(SDK::AHWCharacter_Base::StaticClass())) return nullptr;
            return static_cast<SDK::AHWCharacter_Base*>(pawn);
        } __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ---------------------------------------------------------------
    //  World-to-Screen projection (viewport-relative = overlay coords)
    // ---------------------------------------------------------------
    inline bool W2S(const SDK::FVector& worldPos, SDK::FVector2D& screenPos,
                    bool viewportRelative = true)
    {
        __try {
            auto* pc = GetLocalPC();
            if (!pc) return false;
            return pc->ProjectWorldLocationToScreen(worldPos, &screenPos, viewportRelative);
        } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    inline ImVec2 GetDisplayCenter()
    {
        ImVec2 ds = ImGui::GetIO().DisplaySize;
        return { ds.x * 0.5f, ds.y * 0.5f };
    }

    inline float GetYawDelta(float yawFrom, float yawTo)
    {
        float delta = yawTo - yawFrom;
        while (delta > 180.f) delta -= 360.f;
        while (delta < -180.f) delta += 360.f;
        return delta;
    }

    inline float SolveInterceptTime(const SDK::FVector& relPos,
                                    const SDK::FVector& relVel,
                                    float projSpeed)
    {
        float s = projSpeed;
        float a = relVel.X * relVel.X + relVel.Y * relVel.Y + relVel.Z * relVel.Z - s * s;
        float b = 2.f * (relPos.X * relVel.X + relPos.Y * relVel.Y + relPos.Z * relVel.Z);
        float c = relPos.X * relPos.X + relPos.Y * relPos.Y + relPos.Z * relPos.Z;
        if (fabsf(a) < 1e-6f)
        {
            if (c < 1e-6f) return 0.f;
            return sqrtf(c) / s;
        }
        float disc = b * b - 4.f * a * c;
        if (disc < 0.f)
        {
            if (c < 1e-6f) return 0.f;
            return sqrtf(c) / s;
        }
        float sqrtDisc = sqrtf(disc);
        float t0 = (-b - sqrtDisc) / (2.f * a);
        float t1 = (-b + sqrtDisc) / (2.f * a);
        float t = -1.f;
        if (t0 > 0.f && t1 > 0.f)
            t = (t0 < t1 ? t0 : t1);
        else if (t0 > 0.f)
            t = t0;
        else if (t1 > 0.f)
            t = t1;
        if (t < 0.f)
        {
            if (c < 1e-6f) return 0.f;
            return sqrtf(c) / s;
        }
        return t;
    }

    inline SDK::FVector GetPawnVelocity(SDK::APawn* pawn)
    {
        __try {
            return pawn ? pawn->GetVelocity() : SDK::FVector{};
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return {};
    }

    inline SDK::ETeamAttitude GetTeamAttitude(SDK::AActor* me, SDK::AActor* other)
    {
        __try {
            if (!me || !other) return SDK::ETeamAttitude::Neutral;
            return SDK::UHWLibrary_Core::GetTeamAttitudeTowards(me, other);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return SDK::ETeamAttitude::Neutral;
    }

    inline bool IsHostileToLocal(SDK::AActor* localActor, SDK::AActor* other)
    {
        return GetTeamAttitude(localActor, other) == SDK::ETeamAttitude::Hostile;
    }

    std::vector<SDK::APawn*> GetAllPawns();
    void GatherLevelActors(std::vector<SDK::AActor*>& result);
    std::vector<SDK::AActor*> GetAllLevelActors();

    inline bool IsGodCharacter(SDK::AHWCharacter_Base* ch)
    {
        __try {
            if (!ch || !ch->IsAGod()) return false;
            if (ch->IsFamiliar()) return false;
            if (ch->IsAMinion()) return false;
            if (ch->IsAJungleMonster() || ch->IsAJungleBoss()) return false;
            if (ch->IsAStructure() || ch->IsATitan()) return false;
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }

    // ---------------------------------------------------------------
    //  Get an actor's health/max health safely
    // ---------------------------------------------------------------
    inline float GetHealth(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->GetHealth() : 0.f; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    inline float GetMaxHealth(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->GetMaxHealth() : 0.f; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    inline float GetMana(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->GetMana() : 0.f; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    inline float GetMaxMana(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->GetMaxMana() : 0.f; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    // ---------------------------------------------------------------
    //  Get character level
    // ---------------------------------------------------------------
    inline float GetLevel(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->GetCharacterLevel() : 0.f; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return 0.f; }
    }

    // ---------------------------------------------------------------
    //  Is dead
    // ---------------------------------------------------------------
    inline bool IsDead(SDK::AHWCharacter_Base* ch)
    {
        __try { return ch ? ch->IsDead() : true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return true; }
    }

    // ---------------------------------------------------------------
    //  Get visibility component from character
    // ---------------------------------------------------------------
    inline SDK::UHWVisibilityComponent* GetVisComp(SDK::AHWCharacter_Base* ch)
    {
        __try {
            if (!ch) return nullptr;
            auto* abilityActor = ch->GetCharacterAbilitySystemActor();
            if (!abilityActor) return nullptr;
            auto* actorComp = abilityActor->GetComponentByClass(SDK::UHWVisibilityComponent::StaticClass());
            if (!actorComp) return nullptr;
            if (!actorComp->IsA(SDK::UHWVisibilityComponent::StaticClass())) return nullptr;
            return static_cast<SDK::UHWVisibilityComponent*>(actorComp);
        } __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ---------------------------------------------------------------
    //  Get actor location safely
    // ---------------------------------------------------------------
    inline SDK::FVector GetLocation(SDK::AActor* actor)
    {
        __try {
            return actor ? actor->K2_GetActorLocation() : SDK::FVector{};
        } __except (EXCEPTION_EXECUTE_HANDLER) { return SDK::FVector{}; }
    }

    // ---------------------------------------------------------------
    //  Get velocity via character movement
    // ---------------------------------------------------------------
    inline SDK::FVector GetVelocity(SDK::ACharacter* ch)
    {
        __try {
            if (!ch) return {};
            auto* mv = ch->CharacterMovement;
            if (!mv) return {};
            return mv->Velocity;
        } __except (EXCEPTION_EXECUTE_HANDLER) { return {}; }
    }

    // ---------------------------------------------------------------
    //  Get team ID: returns 0 = order, 1 = chaos, 255 = neutral
    // ---------------------------------------------------------------
    inline uint8_t GetTeamId(SDK::AHWCharacter_Base* ch)
    {
        __try {
            if (!ch) return 255;
            return SDK::UHWLibrary_Core::GetGenericTeamId(ch).TeamId;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return 255;
    }

    inline uint8_t GetActorTeamId(SDK::AActor* actor)
    {
        __try {
            if (!actor) return 255;
            return SDK::UHWLibrary_Core::GetGenericTeamId(actor).TeamId;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return 255;
    }

    inline bool IsVisibleToLocal(SDK::AHWCharacter_Base* ch)
    {
        __try {
            auto* vis = GetVisComp(ch);
            if (!vis) return true;
            return vis->bMeshVisible;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return true;
    }

    inline bool IsWardVisibleToLocal(SDK::AHWDeployable_Ward* ward)
    {
        __try {
            if (!ward) return false;
            auto* vis = ward->VisibilityComponent;
            if (!vis) return true;
            return vis->bMeshVisible || vis->bAlwaysVisible;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return true;
    }

    // ---------------------------------------------------------------
    //  Get player display name
    // ---------------------------------------------------------------
    std::string StripBlueprintActorName(std::string name);
    std::string GetPawnDisplayName(SDK::APawn* pawn);
    std::string SafeGetActorName(SDK::AActor* actor);

    inline std::string GetPlayerName(SDK::AHWCharacter_Base* ch)
    {
        if (!ch) return "";
        std::string name = GetPawnDisplayName(static_cast<SDK::APawn*>(ch));
        if (name.empty())
            return "Bot";
        return name;
    }

    // ---------------------------------------------------------------
    //  Get the USkeletalMeshComponent for a character
    // ---------------------------------------------------------------
    inline SDK::USkeletalMeshComponent* GetMesh(SDK::AHWCharacter_Base* ch)
    {
        __try {
            if (!ch) return nullptr;
            auto* comp = ch->GetComponentByClass(SDK::USkeletalMeshComponent::StaticClass());
            if (!comp) return nullptr;
            return static_cast<SDK::USkeletalMeshComponent*>(comp);
        } __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    // ---------------------------------------------------------------
    //  Get bone world position via GetBoneMatrix (returns world space)
    // ---------------------------------------------------------------
    inline SDK::FVector GetBonePos(SDK::USkeletalMeshComponent* mesh, int32_t boneIdx)
    {
        __try {
            if (!mesh || boneIdx < 0) return {};
            const SDK::FName boneName = mesh->GetBoneName(boneIdx);
            const SDK::FTransform xform = mesh->GetBoneTransform(
                boneName, SDK::ERelativeTransformSpace::RTS_World);
            return xform.Translation;
        } __except (EXCEPTION_EXECUTE_HANDLER) { return {}; }
    }

    // ---------------------------------------------------------------
    //  Distance between two FVectors
    // ---------------------------------------------------------------
    inline float Dist3D(const SDK::FVector& a, const SDK::FVector& b)
    {
        float dx = a.X - b.X, dy = a.Y - b.Y, dz = a.Z - b.Z;
        return sqrtf(dx * dx + dy * dy + dz * dz);
    }

    // ---------------------------------------------------------------
    //  Enumerate all AHWCharacter_Base actors in the world
    // ---------------------------------------------------------------
    inline std::vector<SDK::AHWCharacter_Base*> GetAllCharacters()
    {
        std::vector<SDK::AHWCharacter_Base*> result;
        auto& objs = SDK::UObject::GObjects;
        const int32_t count = objs->Num();
        for (int32_t i = 0; i < count; i++) {
            auto* obj = objs->GetByIndex(i);
            if (!obj) continue;
            if (!obj->IsA(SDK::AHWCharacter_Base::StaticClass())) continue;
            result.push_back(static_cast<SDK::AHWCharacter_Base*>(obj));
        }
        return result;
    }

    inline std::vector<SDK::AHWDeployable_Ward*> GetAllWards()
    {
        std::vector<SDK::AHWDeployable_Ward*> result;
        auto& objs = SDK::UObject::GObjects;
        const int32_t count = objs->Num();
        for (int32_t i = 0; i < count; i++) {
            auto* obj = objs->GetByIndex(i);
            if (!obj) continue;
            if (!obj->IsA(SDK::AHWDeployable_Ward::StaticClass())) continue;
            result.push_back(static_cast<SDK::AHWDeployable_Ward*>(obj));
        }
        return result;
    }
} // namespace Helpers
