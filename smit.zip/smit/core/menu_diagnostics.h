#pragma once
// Filename retained for drop-in compatibility. Runtime error guards only.
// No diagnostic marker, key polling, timers or render-only mode.
#include <Windows.h>
#include <atomic>
#include <cstdio>

namespace RenderSafety
{
    enum class Stage : unsigned { Idle, EnterRender, GetSwapDesc, FenceWait, AllocatorReset,
        ListReset, BeginImGui, Callback, EndImGui, DrawData, CloseList, Execute, Signal, Done, Fault };
    inline std::atomic<Stage> stage{Stage::Idle};
    inline std::atomic<bool> halted{false};
    inline thread_local unsigned presentDepth = 0;
    // Present1 may internally call Present on the same thread: render once.
    struct PresentScope {
        bool outer;
        PresentScope() : outer(presentDepth++ == 0) {}
        ~PresentScope() { --presentDepth; }
        PresentScope(const PresentScope&) = delete;
        PresentScope& operator=(const PresentScope&) = delete;
    };
    inline const char* Name(Stage s)
    {
        switch (s) {
        case Stage::Idle:return "idle"; case Stage::EnterRender:return "enter-render";
        case Stage::GetSwapDesc:return "swap-desc"; case Stage::FenceWait:return "fence-wait";
        case Stage::AllocatorReset:return "allocator-reset"; case Stage::ListReset:return "list-reset";
        case Stage::BeginImGui:return "imgui-newframe"; case Stage::Callback:return "draw-callback";
        case Stage::EndImGui:return "imgui-render"; case Stage::DrawData:return "dx12-drawdata";
        case Stage::CloseList:return "close-list"; case Stage::Execute:return "execute";
        case Stage::Signal:return "signal"; case Stage::Done:return "done"; case Stage::Fault:return "fault";
        }
        return "unknown";
    }
    inline void At(Stage value) { stage.store(value); }
    inline void Exception(DWORD code)
    {
        std::printf("[-] RENDER EXCEPTION code=0x%08lX stage=%s. Overlay halted; restart game before retry.\n",
            static_cast<unsigned long>(code),Name(stage.load()));
        halted.store(true);
        std::fflush(stdout);
    }
    inline bool Check(HRESULT result, const char* operation)
    {
        if (SUCCEEDED(result)) return true;
        std::printf("[-] FAILED %s HRESULT=0x%08lX stage=%s; overlay halted.\n",
            operation,static_cast<unsigned long>(result),Name(stage.load()));
        halted.store(true);
        std::fflush(stdout);
        return false;
    }
}
