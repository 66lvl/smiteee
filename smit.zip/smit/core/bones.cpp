#include "bones.h"
#include "sdk_helpers.h"
#include <cmath>
#include <cfloat>
#include <cstring>

namespace Bones
{
    static constexpr int MAX_BONES = 512;

    static void ToLowerInPlace(char* dst, const char* src, size_t cap)
    {
        size_t i = 0;
        for (; src[i] && i + 1 < cap; ++i)
            dst[i] = static_cast<char>(::tolower(static_cast<unsigned char>(src[i])));
        dst[i] = '\0';
    }

    static bool Contains(const char* haystack, const char* needle)
    {
        return haystack && needle && std::strstr(haystack, needle) != nullptr;
    }

    bool IsImportantBone(const std::string& boneName)
    {
        char lower[128];
        ToLowerInPlace(lower, boneName.c_str(), sizeof(lower));

        static const char* keywords[] = {
            "spine", "pelvis", "neck", "head",
            "thigh", "calf", "foot", "leg",
            "arm", "hand", "upperarm", "lowerarm", "forearm", "shoulder",
            nullptr
        };
        for (int i = 0; keywords[i]; ++i)
        {
            if (Contains(lower, keywords[i]))
                return true;
        }
        return false;
    }

    static bool IsImportantBoneCstr(const char* boneName)
    {
        char lower[128];
        ToLowerInPlace(lower, boneName, sizeof(lower));

        static const char* keywords[] = {
            "spine", "pelvis", "neck", "head",
            "thigh", "calf", "foot", "leg",
            "arm", "hand", "upperarm", "lowerarm", "forearm", "shoulder",
            nullptr
        };
        for (int i = 0; keywords[i]; ++i)
        {
            if (Contains(lower, keywords[i]))
                return true;
        }
        return false;
    }

    static SDK::FVector BoneWorldPos(SDK::USkeletalMeshComponent* mesh, const SDK::FName& boneName)
    {
        __try {
            if (!Helpers::IsValidPtr(mesh)) return {};
            const SDK::FTransform t = mesh->GetBoneTransform(
                boneName, SDK::ERelativeTransformSpace::RTS_World);
            return t.Translation;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return {};
    }

    static int FindBoneIndex(const SDK::FName* names, int count, const SDK::FName& target)
    {
        for (int i = 0; i < count; ++i)
        {
            if (names[i] == target)
                return i;
        }
        return -1;
    }

    static float AimBoneScoreCstr(const char* lower, int aimBone)
    {
        if (aimBone == 0)
        {
            if (!Contains(lower, "head")) return -1.f;
            if (std::strcmp(lower, "head") == 0) return 100.f;
            if (std::strncmp(lower, "head_", 5) == 0 || Contains(lower, "_head")) return 80.f;
            return 50.f;
        }

        if (aimBone == 1)
        {
            if (Contains(lower, "chest")) return 100.f;
            if (Contains(lower, "spine_03") || Contains(lower, "spine2") || Contains(lower, "spine3"))
                return 90.f;
            if (Contains(lower, "spine_02") || Contains(lower, "spine1"))
                return 70.f;
            if (Contains(lower, "spine")) return 40.f;
            return -1.f;
        }

        if (aimBone == 2)
        {
            if (Contains(lower, "foot") || Contains(lower, "ankle")) return 50.f;
        }

        return -1.f;
    }

    static bool ActorBoundsBox(SDK::AHWCharacter_Base* ch,
                                float& bx, float& by, float& bw, float& bh)
    {
        __try {
            SDK::FVector origin, extent;
            ch->GetActorBounds(true, &origin, &extent, false);

            const SDK::FVector top    = { origin.X, origin.Y, origin.Z + extent.Z };
            const SDK::FVector bottom = { origin.X, origin.Y, origin.Z - extent.Z };

            SDK::FVector2D sTop, sBottom, sCenter;
            if (!Helpers::W2S(top, sTop))       return false;
            if (!Helpers::W2S(bottom, sBottom)) return false;
            if (!Helpers::W2S(origin, sCenter))  return false;

            const float h = fabsf(sTop.Y - sBottom.Y);
            const float w = h * 0.45f;
            bx = sCenter.X - w * 0.5f;
            by = sTop.Y;
            bw = w;
            bh = h;
            return (bh > 4.f);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return false;
    }

    static SDK::USkeletalMeshComponent* SafeGetMesh(SDK::AHWCharacter_Base* ch)
    {
        __try {
            if (!ch || !Helpers::IsValidPtr(ch))
                return nullptr;
            auto* mesh = ch->Mesh;
            if (!mesh || !Helpers::IsValidPtr(mesh))
                return nullptr;
            return mesh;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return nullptr;
    }

    static int SafeGetBoneCount(SDK::USkeletalMeshComponent* mesh)
    {
        int count = 0;
        __try {
            if (!mesh || !Helpers::IsValidPtr(mesh))
                return 0;
            count = mesh->GetNumBones();
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
        return count;
    }

    bool ComputeBoundingBox(SDK::AHWCharacter_Base* ch,
                            float& bx, float& by, float& bw, float& bh)
    {
        if (!ch || !Helpers::IsValidPtr(ch))
            return false;

        auto* mesh = SafeGetMesh(ch);
        if (mesh)
        {
            const int boneCount = SafeGetBoneCount(mesh);
            if (boneCount > 0)
            {
                float minX =  FLT_MAX, minY =  FLT_MAX;
                float maxX = -FLT_MAX, maxY = -FLT_MAX;
                bool  any  = false;

                const int limit = boneCount > MAX_BONES ? MAX_BONES : boneCount;
                for (int i = 0; i < limit; ++i)
                {
                    const SDK::FName bn = mesh->GetBoneName(i);
                    if (!IsImportantBoneCstr(bn.ToString().c_str()))
                        continue;

                    SDK::FVector2D scr;
                    if (!Helpers::W2S(BoneWorldPos(mesh, bn), scr))
                        continue;

                    any = true;
                    if (scr.X < minX) minX = scr.X;
                    if (scr.X > maxX) maxX = scr.X;
                    if (scr.Y < minY) minY = scr.Y;
                    if (scr.Y > maxY) maxY = scr.Y;
                }

                if (any && maxX > minX && maxY > minY)
                {
                    const float wPad = (maxX - minX) * 0.10f + 2.f;
                    const float hPad = (maxY - minY) * 0.05f + 2.f;
                    bx = minX - wPad;
                    by = minY - hPad;
                    bw = (maxX - minX) + wPad * 2.f;
                    bh = (maxY - minY) + hPad * 2.f;
                    return (bw > 3.f && bh > 3.f);
                }
            }
        }

        return ActorBoundsBox(ch, bx, by, bw, bh);
    }

    void DrawFilteredSkeleton(ImDrawList* dl,
                              SDK::AHWCharacter_Base* ch,
                              ImU32 lineColor)
    {
        if (!dl || !ch || !Helpers::IsValidPtr(ch))
            return;

        auto* mesh = SafeGetMesh(ch);
        if (!mesh)
            return;

        const int boneCount = SafeGetBoneCount(mesh);
        if (boneCount <= 0)
            return;

        const int limit = boneCount > MAX_BONES ? MAX_BONES : boneCount;

        SDK::FVector positions[MAX_BONES];
        SDK::FName   names[MAX_BONES];
        bool         allowed[MAX_BONES];

        for (int i = 0; i < limit; ++i)
        {
            const SDK::FName bn = mesh->GetBoneName(i);
            names[i]     = bn;
            positions[i] = BoneWorldPos(mesh, bn);
            allowed[i]   = IsImportantBoneCstr(bn.ToString().c_str());
        }

        for (int i = 0; i < limit; ++i)
        {
            if (!allowed[i])
                continue;

            const SDK::FName parent = mesh->GetParentBone(names[i]);
            if (parent.IsNone())
                continue;

            const int parentIdx = FindBoneIndex(names, limit, parent);
            if (parentIdx < 0 || !allowed[parentIdx])
                continue;

            SDK::FVector2D spChild, spParent;
            if (!Helpers::W2S(positions[i], spChild))
                continue;
            if (!Helpers::W2S(positions[parentIdx], spParent))
                continue;

            dl->AddLine(
                { static_cast<float>(spChild.X),  static_cast<float>(spChild.Y) },
                { static_cast<float>(spParent.X), static_cast<float>(spParent.Y) },
                lineColor, 1.5f);
        }
    }

    static bool TryMeshAimPoint(SDK::AHWCharacter_Base* ch, int aimBone, SDK::FVector& out)
    {
        out = {};

        auto* mesh = SafeGetMesh(ch);
        if (!mesh)
            return false;

        const int boneCount = SafeGetBoneCount(mesh);
        if (boneCount <= 0)
            return false;

        const int limit = boneCount > MAX_BONES ? MAX_BONES : boneCount;
        char lower[128];

        if (aimBone == 2)
        {
            SDK::FVector sum{};
            int count = 0;
            for (int i = 0; i < limit; ++i)
            {
                const SDK::FName bn = mesh->GetBoneName(i);
                ToLowerInPlace(lower, bn.ToString().c_str(), sizeof(lower));
                if (AimBoneScoreCstr(lower, 2) < 0.f)
                    continue;
                const SDK::FVector pos = BoneWorldPos(mesh, bn);
                sum.X += pos.X;
                sum.Y += pos.Y;
                sum.Z += pos.Z;
                ++count;
            }
            if (count <= 0)
                return false;

            out = { sum.X / count, sum.Y / count, sum.Z / count };
            return true;
        }

        float bestScore = -1.f;
        SDK::FVector bestPos{};
        bool found = false;

        for (int i = 0; i < limit; ++i)
        {
            const SDK::FName bn = mesh->GetBoneName(i);
            ToLowerInPlace(lower, bn.ToString().c_str(), sizeof(lower));
            const float score = AimBoneScoreCstr(lower, aimBone);
            if (score < 0.f)
                continue;

            const SDK::FVector pos = BoneWorldPos(mesh, bn);
            const bool better = !found ||
                score > bestScore ||
                (score == bestScore && aimBone == 0 && pos.Z > bestPos.Z);

            if (better)
            {
                bestScore = score;
                bestPos   = pos;
                found     = true;
            }
        }

        if (!found)
            return false;

        out = bestPos;
        return true;
    }

    SDK::FVector GetAimPoint(SDK::AHWCharacter_Base* ch, int aimBone)
    {
        if (!ch || !Helpers::IsValidPtr(ch))
        {
            SDK::FVector base = Helpers::GetLocation(ch);
            switch (aimBone) { case 0: base.Z += 80.f; break; case 1: base.Z += 50.f; break; case 2: base.Z -= 60.f; break; }
            return base;
        }

        SDK::FVector meshAim{};
        if (TryMeshAimPoint(ch, aimBone, meshAim))
            return meshAim;

        SDK::FVector base = Helpers::GetLocation(ch);
        switch (aimBone)
        {
        case 0: base.Z += 80.f; break;
        case 1: base.Z += 50.f; break;
        case 2: base.Z -= 60.f; break;
        }
        return base;
    }
}
