#pragma once

namespace GamepadInput
{
    enum class Button : int
    {
        LT = 0,
        RT,
        LB,
        RB,
        A,
        B,
        X,
        Y,
        LStick,
        RStick,
        DpadUp,
        DpadDown,
        DpadLeft,
        DpadRight,
        Count
    };

    enum class Backend : int
    {
        XInput = 0,
        SonyHid = 1
    };

    bool Initialize(); // Call from initialization, not the render loop.
    void Shutdown();
    void Tick(); // Nonblocking value-only snapshot.

    int  DeviceCount();
    bool IsDeviceConnected(int deviceId);
    const char* DeviceName(int deviceId);

    bool IsDeviceButtonDown(int deviceId, Button button);
    bool CaptureAnyButton(int* outDeviceId, Button* outButton);

    void FormatBindingLabel(int deviceId, Button button, char* buf, int bufSize);

    int FindDevice(Backend backend, int backendIndex);
    int ButtonCount();
    const char* ButtonLabel(Button button);
}
