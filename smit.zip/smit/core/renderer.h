#pragma once

#include "../imgui/imgui.h"

namespace Renderer
{
    struct GpuTexture
    {
        ImTextureID id     = 0;
        int         width  = 0;
        int         height = 0;
        bool        valid  = false;
    };

    extern void (*DrawCallback)();

    bool Initialize();
    bool IsReady();
    void Render();
    void Shutdown();

    GpuTexture CreateTextureRgba(const unsigned char* rgba, int width, int height);
}
