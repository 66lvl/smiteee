#include "sdk_helpers.h"
#include "game_state.h"
#include <cstring>

namespace Helpers
{
    std::string StripBlueprintActorName(std::string name)
    {
        for (int pass = 0; pass < 8; ++pass)
        {
            const std::string prev = name;

            const size_t last = name.find_last_of('_');
            if (last != std::string::npos)
                name = name.substr(0, last);

            static const char* kPrefixes[] = {
                "BP_GOD_", "ABP_GOD_", "BP_", "ABP_", "WBP_", "SK_", nullptr
            };
            for (int i = 0; kPrefixes[i]; ++i)
            {
                const char* pre = kPrefixes[i];
                const size_t len = strlen(pre);
                if (name.size() > len && _strnicmp(name.c_str(), pre, len) == 0)
                {
                    name = name.substr(len);
                    break;
                }
            }

            while (name.size() > 2 && name.compare(name.size() - 2, 2, "_C") == 0)
                name.resize(name.size() - 2);

            while (!name.empty() &&
                   (name.back() == '_' || (name.back() >= '0' && name.back() <= '9')))
            {
                name.pop_back();
            }

            if (name == prev)
                break;
        }

        return name;
    }

    static bool TryCopyObjectNameUtf8(SDK::UObject* obj, char* out, size_t outLen)
    {
        if (!obj || !out || outLen < 2)
            return false;
        out[0] = '\0';

        __try {
            if (!IsValidPtr(obj))
                return false;

            SDK::FName fname = obj->Name;
            if (fname.IsNone())
                return false;

            wchar_t wbuf[160] = {};
            UC::FString fstr(wbuf, 0, 160);
            if (!SDK::FName::AppendString)
                SDK::FName::InitInternal();

            auto appendFn = reinterpret_cast<void(*)(const SDK::FName*, UC::FString&)>(
                SDK::FName::AppendString);
            SDK::InSDKUtils::CallGameFunction(appendFn, &fname, fstr);

            const wchar_t* w = fstr.CStr();
            if (!w || !*w)
                return false;
            if (WideCharToMultiByte(CP_UTF8, 0, w, -1, out, (int)outLen, nullptr, nullptr) <= 0)
                return false;

            char* slash = strrchr(out, '/');
            if (slash && slash[1])
                memmove(out, slash + 1, strlen(slash + 1) + 1);
            return out[0] != '\0';
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}

        return false;
    }

    static bool TryCopyFStringUtf8(const UC::FString& fs, char* out, size_t outLen)
    {
        if (!out || outLen < 2)
            return false;
        out[0] = '\0';

        __try {
            const wchar_t* w = fs.CStr();
            if (!w || !*w)
                return false;
            return WideCharToMultiByte(CP_UTF8, 0, w, -1, out, (int)outLen, nullptr, nullptr) > 0;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}

        return false;
    }

    static bool TryCopyPlayerUsername(SDK::APawn* pawn, char* out, size_t outLen)
    {
        if (!pawn || !out || outLen < 2 || !IsValidPtr(pawn))
            return false;

        __try {
            SDK::AController* ctrl = pawn->Controller;
            if (!ctrl || !IsValidPtr(ctrl) || !ctrl->PlayerState || !IsValidPtr(ctrl->PlayerState))
                return false;

            const SDK::FString playerName = ctrl->PlayerState->GetPlayerName();
            if (!playerName)
                return false;

            return TryCopyFStringUtf8(playerName, out, outLen);
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}

        return false;
    }

    static bool TryCopyPawnDisplayName(SDK::APawn* pawn, char* out, size_t outLen)
    {
        if (!pawn || !out || outLen < 2)
            return false;
        out[0] = '\0';

        if (!IsValidPtr(pawn))
            return false;

        if (TryCopyObjectNameUtf8(pawn, out, outLen))
            return true;

        __try {
            if (pawn->IsA(SDK::AHWCharacter_Base::StaticClass()))
            {
                auto* ch = static_cast<SDK::AHWCharacter_Base*>(pawn);
                if (IsValidPtr(ch))
                {
                    SDK::UClass* cls = ch->Class;
                    if (cls && IsValidPtr(cls) &&
                        TryCopyObjectNameUtf8(reinterpret_cast<SDK::UObject*>(cls), out, outLen))
                        return true;
                }
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}

        if (TryCopyPlayerUsername(pawn, out, outLen))
            return true;

        return false;
    }

    std::string GetPawnDisplayName(SDK::APawn* pawn)
    {
        char raw[128]{};
        if (!TryCopyPawnDisplayName(pawn, raw, sizeof(raw)))
            return {};

        std::string result = StripBlueprintActorName(raw);
        if (result.empty())
            return result;

        for (char& c : result)
            c = (char)std::toupper((unsigned char)c);
        return result;
    }

    std::string SafeGetActorName(SDK::AActor* actor)
    {
        char raw[160]{};
        if (!TryCopyObjectNameUtf8(static_cast<SDK::UObject*>(actor), raw, sizeof(raw)))
            return {};

        for (char& c : raw)
            c = (char)std::toupper((unsigned char)c);
        return raw;
    }

    static void AppendPawnsFromLevel(SDK::ULevel* lvl,
                                     SDK::APawn* skipPawn,
                                     std::vector<SDK::APawn*>& out)
    {
        if (!lvl)
            return;

        __try {
            if (!IsValidPtr(lvl))
                return;

            const int num = lvl->Actors.Num();
            for (int i = 0; i < num; ++i)
            {
                __try {
                    if (!lvl->Actors.IsValidIndex(i))
                        continue;

                    SDK::AActor* a = lvl->Actors[i];
                    if (!a || !IsValidPtr(a) || !SafeIsA(a, SDK::APawn::StaticClass()))
                        continue;

                    auto* p = static_cast<SDK::APawn*>(a);
                    if (!p || !IsValidPtr(p) || p == skipPawn)
                        continue;

                    out.push_back(p);
                }
                __except (EXCEPTION_EXECUTE_HANDLER) {}
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    static void AppendStreamingPawns(SDK::UWorld* world,
                                     SDK::APawn* skipPawn,
                                     std::vector<SDK::APawn*>& out)
    {
        if (!world)
            return;

        __try {
            if (!IsValidPtr(world))
                return;

            auto& streaming = world->StreamingLevels;
            if (!streaming.IsValid())
                return;

            const int count = streaming.Num();
            for (int i = 0; i < count; ++i)
            {
                if (!streaming.IsValidIndex(i))
                    continue;
                SDK::ULevelStreaming* sl = streaming[i];
                AppendPawnsFromLevel(sl ? sl->LoadedLevel : nullptr, skipPawn, out);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    static SDK::APawn* SafeGetLocalPawn()
    {
        SDK::APawn* me = nullptr;
        __try {
            auto* localPc = GetLocalPC();
            me = localPc ? localPc->K2_GetPawn() : nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return me;
    }

    static SDK::ULevel* SafeGetPersistentLevel(SDK::UWorld* world)
    {
        SDK::ULevel* level = nullptr;
        __try {
            if (!world || !IsValidPtr(world))
                return nullptr;
            level = world->PersistentLevel;
            if (!level || !IsValidPtr(level))
                return nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return level;
    }

    std::vector<SDK::APawn*> GetAllPawns()
    {
        std::vector<SDK::APawn*> result;
        result.reserve(128);

        if (!GameState::IsPlayable())
            return result;

        auto* world = GetWorld();
        if (!world || !IsValidPtr(world))
            return result;

        SDK::APawn* me = SafeGetLocalPawn();
        AppendPawnsFromLevel(SafeGetPersistentLevel(world), me, result);
        AppendStreamingPawns(world, me, result);
        return result;
    }

    static void AppendActorsFromLevel(SDK::ULevel* lvl, std::vector<SDK::AActor*>& out)
    {
        if (!lvl)
            return;

        __try {
            if (!IsValidPtr(lvl))
                return;

            const int num = lvl->Actors.Num();
            for (int i = 0; i < num; ++i)
            {
                __try {
                    if (!lvl->Actors.IsValidIndex(i))
                        continue;

                    SDK::AActor* a = lvl->Actors[i];
                    if (a && IsValidPtr(a))
                        out.push_back(a);
                }
                __except (EXCEPTION_EXECUTE_HANDLER) {}
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    static void AppendStreamingActors(SDK::UWorld* world, std::vector<SDK::AActor*>& out)
    {
        if (!world)
            return;

        __try {
            if (!IsValidPtr(world))
                return;

            auto& streaming = world->StreamingLevels;
            if (!streaming.IsValid())
                return;

            const int count = streaming.Num();
            for (int i = 0; i < count; ++i)
            {
                if (!streaming.IsValidIndex(i))
                    continue;
                SDK::ULevelStreaming* sl = streaming[i];
                AppendActorsFromLevel(sl ? sl->LoadedLevel : nullptr, out);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    void GatherLevelActors(std::vector<SDK::AActor*>& result)
    {
        result.clear();
        if (result.capacity() < 512) result.reserve(512);
        if (!GameState::IsPlayable()) return;
        auto* world = GetWorld();
        if (!world || !IsValidPtr(world)) return;
        AppendActorsFromLevel(SafeGetPersistentLevel(world), result);
        AppendStreamingActors(world, result);
    }

    std::vector<SDK::AActor*> GetAllLevelActors()
    {
        std::vector<SDK::AActor*> result;
        GatherLevelActors(result);
        return result;
    }
}
