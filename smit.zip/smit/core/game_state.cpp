#include "game_state.h"
#include "sdk_helpers.h"
#include "../features/maphack.h"
#include "../features/skin_changer.h"
#include "../features/aimbot.h"
#include "../features/camera.h"
#include "pawn_filter.h"
#include "../features/esp.h"

namespace GameState
{
    static SDK::UWorld* s_lastWorld = nullptr;
    static SDK::ULevel* s_lastLevel = nullptr;
    static bool         s_playable  = false;

    static SDK::ULevel* SafeGetPersistentLevel(SDK::UWorld* world)
    {
        SDK::ULevel* level = nullptr;
        __try
        {
            if (!world || !Helpers::IsValidPtr(world))
                return nullptr;
            level = world->PersistentLevel;
            if (!level || !Helpers::IsValidPtr(level))
                return nullptr;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return nullptr;
        }
        return level;
    }

    static bool ComputePlayable()
    {
        __try
        {
            auto* world = Helpers::GetWorld();
            if (!world || !Helpers::IsValidPtr(world))
                return false;
            if (!world->OwningGameInstance || !Helpers::IsValidPtr(world->OwningGameInstance))
                return false;
            if (!SafeGetPersistentLevel(world))
                return false;
            auto* pc = Helpers::GetLocalPC();
            if (!pc || !Helpers::IsValidPtr(pc))
                return false;

            // PC alone is enough — pawn can be null briefly while dead/respawning.
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return false;
        }
    }

    static void OnSessionEnded()
    {
        MapHack::Reset();
        SkinChanger::ResetSession();
        Aimbot::ResetState();
        Camera::Reset();
        PawnFilter::ClearSessionCaches();
        ESP::Reset();
    }

    void Tick()
    {
        auto* world = Helpers::GetWorld();
        auto* level = SafeGetPersistentLevel(world);
        const bool playable = ComputePlayable();

        const bool worldChanged = (world != s_lastWorld);
        const bool levelChanged = (level != s_lastLevel);
        if ((worldChanged || levelChanged) &&
            (s_lastWorld != nullptr || s_lastLevel != nullptr))
        {
            OnSessionEnded();
        }

        if (s_playable && !playable)
            ESP::Reset();

        s_lastWorld = world;
        s_lastLevel = level;
        s_playable  = playable;

        if (s_playable)
            SkinChanger::TickPending();
    }

    bool IsPlayable()
    {
        return s_playable;
    }
}
