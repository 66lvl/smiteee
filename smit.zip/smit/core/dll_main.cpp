#include "../features/world_environment.h"
#include "../features/auto_laugh.h"
#include "../features/death_camera.h"
#include "../features/status_overlay.h"
#include <Windows.h>
#include <cstdio>

#include "hooks.h"
#include "renderer.h"
#include "gamepad_input.h"
#include "render_backend.h"
#include "../features/config.h"
#include "../features/auto_pick.h"
#include "../ui/menu.h"

namespace
{
    HMODULE g_Module = nullptr;

    void InitConsole()
    {
        AllocConsole();
        FILE* stream = nullptr;
        freopen_s(&stream, "CONOUT$", "w", stdout);
        freopen_s(&stream, "CONOUT$", "w", stderr);
        freopen_s(&stream, "CONIN$", "r", stdin);
    }

    DWORD WINAPI MainThread(LPVOID)
    {
        InitConsole();
        printf("[*] ALWAYSLOSE | SMITE 2 INTERNAL loading...\n");

        Sleep(2000);

        const RenderBackend::Api backend = RenderBackend::PromptOnInject();
        if (backend == RenderBackend::Api::None)
        {
            printf("[-] No DirectX backend selected — aborting.\n");
            FreeLibraryAndExitThread(g_Module, 0);
            return 0;
        }
        RenderBackend::SetSelected(backend);

        ::Config::Load();
        if (!GamepadInput::Initialize())
            printf("[-] Controller worker unavailable; keyboard/mouse remain active.\n");
        else
            printf("[+] Input worker enabled; no HID scans in Present.\n");
        Renderer::DrawCallback = []() { Menu::Draw(); };

        if (!Hooks::Initialize())
        {
            printf("[-] Hook initialization failed.\n");
            GamepadInput::Shutdown();
            FreeLibraryAndExitThread(g_Module, 0);
            return 0;
        }

        printf("[+] ALWAYSLOSE ready.\n");
        printf("[*] INSERT / DELETE / HOME = menu | END = unload\n");

        while (true)
        {
            if (GetAsyncKeyState(VK_END) & 1) {
                const bool environmentReady=WorldEnvironment::PrepareUnload();
                const bool cameraReady=DeathCamera::PrepareUnload();
                if(environmentReady&&cameraReady)break;
                WorldEnvironment::CancelUnload();
                if(!environmentReady)printf("[!] Environment restore pending. Disable environment/time effects and return to gameplay before END.\n");
                if(!cameraReady)printf("[!] Camera restore pending. Use native spectate controls / respawn, then END again.\n");
            }
            Sleep(100);
        }

        printf("[*] Unloading ALWAYSLOSE...\n");
        // Profile writes are explicit (Save / Save changes). Never persist an unsaved reset on END.
        WorldEnvironment::Shutdown();
        AutoLaugh::Shutdown();
        GamepadInput::Shutdown();
        DeathCamera::Shutdown();
        StatusOverlay::Shutdown();
        AutoPick::Shutdown();
        Renderer::Shutdown();
        Hooks::Shutdown();

        FreeLibraryAndExitThread(g_Module, 0);
        return 0;
    }
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        g_Module = module;
        DisableThreadLibraryCalls(module);
        CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
