#pragma once

#include "renderer.h"

bool RendererDx11_Initialize();
bool RendererDx11_IsReady();
void RendererDx11_Render();
void RendererDx11_Shutdown();

Renderer::GpuTexture RendererDx11_CreateTextureRgba(const unsigned char* rgba,
                                                   int width,
                                                   int height);
