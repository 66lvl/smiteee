#include "../features/world_environment.h"
#include "../features/auto_laugh.h"
#include "../features/death_camera.h"
#include "../features/status_overlay.h"
#include "renderer.h"
#include "menu_diagnostics.h"
#include <cstdio>
#include "performance.h"
#include "../features/auto_pick.h"
#include "renderer_dx11.h"
#include "render_backend.h"
#include "hooks.h"
#include "../ui/menu.h"
#include "../ui/theme.h"
#include "../features/ability_icons.h"
#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_win32.h"
#include "../imgui/imgui_impl_dx12.h"
#include <d3d12.h>
#include <dxgi1_4.h>
#include <vector>
#include <wrl/client.h>

#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")

static constexpr UINT kSrvHeapCapacity = 1024;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace Renderer
{
    void (*DrawCallback)() = nullptr;

    static bool InitializeDx12();

    static bool g_Initialized     = false;

    // Per-frame descriptor heaps and render targets
    struct FrameContext
    {
        ID3D12CommandAllocator* CommandAllocator = nullptr;
        UINT64                  FenceValue       = 0;
    };

    static ID3D12DescriptorHeap*   g_RTVHeap           = nullptr;
    static ID3D12DescriptorHeap*   g_SRVHeap           = nullptr;
    static ID3D12CommandAllocator* g_CommandAllocators[8] = {};
    static ID3D12GraphicsCommandList* g_CommandList    = nullptr;
    static ID3D12Fence*            g_Fence             = nullptr;
    static HANDLE                  g_FenceEvent        = nullptr;
    static UINT64                  g_FenceValues[8]    = {};
    static ID3D12Resource*         g_RenderTargets[8]  = {};
    static UINT                    g_BufferCount       = 0;
    static UINT                    g_RTVDescriptorSize = 0;
    static UINT                    g_SRVDescriptorSize = 0;
    static UINT                    g_NextSrvIndex      = 1;

    static ID3D12CommandAllocator* g_UploadAllocator   = nullptr;
    static ID3D12GraphicsCommandList* g_UploadList     = nullptr;
    static ID3D12Fence*            g_UploadFence       = nullptr;
    static HANDLE                  g_UploadFenceEvent  = nullptr;
    static UINT64                  g_UploadFenceValue  = 0;

    static std::vector<ID3D12Resource*> g_CustomTextures;

    // WNDPROC original
    static WNDPROC g_OrigWndProc = nullptr;
    static HWND    g_HookedWnd     = nullptr;

    static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    static UINT GetBackBufferIndex(IDXGISwapChain* swapchain, UINT bufferCount)
    {
        if (!swapchain || bufferCount == 0)
            return 0;

        IDXGISwapChain3* swap3 = nullptr;
        if (SUCCEEDED(swapchain->QueryInterface(IID_PPV_ARGS(&swap3))) && swap3)
        {
            const UINT idx = swap3->GetCurrentBackBufferIndex() % bufferCount;
            swap3->Release();
            return idx;
        }

        return 0;
    }

    static void EnsureWndProcHooked(HWND hwnd)
    {
        if (!hwnd || hwnd == g_HookedWnd)
            return;

        if (g_HookedWnd && g_OrigWndProc)
        {
            SetWindowLongPtrW(g_HookedWnd, GWLP_WNDPROC,
                              reinterpret_cast<LONG_PTR>(g_OrigWndProc));
        }

        g_HookedWnd = hwnd;
        Hooks::g_hWnd = hwnd;
        g_OrigWndProc = reinterpret_cast<WNDPROC>(
            SetWindowLongPtrW(hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc)));
    }

    static bool ShouldBlockGameInput(UINT msg)
    {
        if (!Menu::WantsInput())
            return false;

        if (msg == WM_INPUT)
            return true;

        const bool is_keyboard =
            (msg >= WM_KEYFIRST && msg <= WM_KEYLAST) ||
            msg == WM_CHAR || msg == WM_SYSCHAR || msg == WM_UNICHAR;
        const bool is_mouse =
            (msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) ||
            msg == WM_MOUSEWHEEL || msg == WM_MOUSEHWHEEL;
        const bool is_pointer =
            (msg >= WM_POINTERUPDATE && msg <= WM_POINTERUP) ||
            msg == WM_POINTERWHEEL;

        return is_keyboard || is_mouse || is_pointer;
    }

    static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        if (WorldEnvironment::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (AutoLaugh::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (DeathCamera::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (StatusOverlay::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (AutoPick::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (msg == WM_KEYUP)
        {
            if (wParam == VK_INSERT || wParam == VK_DELETE || wParam == VK_HOME)
                return TRUE;
        }

        if (msg == WM_SETCURSOR && LOWORD(lParam) == HTCLIENT)
        {
            ::SetCursor(nullptr);
            return TRUE;
        }

        const bool imgui_consumed =
            (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam) != 0);

        if (ShouldBlockGameInput(msg))
            return TRUE;

        if (imgui_consumed && Menu::WantsInput())
            return TRUE;

        if (!g_OrigWndProc)
            return DefWindowProcW(hwnd, msg, wParam, lParam);

        return CallWindowProcW(g_OrigWndProc, hwnd, msg, wParam, lParam);
    }

    // ---------------------------------------------------------------
    //  Initialize ImGui with D3D12 backend
    // ---------------------------------------------------------------
    bool Initialize()
    {
        if (RenderBackend::GetSelected() == RenderBackend::Api::DX11)
            return RendererDx11_Initialize();
        return InitializeDx12();
    }

    static bool InitializeDx12()
    {
        if (g_Initialized) return true;

        if (!Hooks::g_Device || !Hooks::g_CommandQueue || !Hooks::g_SwapChain || !Hooks::g_hWnd)
        {
            printf("[-] Renderer::Initialize: Attempted init before interface pointers were ready!\n");
            return false;
        }

        printf("[*] Renderer::Initialize: Starting D3D12/ImGui initialization...\n");

        auto* device     = Hooks::g_Device;
        auto* swapchain  = Hooks::g_SwapChain;
        auto* queue      = Hooks::g_CommandQueue;
        HWND  hwnd       = Hooks::g_hWnd;
        g_BufferCount    = Hooks::g_BufferCount;
        if (g_BufferCount == 0) g_BufferCount = 2;
        if (g_BufferCount > 8) { std::printf("[-] unsupported buffer count=%u (capacity=8)\n",g_BufferCount); return false; }

        // --- RTV descriptor heap ---
        D3D12_DESCRIPTOR_HEAP_DESC rtvDesc{};
        rtvDesc.Type           = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
        rtvDesc.NumDescriptors = g_BufferCount;
        rtvDesc.Flags          = D3D12_DESCRIPTOR_HEAP_FLAG_NONE;
        if (FAILED(device->CreateDescriptorHeap(&rtvDesc, IID_PPV_ARGS(&g_RTVHeap))))
            return false;

        g_RTVDescriptorSize = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);

        // --- SRV descriptor heap for ImGui ---
        D3D12_DESCRIPTOR_HEAP_DESC srvDesc{};
        srvDesc.Type           = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        srvDesc.NumDescriptors = kSrvHeapCapacity;
        srvDesc.Flags          = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if (FAILED(device->CreateDescriptorHeap(&srvDesc, IID_PPV_ARGS(&g_SRVHeap))))
            return false;

        g_SRVDescriptorSize = device->GetDescriptorHandleIncrementSize(
            D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        g_NextSrvIndex = 1;

        if (FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                                  IID_PPV_ARGS(&g_UploadAllocator))))
            return false;
        if (FAILED(device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT,
                                             g_UploadAllocator, nullptr,
                                             IID_PPV_ARGS(&g_UploadList))))
            return false;
        g_UploadList->Close();

        if (FAILED(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&g_UploadFence))))
            return false;
        g_UploadFenceEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        g_UploadFenceValue = 0;

        // --- Per-frame command allocators ---
        for (UINT i = 0; i < g_BufferCount; i++)
        {
            if (FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                                      IID_PPV_ARGS(&g_CommandAllocators[i]))))
                return false;
        }

        // --- Command list ---
        if (FAILED(device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT,
                                              g_CommandAllocators[0], nullptr,
                                              IID_PPV_ARGS(&g_CommandList))))
            return false;
        g_CommandList->Close();

        // --- Fence ---
        if (FAILED(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&g_Fence))))
            return false;
        g_FenceEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);

        // --- Bind render targets ---
        D3D12_CPU_DESCRIPTOR_HANDLE rtvHandle = g_RTVHeap->GetCPUDescriptorHandleForHeapStart();
        for (UINT i = 0; i < g_BufferCount; i++)
        {
            swapchain->GetBuffer(i, IID_PPV_ARGS(&g_RenderTargets[i]));
            device->CreateRenderTargetView(g_RenderTargets[i], nullptr, rtvHandle);
            rtvHandle.ptr += g_RTVDescriptorSize;
        }

        // --- ImGui Setup ---
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        io.IniFilename  = nullptr;

        const float dpiScale = ImGui_ImplWin32_GetDpiScaleForMonitor(
            ::MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST));
        UITheme::SetDisplayScale(dpiScale);

        UITheme::LoadFonts();
        UITheme::ApplyGlobalStyle();

        DXGI_SWAP_CHAIN_DESC desc{};
        swapchain->GetDesc(&desc);
        DXGI_FORMAT format = desc.BufferDesc.Format;
        if (format == DXGI_FORMAT_UNKNOWN) format = DXGI_FORMAT_R8G8B8A8_UNORM;

        if (!ImGui_ImplWin32_Init(hwnd)) {
            std::printf("[-] ImGui_ImplWin32_Init returned false\n");
            RenderSafety::halted.store(true); return false;
        }
        if (!ImGui_ImplDX12_Init(device, g_BufferCount, format,
                             g_SRVHeap,
                             g_SRVHeap->GetCPUDescriptorHandleForHeapStart(),
                             g_SRVHeap->GetGPUDescriptorHandleForHeapStart())) {
            std::printf("[-] ImGui_ImplDX12_Init returned false\n");
            RenderSafety::halted.store(true); return false;
        }

        // Explicitly clear RendererHasTextures flag to bypass new dynamic texture updates assert
        io.BackendFlags &= ~ImGuiBackendFlags_RendererHasTextures;

        // Build the font atlas in legacy mode after the backend flags have been settled
        if (!io.Fonts->Build()) {
            std::printf("[-] Font atlas Build returned false\n");
            RenderSafety::halted.store(true); return false;
        }

        EnsureWndProcHooked(hwnd);

        AbilityIcons::Initialize();

        g_Initialized = true;
        printf("[+] Renderer::Initialize: ImGui & D3D12 renderer initialized. Hooked WndProc at 0x%p\n", WndProc);
        return true;
    }

    bool IsReady()
    {
        if (RenderBackend::GetSelected() == RenderBackend::Api::DX11)
            return RendererDx11_IsReady();
        return g_Initialized;
    }

    static bool AllocateSrvDescriptor(D3D12_CPU_DESCRIPTOR_HANDLE* outCpu,
                                      D3D12_GPU_DESCRIPTOR_HANDLE* outGpu)
    {
        if (!g_SRVHeap || g_NextSrvIndex >= kSrvHeapCapacity)
            return false;

        D3D12_CPU_DESCRIPTOR_HANDLE cpu = g_SRVHeap->GetCPUDescriptorHandleForHeapStart();
        D3D12_GPU_DESCRIPTOR_HANDLE gpu = g_SRVHeap->GetGPUDescriptorHandleForHeapStart();
        cpu.ptr += static_cast<SIZE_T>(g_NextSrvIndex) * g_SRVDescriptorSize;
        gpu.ptr += static_cast<UINT64>(g_NextSrvIndex) * g_SRVDescriptorSize;
        ++g_NextSrvIndex;

        *outCpu = cpu;
        *outGpu = gpu;
        return true;
    }

    static void WaitUploadQueue()
    {
        if (!Hooks::g_CommandQueue || !g_UploadFence || !g_UploadFenceEvent)
            return;

        ++g_UploadFenceValue;
        Hooks::g_CommandQueue->Signal(g_UploadFence, g_UploadFenceValue);
        if (g_UploadFence->GetCompletedValue() < g_UploadFenceValue)
        {
            g_UploadFence->SetEventOnCompletion(g_UploadFenceValue, g_UploadFenceEvent);
            WaitForSingleObject(g_UploadFenceEvent, INFINITE);
        }
    }

    GpuTexture CreateTextureRgba(const unsigned char* rgba, int width, int height)
    {
        if (RenderBackend::GetSelected() == RenderBackend::Api::DX11)
            return RendererDx11_CreateTextureRgba(rgba, width, height);

        GpuTexture result{};
        if (!g_Initialized || !rgba || width <= 0 || height <= 0)
            return result;

        auto* device = Hooks::g_Device;
        auto* queue  = Hooks::g_CommandQueue;
        if (!device || !queue)
            return result;

        D3D12_CPU_DESCRIPTOR_HANDLE srvCpu{};
        D3D12_GPU_DESCRIPTOR_HANDLE srvGpu{};
        if (!AllocateSrvDescriptor(&srvCpu, &srvGpu))
            return result;

        D3D12_RESOURCE_DESC texDesc{};
        texDesc.Dimension          = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
        texDesc.Width              = static_cast<UINT>(width);
        texDesc.Height             = static_cast<UINT>(height);
        texDesc.DepthOrArraySize   = 1;
        texDesc.MipLevels          = 1;
        texDesc.Format             = DXGI_FORMAT_R8G8B8A8_UNORM;
        texDesc.SampleDesc.Count   = 1;
        texDesc.Layout             = D3D12_TEXTURE_LAYOUT_UNKNOWN;
        texDesc.Flags              = D3D12_RESOURCE_FLAG_NONE;

        D3D12_HEAP_PROPERTIES defaultHeap{};
        defaultHeap.Type = D3D12_HEAP_TYPE_DEFAULT;

        ID3D12Resource* texture = nullptr;
        if (FAILED(device->CreateCommittedResource(
                &defaultHeap, D3D12_HEAP_FLAG_NONE, &texDesc,
                D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&texture))))
            return result;

        const UINT rowPitch = static_cast<UINT>(width) * 4u;
        const UINT64 uploadPitch =
            (static_cast<UINT64>(rowPitch) + D3D12_TEXTURE_DATA_PITCH_ALIGNMENT - 1u) &
            ~(static_cast<UINT64>(D3D12_TEXTURE_DATA_PITCH_ALIGNMENT) - 1u);
        const UINT64 uploadSize = uploadPitch * static_cast<UINT64>(height);

        D3D12_HEAP_PROPERTIES uploadHeap{};
        uploadHeap.Type = D3D12_HEAP_TYPE_UPLOAD;

        D3D12_RESOURCE_DESC uploadDesc{};
        uploadDesc.Dimension          = D3D12_RESOURCE_DIMENSION_BUFFER;
        uploadDesc.Width              = uploadSize;
        uploadDesc.Height             = 1;
        uploadDesc.DepthOrArraySize   = 1;
        uploadDesc.MipLevels          = 1;
        uploadDesc.Format             = DXGI_FORMAT_UNKNOWN;
        uploadDesc.SampleDesc.Count   = 1;
        uploadDesc.Layout             = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;

        ID3D12Resource* uploadBuffer = nullptr;
        if (FAILED(device->CreateCommittedResource(
                &uploadHeap, D3D12_HEAP_FLAG_NONE, &uploadDesc,
                D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&uploadBuffer))))
        {
            texture->Release();
            return result;
        }

        void* mapped = nullptr;
        D3D12_RANGE readRange{ 0, 0 };
        if (FAILED(uploadBuffer->Map(0, &readRange, &mapped)) || !mapped)
        {
            uploadBuffer->Release();
            texture->Release();
            return result;
        }

        const unsigned char* src = rgba;
        auto* dst = static_cast<unsigned char*>(mapped);
        for (int y = 0; y < height; ++y)
            memcpy(dst + y * uploadPitch, src + y * rowPitch, rowPitch);
        uploadBuffer->Unmap(0, nullptr);

        g_UploadAllocator->Reset();
        g_UploadList->Reset(g_UploadAllocator, nullptr);

        D3D12_TEXTURE_COPY_LOCATION dstLoc{};
        dstLoc.pResource        = texture;
        dstLoc.Type             = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        dstLoc.SubresourceIndex = 0;

        D3D12_TEXTURE_COPY_LOCATION srcLoc{};
        srcLoc.pResource       = uploadBuffer;
        srcLoc.Type            = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
        srcLoc.PlacedFootprint.Offset = 0;
        srcLoc.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        srcLoc.PlacedFootprint.Footprint.Width  = static_cast<UINT>(width);
        srcLoc.PlacedFootprint.Footprint.Height = static_cast<UINT>(height);
        srcLoc.PlacedFootprint.Footprint.Depth  = 1;
        srcLoc.PlacedFootprint.Footprint.RowPitch = static_cast<UINT>(uploadPitch);

        g_UploadList->CopyTextureRegion(&dstLoc, 0, 0, 0, &srcLoc, nullptr);

        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type                   = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource   = texture;
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
        barrier.Transition.StateAfter  = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        g_UploadList->ResourceBarrier(1, &barrier);
        g_UploadList->Close();

        ID3D12CommandList* lists[] = { g_UploadList };
        queue->ExecuteCommandLists(1, lists);
        WaitUploadQueue();

        D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc{};
        srvDesc.Format                  = DXGI_FORMAT_R8G8B8A8_UNORM;
        srvDesc.ViewDimension           = D3D12_SRV_DIMENSION_TEXTURE2D;
        srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
        srvDesc.Texture2D.MipLevels     = 1;
        device->CreateShaderResourceView(texture, &srvDesc, srvCpu);

        uploadBuffer->Release();
        g_CustomTextures.push_back(texture);

        result.id     = static_cast<ImTextureID>(srvGpu.ptr);
        result.width  = width;
        result.height = height;
        result.valid  = true;
        return result;
    }

    // ---------------------------------------------------------------
    //  Render one frame (called from hkPresent each frame)
    // ---------------------------------------------------------------
    void Render()
    {
        RenderSafety::At(RenderSafety::Stage::EnterRender);

        Performance::Frame timingFrame;
        Performance::Scope timingTotal(Performance::Part::Frame);
        if (RenderBackend::GetSelected() == RenderBackend::Api::DX11)
        {
            RendererDx11_Render();
            return;
        }

        if (!g_Initialized) return;

        IDXGISwapChain* swapchain = Hooks::g_SwapChain;
        if (!swapchain) return;

        RenderSafety::At(RenderSafety::Stage::GetSwapDesc);
        DXGI_SWAP_CHAIN_DESC swapDesc{};
        if (SUCCEEDED(swapchain->GetDesc(&swapDesc)))
            EnsureWndProcHooked(swapDesc.OutputWindow);

        const UINT frameIdx = GetBackBufferIndex(swapchain, g_BufferCount);

        if (frameIdx >= 8 || frameIdx >= g_BufferCount) {
            std::printf("[-] invalid backbuffer index=%u count=%u\n",frameIdx,g_BufferCount);
            RenderSafety::halted.store(true); return;
        }

        // Wait for previous frame
        if (g_Fence->GetCompletedValue() < g_FenceValues[frameIdx])
        {
            Performance::Scope timingWait(Performance::Part::GpuWait);
            RenderSafety::At(RenderSafety::Stage::FenceWait);
            if (!RenderSafety::Check(g_Fence->SetEventOnCompletion(g_FenceValues[frameIdx], g_FenceEvent),"SetEventOnCompletion")) return;
            const DWORD waitResult = WaitForSingleObject(g_FenceEvent, INFINITE);
            if (waitResult != WAIT_OBJECT_0) {
                std::printf("[-] fence wait result=0x%08lX error=%lu\n",static_cast<unsigned long>(waitResult),GetLastError());
                RenderSafety::halted.store(true); return;
            }
        }

        // Begin frame
        RenderSafety::At(RenderSafety::Stage::AllocatorReset);
        if (!RenderSafety::Check(g_CommandAllocators[frameIdx]->Reset(),"Allocator::Reset")) return;
        RenderSafety::At(RenderSafety::Stage::ListReset);
        if (!RenderSafety::Check(g_CommandList->Reset(g_CommandAllocators[frameIdx], nullptr),"CommandList::Reset")) return;

        // Transition render target
        D3D12_RESOURCE_BARRIER barrier{};
        barrier.Type                   = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
        barrier.Transition.pResource   = g_RenderTargets[frameIdx];
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
        barrier.Transition.StateAfter  = D3D12_RESOURCE_STATE_RENDER_TARGET;
        barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        g_CommandList->ResourceBarrier(1, &barrier);

        D3D12_CPU_DESCRIPTOR_HANDLE rtvHandle = g_RTVHeap->GetCPUDescriptorHandleForHeapStart();
        rtvHandle.ptr += static_cast<SIZE_T>(frameIdx) * g_RTVDescriptorSize;
        g_CommandList->OMSetRenderTargets(1, &rtvHandle, FALSE, nullptr);
        g_CommandList->SetDescriptorHeaps(1, &g_SRVHeap);

        // ImGui frame
        ImGui::GetIO().MouseDrawCursor = Menu::WantsInput();

        RenderSafety::At(RenderSafety::Stage::BeginImGui);
        ImGui_ImplDX12_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // Run the normal callback immediately; no diagnostic F8 gate.
        RenderSafety::At(RenderSafety::Stage::Callback);
        if (DrawCallback) DrawCallback();

        RenderSafety::At(RenderSafety::Stage::EndImGui);
        ImGui::Render();
        RenderSafety::At(RenderSafety::Stage::DrawData);
        Performance::Measure(Performance::Part::Submit, [&]() {
            ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_CommandList);
        });

        // Transition back
        barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
        barrier.Transition.StateAfter  = D3D12_RESOURCE_STATE_PRESENT;
        g_CommandList->ResourceBarrier(1, &barrier);
        RenderSafety::At(RenderSafety::Stage::CloseList);
        if (!RenderSafety::Check(g_CommandList->Close(),"CommandList::Close")) return;

        ID3D12CommandList* ppCL[] = { g_CommandList };
        RenderSafety::At(RenderSafety::Stage::Execute);
        Hooks::g_CommandQueue->ExecuteCommandLists(1, ppCL);


        // Signal fence
        static UINT64 fenceVal = 0;
        g_FenceValues[frameIdx] = ++fenceVal;
        RenderSafety::At(RenderSafety::Stage::Signal);
        if (!RenderSafety::Check(Hooks::g_CommandQueue->Signal(g_Fence, fenceVal),"Queue::Signal")) return;
        RenderSafety::At(RenderSafety::Stage::Done);
    }

    void Shutdown()
    {
        if (RenderBackend::GetSelected() == RenderBackend::Api::DX11)
        {
            RendererDx11_Shutdown();
            return;
        }

        if (!g_Initialized) return;
        AbilityIcons::Shutdown();
        ImGui_ImplDX12_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();

        if (g_HookedWnd && g_OrigWndProc)
        {
            SetWindowLongPtrW(g_HookedWnd, GWLP_WNDPROC,
                              reinterpret_cast<LONG_PTR>(g_OrigWndProc));
            g_HookedWnd = nullptr;
            g_OrigWndProc = nullptr;
        }

        for (UINT i = 0; i < g_BufferCount; i++)
        {
            if (g_CommandAllocators[i]) g_CommandAllocators[i]->Release();
            if (g_RenderTargets[i])     g_RenderTargets[i]->Release();
        }
        if (g_CommandList) g_CommandList->Release();
        if (g_RTVHeap)     g_RTVHeap->Release();
        if (g_SRVHeap)     g_SRVHeap->Release();
        if (g_Fence)       g_Fence->Release();
        if (g_FenceEvent)  CloseHandle(g_FenceEvent);

        for (ID3D12Resource* tex : g_CustomTextures)
        {
            if (tex)
                tex->Release();
        }
        g_CustomTextures.clear();

        if (g_UploadList)      { g_UploadList->Release();      g_UploadList = nullptr; }
        if (g_UploadAllocator) { g_UploadAllocator->Release(); g_UploadAllocator = nullptr; }
        if (g_UploadFence)     { g_UploadFence->Release();     g_UploadFence = nullptr; }
        if (g_UploadFenceEvent){ CloseHandle(g_UploadFenceEvent); g_UploadFenceEvent = nullptr; }

        g_Initialized = false;
        printf("[+] Renderer::Shutdown: D3D12/ImGui resources cleaned up.\n");
    }
}
