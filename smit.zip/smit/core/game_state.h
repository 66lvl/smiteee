#pragma once

namespace GameState
{
    void Tick();
    bool IsPlayable();
}
