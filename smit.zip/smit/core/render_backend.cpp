#include "render_backend.h"
#include <Windows.h>
#include <commctrl.h>

#pragma comment(lib, "comctl32.lib")

namespace RenderBackend
{
    static Api s_selected = Api::None;

    namespace
    {
        constexpr int kBtnDx12 = 1001;
        constexpr int kBtnDx11 = 1002;
    }

    Api PromptOnInject()
    {
        const TASKDIALOG_BUTTON buttons[] = {
            { kBtnDx12, L"DirectX 12" },
            { kBtnDx11, L"DirectX 11" },
        };

        TASKDIALOGCONFIG config = {};
        config.cbSize = sizeof(config);
        config.hwndParent = nullptr;
        config.pszWindowTitle = L"directx selecter";
        config.cButtons = static_cast<UINT>(sizeof(buttons) / sizeof(buttons[0]));
        config.pButtons = buttons;
        config.dwCommonButtons = 0;
        config.pszMainIcon = TD_INFORMATION_ICON;

        int pressed = 0;
        const HRESULT hr = TaskDialogIndirect(&config, &pressed, nullptr, nullptr);
        if (FAILED(hr) || pressed == 0)
            return Api::None;
        if (pressed == kBtnDx12)
            return Api::DX12;
        if (pressed == kBtnDx11)
            return Api::DX11;
        return Api::None;
    }

    void SetSelected(Api api)
    {
        s_selected = api;
    }

    Api GetSelected()
    {
        return s_selected;
    }
}
