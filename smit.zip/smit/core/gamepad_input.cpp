#include "gamepad_input.h"
#include <Windows.h>
#include <XInput.h>
#include <hidsdi.h>
#include <setupapi.h>
#include <initguid.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <atomic>
#include <mutex>

#ifndef GUID_DEVINTERFACE_HID
DEFINE_GUID(GUID_DEVINTERFACE_HID, 0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30);
#endif

#pragma comment(lib, "xinput.lib")
#pragma comment(lib, "hid.lib")
#pragma comment(lib, "setupapi.lib")

#ifndef HID_USAGE_PAGE_GENERIC
#define HID_USAGE_PAGE_GENERIC 0x01
#endif
#ifndef HID_USAGE_GENERIC_GAMEPAD
#define HID_USAGE_GENERIC_GAMEPAD 0x05
#endif
#ifndef HID_USAGE_GENERIC_JOYSTICK
#define HID_USAGE_GENERIC_JOYSTICK 0x04
#endif

namespace GamepadInput
{
    static constexpr int kMaxXInputDevices = 4;
    static constexpr int kMaxSonyDevices     = 2;
    static constexpr int kMaxDevices         = kMaxXInputDevices + kMaxSonyDevices;
    static constexpr BYTE kTriggerThreshold  = 64;
    static constexpr unsigned short kSonyVid   = 0x054C;

    struct Device
    {
        Backend backend = Backend::XInput;
        int     backendIndex = 0;
        bool    connected = false;
        char    name[64] = "Controller";
        bool    buttons[(int)Button::Count]{};
    };

    static Device s_devices[kMaxDevices]{};
    static int    s_deviceCount = 0;
    // Only Tick/API access s_devices. The worker publishes value-only snapshots.
    static Device s_workerDevices[kMaxDevices]{};
    static int s_workerCount = 0;
    static Device s_published[kMaxDevices]{};
    static int s_publishedCount = 0;
    static std::mutex s_snapshotMutex;
    static std::atomic<bool> s_stop{false};
    static HANDLE s_worker = nullptr, s_wake = nullptr;
    static ULONGLONG s_nextSonyRefresh = 0;
    static ULONGLONG s_nextXProbe[kMaxXInputDevices]{};
    static bool s_xConnected[kMaxXInputDevices]{};

    struct SonySlot
    {
        HANDLE handle = INVALID_HANDLE_VALUE;
        wchar_t path[260]{};
        char name[64] = "PlayStation Controller";
        bool connected = false;
        bool buttons[(int)Button::Count]{};
        OVERLAPPED readOp{};
        uint8_t report[64]{};
        bool readPending = false;
    };

    static SonySlot s_sony[kMaxSonyDevices]{};

    static const char* kButtonLabels[] =
    {
        "LT / L2", "RT / R2", "LB / L1", "RB / R1",
        "A / Cross", "B / Circle", "X / Square", "Y / Triangle",
        "L Stick", "R Stick",
        "D-Pad Up", "D-Pad Down", "D-Pad Left", "D-Pad Right",
    };

    static_assert((int)Button::Count == _countof(kButtonLabels), "Button labels out of sync");

    static void ClearButtons(bool* buttons)
    {
        for (int i = 0; i < (int)Button::Count; ++i)
            buttons[i] = false;
    }

    static void SetButton(bool* buttons, Button btn, bool down)
    {
        const int idx = static_cast<int>(btn);
        if (idx >= 0 && idx < (int)Button::Count)
            buttons[idx] = down;
    }

    static void ParseSonyReport(const uint8_t* report, int len, bool* buttons)
    {
        ClearButtons(buttons);
        if (!report || len < 10)
            return;

        const uint8_t b5 = report[5];
        const uint8_t b6 = report[6];
        const uint8_t l2 = report[8];
        const uint8_t r2 = report[9];

        const int dpad = b5 & 0x0F;
        SetButton(buttons, Button::DpadUp,    dpad == 0 || dpad == 1 || dpad == 7);
        SetButton(buttons, Button::DpadRight, dpad == 1 || dpad == 2 || dpad == 3);
        SetButton(buttons, Button::DpadDown,  dpad == 3 || dpad == 4 || dpad == 5);
        SetButton(buttons, Button::DpadLeft,  dpad == 5 || dpad == 6 || dpad == 7);

        SetButton(buttons, Button::X, (b5 & (1 << 4)) != 0); // Square
        SetButton(buttons, Button::A, (b5 & (1 << 5)) != 0); // Cross
        SetButton(buttons, Button::B, (b5 & (1 << 6)) != 0); // Circle
        SetButton(buttons, Button::Y, (b5 & (1 << 7)) != 0); // Triangle

        SetButton(buttons, Button::LB, (b6 & (1 << 0)) != 0);
        SetButton(buttons, Button::RB, (b6 & (1 << 1)) != 0);
        SetButton(buttons, Button::LStick, (b6 & (1 << 6)) != 0);
        SetButton(buttons, Button::RStick, (b6 & (1 << 7)) != 0);

        SetButton(buttons, Button::LT, l2 > kTriggerThreshold || (b6 & (1 << 2)) != 0);
        SetButton(buttons, Button::RT, r2 > kTriggerThreshold || (b6 & (1 << 3)) != 0);
    }

    static bool IsPlaystationInterface(HIDD_ATTRIBUTES& attr)
    {
        return attr.VendorID == kSonyVid;
    }

    static void CloseSonySlot(SonySlot& slot)
    {
        if (slot.handle != INVALID_HANDLE_VALUE)
        {
            if (slot.readPending)
            {
                CancelIoEx(slot.handle, &slot.readOp);
                DWORD ignored = 0;
                // Worker/shutdown only; OVERLAPPED storage must outlive cancellation.
                GetOverlappedResult(slot.handle, &slot.readOp, &ignored, TRUE);
                slot.readPending = false;
            }
            CloseHandle(slot.handle);
            slot.handle = INVALID_HANDLE_VALUE;
        }
        if (slot.readOp.hEvent) CloseHandle(slot.readOp.hEvent);
        slot.readOp = {};
        slot.connected = false;
        ClearButtons(slot.buttons);
        slot.path[0] = L'\0';
    }

    static void RefreshSonyDevices()
    {
        const ULONGLONG now = GetTickCount64();
        if (now < s_nextSonyRefresh) return;
        s_nextSonyRefresh = now + 2000;
        for (int i = 0; i < kMaxSonyDevices; ++i)
            s_sony[i].connected = false;

        HDEVINFO devInfo = SetupDiGetClassDevsW(
            &GUID_DEVINTERFACE_HID, nullptr, nullptr,
            DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
        if (devInfo == INVALID_HANDLE_VALUE)
            return;

        SP_DEVICE_INTERFACE_DATA ifData{};
        ifData.cbSize = sizeof(ifData);

        int nextSlot = 0;
        for (DWORD idx = 0;
             nextSlot < kMaxSonyDevices &&
             SetupDiEnumDeviceInterfaces(devInfo, nullptr, &GUID_DEVINTERFACE_HID, idx, &ifData);
             ++idx)
        {
            DWORD reqSize = 0;
            SetupDiGetDeviceInterfaceDetailW(devInfo, &ifData, nullptr, 0, &reqSize, nullptr);
            if (reqSize == 0)
                continue;

            auto* detail = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA_W*>(malloc(reqSize));
            if (!detail)
                continue;

            detail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W);
            if (!SetupDiGetDeviceInterfaceDetailW(devInfo, &ifData, detail, reqSize, nullptr, nullptr))
            {
                free(detail);
                continue;
            }

            HIDD_ATTRIBUTES attr{};
            attr.Size = sizeof(attr);
            bool isSony = false;
            {
                HANDLE probe = CreateFileW(
                    detail->DevicePath, 0,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    nullptr, OPEN_EXISTING, 0, nullptr);
                if (probe != INVALID_HANDLE_VALUE)
                {
                    if (HidD_GetAttributes(probe, &attr) && IsPlaystationInterface(attr))
                        isSony = true;
                    CloseHandle(probe);
                }
            }

            if (!isSony)
            {
                free(detail);
                continue;
            }

            SonySlot* slot = nullptr;
            for (int s = 0; s < kMaxSonyDevices; ++s)
            {
                if (s_sony[s].path[0] != L'\0' &&
                    wcscmp(s_sony[s].path, detail->DevicePath) == 0)
                {
                    slot = &s_sony[s];
                    break;
                }
            }
            if (!slot)
            {
                for (int s = 0; s < kMaxSonyDevices; ++s)
                {
                    if (s_sony[s].path[0] == L'\0')
                    {
                        slot = &s_sony[s];
                        wcscpy_s(slot->path, detail->DevicePath);
                        break;
                    }
                }
            }

            if (slot)
            {
                if (slot->handle == INVALID_HANDLE_VALUE)
                {
                    slot->handle = CreateFileW(
                        detail->DevicePath,
                        GENERIC_READ | GENERIC_WRITE,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        nullptr, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, nullptr);
                }

                if (slot->handle != INVALID_HANDLE_VALUE)
                {
                    if (!slot->readOp.hEvent)
                        slot->readOp.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
                    if (!slot->readOp.hEvent) { CloseSonySlot(*slot); free(detail); continue; }
                    slot->connected = true;
                    if (attr.ProductID == 0x0CE6 || attr.ProductID == 0x0DF2)
                        strcpy_s(slot->name, "DualSense");
                    else if (attr.ProductID == 0x05C4 || attr.ProductID == 0x09CC || attr.ProductID == 0x0BA0)
                        strcpy_s(slot->name, "DualShock 4");
                    else
                        snprintf(slot->name, sizeof(slot->name), "PlayStation %04X", attr.ProductID);

                    if (nextSlot < kMaxSonyDevices)
                        ++nextSlot;
                }
            }

            free(detail);
        }

        SetupDiDestroyDeviceInfoList(devInfo);
        for (auto& slot : s_sony)
            if (!slot.connected && slot.handle != INVALID_HANDLE_VALUE) CloseSonySlot(slot);
    }

    static void PollSonyDevices()
    {
        RefreshSonyDevices();

        for (int i = 0; i < kMaxSonyDevices; ++i)
        {
            SonySlot& slot = s_sony[i];
            if (!slot.connected || slot.handle == INVALID_HANDLE_VALUE)
                continue;

            DWORD read = 0;
            if (slot.readPending)
            {
                if (!GetOverlappedResult(slot.handle, &slot.readOp, &read, FALSE))
                {
                    if (GetLastError() == ERROR_IO_INCOMPLETE) continue;
                    CloseSonySlot(slot); continue;
                }
                slot.readPending = false;
                if (read >= 10) ParseSonyReport(slot.report, static_cast<int>(read), slot.buttons);
            }
            ResetEvent(slot.readOp.hEvent);
            if (ReadFile(slot.handle, slot.report, sizeof(slot.report), &read, &slot.readOp))
            {
                if (read >= 10) ParseSonyReport(slot.report, static_cast<int>(read), slot.buttons);
            }
            else if (GetLastError() == ERROR_IO_PENDING)
                slot.readPending = true;
            else
                CloseSonySlot(slot);
        }
    }

    static void DecodeXInput(const XINPUT_STATE& state, bool* buttons)
    {
        ClearButtons(buttons);
        const XINPUT_GAMEPAD& pad = state.Gamepad;
        SetButton(buttons, Button::LT, pad.bLeftTrigger > kTriggerThreshold);
        SetButton(buttons, Button::RT, pad.bRightTrigger > kTriggerThreshold);
        SetButton(buttons, Button::LB, (pad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) != 0);
        SetButton(buttons, Button::RB, (pad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) != 0);
        SetButton(buttons, Button::A,  (pad.wButtons & XINPUT_GAMEPAD_A) != 0);
        SetButton(buttons, Button::B,  (pad.wButtons & XINPUT_GAMEPAD_B) != 0);
        SetButton(buttons, Button::X,  (pad.wButtons & XINPUT_GAMEPAD_X) != 0);
        SetButton(buttons, Button::Y,  (pad.wButtons & XINPUT_GAMEPAD_Y) != 0);
        SetButton(buttons, Button::LStick, (pad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB) != 0);
        SetButton(buttons, Button::RStick, (pad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) != 0);
        SetButton(buttons, Button::DpadUp,    (pad.wButtons & XINPUT_GAMEPAD_DPAD_UP) != 0);
        SetButton(buttons, Button::DpadDown,  (pad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN) != 0);
        SetButton(buttons, Button::DpadLeft,  (pad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT) != 0);
        SetButton(buttons, Button::DpadRight, (pad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) != 0);
    }

    static void RebuildDeviceList()
    {
        s_workerCount = 0;
        const ULONGLONG now = GetTickCount64();
        for (int i = 0; i < kMaxXInputDevices; ++i)
        {
            if (!s_xConnected[i] && now < s_nextXProbe[i]) continue;
            XINPUT_STATE state{};
            s_xConnected[i] = XInputGetState(static_cast<DWORD>(i), &state) == ERROR_SUCCESS;
            s_nextXProbe[i] = now + 1000;
            if (!s_xConnected[i]) continue;
            Device& dev = s_workerDevices[s_workerCount++];
            dev.backend = Backend::XInput; dev.backendIndex = i; dev.connected = true;
            snprintf(dev.name, sizeof(dev.name), "Xbox / XInput %d", i + 1);
            DecodeXInput(state, dev.buttons);
        }
        for (int i = 0; i < kMaxSonyDevices; ++i)
        {
            if (!s_sony[i].connected) continue;
            Device& dev = s_workerDevices[s_workerCount++];
            dev.backend = Backend::SonyHid; dev.backendIndex = i; dev.connected = true;
            strcpy_s(dev.name, s_sony[i].name);
            memcpy(dev.buttons, s_sony[i].buttons, sizeof(dev.buttons));
        }
    }

    static DWORD WINAPI InputWorker(LPVOID)
    {
        while (!s_stop.load())
        {
            // Win32 input only: no UObject access or game/SDK calls on this thread.
            PollSonyDevices();
            RebuildDeviceList();
            {
                std::lock_guard<std::mutex> lock(s_snapshotMutex);
                memcpy(s_published, s_workerDevices, sizeof(s_published));
                s_publishedCount = s_workerCount;
            }
            if (WaitForSingleObject(s_wake, 8) != WAIT_TIMEOUT) break;
        }
        for (auto& slot : s_sony) CloseSonySlot(slot);
        return 0;
    }

    bool Initialize()
    {
        if (s_worker) return true;
        s_stop = false;
        s_nextSonyRefresh = 0;
        memset(s_nextXProbe, 0, sizeof(s_nextXProbe));
        memset(s_xConnected, 0, sizeof(s_xConnected));
        s_wake = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!s_wake) return false;
        s_worker = CreateThread(nullptr, 0, InputWorker, nullptr, 0, nullptr);
        if (!s_worker) { CloseHandle(s_wake); s_wake = nullptr; return false; }
        return true;
    }

    void Shutdown()
    {
        s_stop = true;
        if (s_wake) SetEvent(s_wake);
        if (s_worker)
        {
            WaitForSingleObject(s_worker, INFINITE);
            CloseHandle(s_worker); s_worker = nullptr;
        }
        if (s_wake) { CloseHandle(s_wake); s_wake = nullptr; }
        std::lock_guard<std::mutex> lock(s_snapshotMutex);
        s_publishedCount = 0;
    }

    void Tick()
    {
        // Render thread: never enumerate, probe, read HID or wait for the worker.
        std::unique_lock<std::mutex> lock(s_snapshotMutex, std::try_to_lock);
        if (!lock.owns_lock()) return;
        memcpy(s_devices, s_published, sizeof(s_devices));
        s_deviceCount = s_publishedCount;
    }

    int DeviceCount()
    {
        return s_deviceCount;
    }

    bool IsDeviceConnected(int deviceId)
    {
        return deviceId >= 0 && deviceId < s_deviceCount && s_devices[deviceId].connected;
    }

    const char* DeviceName(int deviceId)
    {
        if (!IsDeviceConnected(deviceId))
            return "Controller";
        return s_devices[deviceId].name;
    }

    bool IsDeviceButtonDown(int deviceId, Button button)
    {
        if (!IsDeviceConnected(deviceId))
            return false;

        const int idx = static_cast<int>(button);
        if (idx < 0 || idx >= (int)Button::Count)
            return false;

        return s_devices[deviceId].buttons[idx];
    }

    bool CaptureAnyButton(int* outDeviceId, Button* outButton)
    {
        if (!outDeviceId || !outButton)
            return false;

        for (int d = 0; d < s_deviceCount; ++d)
        {
            for (int b = 0; b < (int)Button::Count; ++b)
            {
                if (!s_devices[d].buttons[b])
                    continue;

                *outDeviceId = d;
                *outButton = static_cast<Button>(b);
                return true;
            }
        }
        return false;
    }

    void FormatBindingLabel(int deviceId, Button button, char* buf, int bufSize)
    {
        if (!buf || bufSize <= 0)
            return;

        const char* btn = ButtonLabel(button);
        if (!IsDeviceConnected(deviceId))
        {
            snprintf(buf, bufSize, "%s", btn);
            return;
        }

        snprintf(buf, bufSize, "%s · %s", btn, s_devices[deviceId].name);
    }

    int FindDevice(Backend backend, int backendIndex)
    {
        for (int i = 0; i < s_deviceCount; ++i)
        {
            if (s_devices[i].backend == backend && s_devices[i].backendIndex == backendIndex)
                return i;
        }
        return 0;
    }

    int ButtonCount()
    {
        return static_cast<int>(Button::Count);
    }

    const char* ButtonLabel(Button button)
    {
        const int idx = static_cast<int>(button);
        if (idx < 0 || idx >= ButtonCount())
            return "?";
        return kButtonLabels[idx];
    }
}
