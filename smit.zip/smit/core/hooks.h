#pragma once

#include <functional>
#include <cstddef>

struct ID3D12Device;
struct ID3D12CommandQueue;
struct ID3D11Device;
struct ID3D11DeviceContext;
struct IDXGISwapChain;
struct HWND__;
typedef HWND__* HWND;

namespace Hooks
{
    extern std::function<void()> OnPresent;

    extern ID3D12Device*          g_Device;
    extern ID3D12CommandQueue*    g_CommandQueue;
    extern ID3D11Device*          g_Device11;
    extern ID3D11DeviceContext*   g_Context11;
    extern IDXGISwapChain*        g_SwapChain;
    extern HWND                   g_hWnd;
    extern unsigned int           g_BufferCount;
    extern size_t                 g_CommandQueueOffset;

    bool Initialize();
    void Shutdown();
}
