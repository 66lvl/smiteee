#include "../features/world_environment.h"
#include "../features/auto_laugh.h"
#include "../features/death_camera.h"
#include "../features/status_overlay.h"
#include "renderer_dx11.h"
#include "performance.h"
#include "../features/auto_pick.h"
#include "renderer.h"
#include "hooks.h"
#include "render_backend.h"
#include "../ui/menu.h"
#include "../ui/theme.h"
#include "../features/ability_icons.h"
#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_win32.h"
#include "../imgui/imgui_impl_dx11.h"
#include <d3d11.h>
#include <dxgi.h>
#include <vector>

#pragma comment(lib, "d3d11.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace
{
    static bool g_Initialized = false;

    static ID3D11RenderTargetView* g_Rtv = nullptr;
    static bool                    g_NeedRtvRecreate = true;

    static std::vector<ID3D11ShaderResourceView*> g_TextureSrvs;
    static std::vector<ID3D11Texture2D*>          g_TextureResources;

    static WNDPROC g_OrigWndProc = nullptr;
    static HWND    g_HookedWnd   = nullptr;

    static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

    static void EnsureWndProcHooked(HWND hwnd)
    {
        if (!hwnd || hwnd == g_HookedWnd)
            return;

        if (g_HookedWnd && g_OrigWndProc)
        {
            SetWindowLongPtrW(g_HookedWnd, GWLP_WNDPROC,
                              reinterpret_cast<LONG_PTR>(g_OrigWndProc));
        }

        g_HookedWnd = hwnd;
        Hooks::g_hWnd = hwnd;
        g_OrigWndProc = reinterpret_cast<WNDPROC>(
            SetWindowLongPtrW(hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc)));
    }

    static bool ShouldBlockGameInput(UINT msg)
    {
        if (!Menu::WantsInput())
            return false;

        if (msg == WM_INPUT)
            return true;

        const bool is_keyboard =
            (msg >= WM_KEYFIRST && msg <= WM_KEYLAST) ||
            msg == WM_CHAR || msg == WM_SYSCHAR || msg == WM_UNICHAR;
        const bool is_mouse =
            (msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) ||
            msg == WM_MOUSEWHEEL || msg == WM_MOUSEHWHEEL;
        const bool is_pointer =
            (msg >= WM_POINTERUPDATE && msg <= WM_POINTERUP) ||
            msg == WM_POINTERWHEEL;

        return is_keyboard || is_mouse || is_pointer;
    }

    static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        if (WorldEnvironment::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (AutoLaugh::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (DeathCamera::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (StatusOverlay::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (AutoPick::HandleWindowMessage(hwnd, msg, wParam, lParam)) return 0;
        if (msg == WM_KEYUP)
        {
            if (wParam == VK_INSERT || wParam == VK_DELETE || wParam == VK_HOME)
                return TRUE;
        }

        if (msg == WM_SETCURSOR && LOWORD(lParam) == HTCLIENT)
        {
            ::SetCursor(nullptr);
            return TRUE;
        }

        const bool imgui_consumed =
            (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam) != 0);

        if (ShouldBlockGameInput(msg))
            return TRUE;

        if (imgui_consumed && Menu::WantsInput())
            return TRUE;

        if (!g_OrigWndProc)
            return DefWindowProcW(hwnd, msg, wParam, lParam);

        return CallWindowProcW(g_OrigWndProc, hwnd, msg, wParam, lParam);
    }

    static void ReleaseRtv()
    {
        if (g_Rtv)
        {
            g_Rtv->Release();
            g_Rtv = nullptr;
        }
    }

    static void CreateOrRecreateRtv(IDXGISwapChain* swap)
    {
        ReleaseRtv();

        ID3D11Texture2D* backBuffer = nullptr;
        if (FAILED(swap->GetBuffer(0, IID_PPV_ARGS(&backBuffer))) || !backBuffer)
            return;

        if (Hooks::g_Device11)
            Hooks::g_Device11->CreateRenderTargetView(backBuffer, nullptr, &g_Rtv);

        backBuffer->Release();
    }

    static void EnsureDevice(IDXGISwapChain* swap)
    {
        if (Hooks::g_Device11 && Hooks::g_Context11)
            return;

        if (Hooks::g_Context11)
        {
            Hooks::g_Context11->Release();
            Hooks::g_Context11 = nullptr;
        }
        if (Hooks::g_Device11)
        {
            Hooks::g_Device11->Release();
            Hooks::g_Device11 = nullptr;
        }

        ID3D11Device* device = nullptr;
        if (SUCCEEDED(swap->GetDevice(IID_PPV_ARGS(&device))) && device)
        {
            Hooks::g_Device11 = device;
            device->GetImmediateContext(&Hooks::g_Context11);
            g_NeedRtvRecreate = true;
            printf("[*] RendererDx11: recovered D3D11 device 0x%p\n", device);
        }
    }
}

bool RendererDx11_Initialize()
{
    if (g_Initialized)
        return true;

    if (!Hooks::g_Device11 || !Hooks::g_Context11 || !Hooks::g_SwapChain || !Hooks::g_hWnd)
    {
        printf("[-] RendererDx11: interfaces not ready\n");
        return false;
    }

    printf("[*] RendererDx11: initializing...\n");

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;

    const float dpiScale = ImGui_ImplWin32_GetDpiScaleForMonitor(
        ::MonitorFromWindow(Hooks::g_hWnd, MONITOR_DEFAULTTONEAREST));
    UITheme::SetDisplayScale(dpiScale);
    UITheme::LoadFonts();
    UITheme::ApplyGlobalStyle();

    ImGui_ImplWin32_Init(Hooks::g_hWnd);
    ImGui_ImplDX11_Init(Hooks::g_Device11, Hooks::g_Context11);
    io.BackendFlags &= ~ImGuiBackendFlags_RendererHasTextures;
    io.Fonts->Build();

    EnsureWndProcHooked(Hooks::g_hWnd);
    CreateOrRecreateRtv(Hooks::g_SwapChain);
    g_NeedRtvRecreate = false;
    AbilityIcons::Initialize();

    g_Initialized = true;
    printf("[+] RendererDx11: ready\n");
    return true;
}

bool RendererDx11_IsReady()
{
    return g_Initialized;
}

void RendererDx11_Render()
{
    if (!g_Initialized)
        return;

    IDXGISwapChain* swap = Hooks::g_SwapChain;
    if (!swap)
        return;

    EnsureDevice(swap);
    if (!Hooks::g_Device11 || !Hooks::g_Context11)
        return;

    DXGI_SWAP_CHAIN_DESC swapDesc{};
    if (SUCCEEDED(swap->GetDesc(&swapDesc)))
    {
        if (Hooks::g_hWnd && Hooks::g_hWnd != swapDesc.OutputWindow)
        {
            if (g_HookedWnd && g_OrigWndProc)
            {
                SetWindowLongPtrW(g_HookedWnd, GWLP_WNDPROC,
                                  reinterpret_cast<LONG_PTR>(g_OrigWndProc));
                g_HookedWnd = nullptr;
                g_OrigWndProc = nullptr;
            }
            g_NeedRtvRecreate = true;
        }
        EnsureWndProcHooked(swapDesc.OutputWindow);
    }

    if (g_NeedRtvRecreate || !g_Rtv)
    {
        CreateOrRecreateRtv(swap);
        g_NeedRtvRecreate = false;
    }

    ImGui::GetIO().MouseDrawCursor = Menu::WantsInput();

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    if (Renderer::DrawCallback)
        Renderer::DrawCallback();

    ImGui::Render();

    if (!g_Rtv)
        CreateOrRecreateRtv(swap);
    if (!g_Rtv)
        return;

    ID3D11RenderTargetView* rtv = g_Rtv;
    Hooks::g_Context11->OMSetRenderTargets(1, &rtv, nullptr);
    Performance::Measure(Performance::Part::Submit, [&]() {
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    });
}

void RendererDx11_Shutdown()
{
    if (!g_Initialized)
        return;

    AbilityIcons::Shutdown();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    if (g_HookedWnd && g_OrigWndProc)
    {
        SetWindowLongPtrW(g_HookedWnd, GWLP_WNDPROC,
                          reinterpret_cast<LONG_PTR>(g_OrigWndProc));
        g_HookedWnd = nullptr;
        g_OrigWndProc = nullptr;
    }

    ReleaseRtv();

    for (ID3D11ShaderResourceView* srv : g_TextureSrvs)
    {
        if (srv)
            srv->Release();
    }
    g_TextureSrvs.clear();

    for (ID3D11Texture2D* tex : g_TextureResources)
    {
        if (tex)
            tex->Release();
    }
    g_TextureResources.clear();

    g_NeedRtvRecreate = true;
    g_Initialized = false;
    printf("[+] RendererDx11: shutdown complete\n");
}

Renderer::GpuTexture RendererDx11_CreateTextureRgba(const unsigned char* rgba,
                                                    int width,
                                                    int height)
{
    Renderer::GpuTexture result{};
    if (!g_Initialized || !rgba || width <= 0 || height <= 0)
        return result;

    auto* device = Hooks::g_Device11;
    if (!device)
        return result;

    D3D11_TEXTURE2D_DESC desc{};
    desc.Width              = static_cast<UINT>(width);
    desc.Height             = static_cast<UINT>(height);
    desc.MipLevels          = 1;
    desc.ArraySize          = 1;
    desc.Format             = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count   = 1;
    desc.Usage              = D3D11_USAGE_DEFAULT;
    desc.BindFlags          = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA sub{};
    sub.pSysMem     = rgba;
    sub.SysMemPitch = static_cast<UINT>(width) * 4u;

    ID3D11Texture2D* texture = nullptr;
    if (FAILED(device->CreateTexture2D(&desc, &sub, &texture)))
        return result;

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};
    srvDesc.Format              = desc.Format;
    srvDesc.ViewDimension       = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;

    ID3D11ShaderResourceView* srv = nullptr;
    if (FAILED(device->CreateShaderResourceView(texture, &srvDesc, &srv)))
    {
        texture->Release();
        return result;
    }

    g_TextureResources.push_back(texture);
    g_TextureSrvs.push_back(srv);

    result.id     = reinterpret_cast<ImTextureID>(srv);
    result.width  = width;
    result.height = height;
    result.valid  = true;
    return result;
}
