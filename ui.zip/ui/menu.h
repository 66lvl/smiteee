#pragma once

namespace Menu
{
    extern bool IsOpen;

    bool WantsInput();
    void Draw();
}
