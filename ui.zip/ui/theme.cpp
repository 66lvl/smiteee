#include "theme.h"
#include "../core/gamepad_input.h"
#include <Windows.h>
#include <cmath>
#include <cstdio>
#include <unordered_map>
#include <cstring>

namespace UITheme
{
    Palette palette;
    AppearanceSettings appearance;
    MenuFxSettings menuFx;
    ComfortSettings comfort;
    static ImGuiStyle s_menuStyle;
    static float s_menuScale = 1.f;
    static bool s_inMenu = false;
    static bool s_appearanceReset = false;
    static const char* s_cardTitle = nullptr;
    ImFont* fontRegular = nullptr;
    ImFont* fontTitle   = nullptr;
    ImFont* fontHeading = nullptr;
    ImFont* fontSmall   = nullptr;
    ImFont* fontBrand   = nullptr;

    static std::unordered_map<ImGuiID, float> s_anim;
    static float s_displayScale = 1.f;

    void SetDisplayScale(float scale)
    {
        if (scale < 1.f) scale = 1.f;
        if (scale > 2.5f) scale = 2.5f;
        s_displayScale = scale;
    }

    float DisplayScale() { return s_displayScale; }
    float UiScale() { return s_inMenu ? s_menuScale : 1.f; }
    float Px(float v) { return v * UiScale(); }
    void SanitizeComfort()
    {
        comfort.Scale = std::isfinite(comfort.Scale) ? fmaxf(.9f, fminf(1.5f, comfort.Scale)) : 1.f;
    }
    void BeginMenuFrame()
    {
        SanitizeComfort();
        s_menuStyle = ImGui::GetStyle();
        s_menuScale = s_displayScale * comfort.Scale;
        s_inMenu = true;
        ImGui::GetStyle().ScaleAllSizes(s_menuScale);
        ImGui::GetStyle().FontScaleMain *= comfort.Scale;
        CornerRadius = appearance.Rounding * s_menuScale;
    }
    void EndMenuFrame()
    {
        ImGui::GetStyle() = s_menuStyle;
        s_inMenu = false;
        CornerRadius = appearance.Rounding;
        // Refresh ImGui's cached font metrics after restoring the menu-only font scale.
        ImGui::PushFont(nullptr, 0.f); ImGui::PopFont();
    }

    void SameLineIfRoom(float nextLogicalWidth)
    {
        const float right=ImGui::GetWindowPos().x+ImGui::GetWindowContentRegionMax().x;
        if(ImGui::GetItemRectMax().x+ImGui::GetStyle().ItemSpacing.x+Px(nextLogicalWidth)<=right)ImGui::SameLine();
    }
    void HelpLastItem(const char* label, const char* explanation)
    {
        if(!comfort.Tooltips || !ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal | ImGuiHoveredFlags_AllowWhenDisabled))return;
        struct Tip { const char* label; const char* text; };
        static constexpr Tip tips[] = {
            {"Menu scale", "Scales menu text, controls and spacing together; does not change game resolution or HUD scale. Combined with monitor DPI. Ctrl+0 restores 100% and fits the menu."},
            {"Show setting tooltips", "Show explanations when you hover controls, including disabled controls. Important warnings remain visible without tooltips."},
            {"Visual overlay", "Master switch for the visual overlay. Disabling it keeps your per-element preferences."},
            {"Enemy Gods", "Include enemy gods in this display. Only data available on this client can be shown."},
            {"Ally Gods", "Include allied gods in the visual overlay."},
            {"Minions", "Include minions. Large groups can increase overlay work."},
            {"Jungle Camps", "Include jungle camps. Use Camp Range to limit their display distance where available."},
            {"Camp Range", "Maximum camp display distance in Unreal units (UU). 100 UU is approximately one meter."},
            {"Structures", "Include structures in the visual overlay."},
            {"Wards", "Enable ward-related display options."},
            {"Enemy Wards", "Include enemy wards when their data is available on this client."},
            {"Friendly Wards", "Include friendly wards."},
            {"Ward Vision Radius", "Draw a visual radius around wards; this does not change their actual vision."},
            {"Box", "Draw a box around each included character. Style and thickness are configured below."},
            {"Health Bar", "Draw the health bar using the available character health data."},
            {"Health bar", "Draw a health bar in the visual overlay."},
            {"Name", "Show the character name."},
            {"Distance", "Show distance to the displayed target."},
            {"Skeleton", "Draw additional bone lines. This is more expensive than a simple box."},
            {"Ability Cooldowns", "Show ability cooldown information when available on the client."},
            {"Box Mode", "Choose the box rendering style. Corner length applies to Corner Box."},
            {"Box Thickness", "Line thickness of rendered boxes in screen pixels."},
            {"Corner Length", "Length of the short edges in Corner Box style."},
            {"Max Distance", "Maximum visual display distance in Unreal units (UU). 100 UU is approximately one meter."},
            {"Visible Check", "Use the existing visibility check to filter displayed targets. It can add processing cost."},
            {"Mana Bar", "Show an additional mana bar."},
            {"Shield Bar", "Show an additional shield bar when shield data is available."},
            {"Level", "Show the character level."},
            {"Snaplines", "Draw connecting lines to included targets."},
            {"CC Indicator", "Show the existing crowd-control indicator when status data is available."},
            {"Cooldown ESP Size", "Scale the ability cooldown elements in the visual overlay, independently of menu scale."},
            {"FOV Changer", "Enable the existing camera field-of-view override. Disabling returns control to the game module."},
            {"Field of View", "Camera field of view, in degrees. This is not the targeting FOV setting."},
            {"Camera Distance", "Enable the existing camera distance override."},
            {"Arm Length", "Camera spring-arm distance in Unreal units."},
            {"Disable Arm Collision", "Disable camera-arm collision in the existing camera module; this can allow camera clipping."},
            {"Show Enemies", "Include enemies in the Cooldown Hub."},
            {"Show Team", "Include allied players in the Cooldown Hub."},
            {"Show Self", "Include your own character when team display is enabled."},
            {"Split Hubs", "Separate the cooldown display into team and enemy groups."},
            {"Transparent Background", "Remove the cooldown panel background; icons and text remain visible."},
            {"Widget Mode", "Use the existing compact cooldown widget layout."},
            {"Vertical Layout", "Arrange cooldown widgets vertically."},
            {"God Name Size", "Text size of god names in cooldown widgets; independent of menu scale."},
            {"Icon Size", "Size of cooldown icons; independent of menu scale."},
            {"God Name", "Show the god name on cooldown displays."},
            {"Ability 1", "Include the first ability slot."},
            {"Ability 2", "Include the second ability slot."},
            {"Ability 3", "Include the third ability slot."},
            {"Ability 4", "Include the fourth ability slot."},
            {"Relic", "Include the relic slot."},
            {"Team check", "Exclude teammates from the existing targeting logic."},
            {"Hard lock", "Use the existing hard-lock targeting behavior while activation conditions are met."},
            {"Priority", "Choose how the existing targeting module prioritizes eligible targets."},
            {"Field of view", "Angular targeting cone in degrees; not the camera FOV."},
            {"FOV (degrees)", "Angular targeting cone in degrees; not the camera FOV."},
            {"Smoothing", "Amount of smoothing used by the existing targeting module."},
            {"Range (meters)", "Maximum targeting range in meters."},
            {"Projectile Speed", "Projectile speed assumed by prediction, in centimeters per second."},
            {"Lead Scale", "Multiplier for the prediction lead used by the existing module."},
            {"Dynamic Smooth", "Adjust the existing dynamic smoothing setting."},
            {"Auto Recommended Speed", "Use the existing recommended projectile speed when available."},
            {"Show Speed Overlay", "Display the projectile-speed diagnostic overlay."},
            {"FOV circle", "Draw the targeting FOV indicator. This does not change targeting range."},
            {"FOV Circle", "Draw the targeting FOV indicator."},
            {"Impact marker", "Display the existing predicted impact marker."},
            {"Impact Marker", "Display the existing predicted impact marker."},
            {"Target info", "Display the existing target information overlay."},
            {"Target Info", "Display the existing target information overlay."},
            {"Enemy Familiars", "Include enemy familiars in the existing map display when their data is available."},
            {"Background opacity", "Opacity of the menu background. Does not change game rendering or HUD opacity."},
            {"Corner radius", "Rounding of menu corners, in logical pixels before menu scaling."},
            {"Corner rounding", "Rounding of menu corners."},
            {"Border contrast", "Strength of menu borders. Raise this if card boundaries are hard to see."},
            {"Particles", "Decorative effects inside the menu only. Leave off for a calmer appearance and less UI work."},
            {"Particle style", "Choose Rain, Bubbles, Snow or Mixed. Available when Particles is on."},
            {"Density", "Number of decorative menu particles. Available when Particles is on."},
            {"Speed", "Animation speed of decorative menu particles. Available when Particles is on."},
            {"Performance diagnostics (CPU)", "Enable optional CPU timing. Measurements are not GPU time or total game frame time."},
            {"Show timing overlay", "Show the CPU timing panel while the menu is closed. Timing collection must be enabled."},
            {"Retry interval", "Minimum interval between existing Auto Dagger attempts. Lower values increase request frequency."},
            {"Selection mode", "Choose a specific god or a random available god. Auto Pick only selects; it never presses Lock In."},
            {"Select when time left is at most", "Trigger threshold for your personal pick timer. Requires a valid live selection phase and timer."},
            {"Show FPS", "Show the overlay frame rate, not a separate GPU performance measurement."},
            {"Show Ping", "Show replicated PlayerState ping (approximate, around 4 ms resolution). N/A means unavailable or uninitialized."},
            {"Spectator list", "Only confirmed allied spectators are shown. Remote spectator data may not be replicated; unavailable does not mean zero."},
            {"Enable local death target cycling", "Enable before dying. Wait for the native ally-camera profile. With menu closed: LMB or ] next, [ previous, F8 restore. Only available living targets are cycled."},
            {"Refresh god list", "Refresh the local god catalog. Catalog entries do not guarantee availability in the active draft."},
            {"Print inventory", "Print the existing inventory diagnostic to the console; does not change your inventory."},
            {"Save", "Write current settings to the local configuration file. Saving is explicit; unloading does not save unsaved changes."},
            {"Save changes", "Write current settings to the local configuration file. Saving is explicit; unloading does not save unsaved changes."},
            {"Load", "Replace current settings with values from the saved local configuration."},
            {"Load profile", "Replace current settings with the saved local configuration."},
            {"Fit menu to screen", "Recenter and resize the menu to the available display area without changing settings."},
            {"Reset appearance", "Ask before resetting theme colors, opacity, rounding and borders. Menu scale and gameplay settings are kept."},
            {"Reset to defaults", "Open a confirmation dialog. Resetting does not write to disk; Save remains a separate action."},
        };
        const char* text=explanation;
        if(!text && !strcmp(label,"Enabled") && s_cardTitle){
            if(strstr(s_cardTitle,"Auto Pick"))text="Select a god near the end of your personal pick timer. Keeps manual choices, skips bans and unavailable gods, never locks in.";
            else if(strstr(s_cardTitle,"Auto Dagger"))text="Enable the existing Auto Dagger module at 499 HP or less. Paused while the menu is open or the game is unfocused.";
        }
        if(!text)for(const auto& tip:tips)if(!strcmp(label,tip.label)){text=tip.text;break;}
        if(!text)return;
        ImGui::BeginTooltip();ImGui::PushTextWrapPos(Px(330.f));
        ImGui::TextUnformatted(label);ImGui::Separator();ImGui::TextWrapped("%s",text);
        ImGui::PopTextWrapPos();ImGui::EndTooltip();
    }
    void RequestAppearanceReset() { s_appearanceReset=true; }
    void DrawAppearanceResetConfirmation()
    {
        if(s_appearanceReset){ImGui::OpenPopup("Reset appearance?##safe");s_appearanceReset=false;}
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{Px(18.f),Px(18.f)});
        ImGui::PushStyleColor(ImGuiCol_WindowBg,{palette.glassPanel.x,palette.glassPanel.y,palette.glassPanel.z,1.f});
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive,palette.bgCardHi);
        ImGui::SetNextWindowSizeConstraints({0.f,0.f},{fmaxf(1.f,ImGui::GetIO().DisplaySize.x-20.f),fmaxf(1.f,ImGui::GetIO().DisplaySize.y-20.f)});
        if(ImGui::BeginPopupModal("Reset appearance?##safe",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX()+fminf(Px(360.f),fmaxf(Px(100.f),ImGui::GetIO().DisplaySize.x-Px(60.f))));
            ImGui::TextWrapped("Reset theme colors, opacity, corner radius and borders? Menu scale, tooltips, effects and gameplay settings are kept.");
            ImGui::TextWrapped("The saved profile will NOT be overwritten. Use Save separately to keep the reset.");
            ImGui::PopTextWrapPos();ImGui::Spacing();
            if(ImGui::Button("Cancel",{Px(120.f),0.f})||ImGui::IsKeyPressed(ImGuiKey_Escape))ImGui::CloseCurrentPopup();
            ImGui::SetItemDefaultFocus();UITheme::SameLineIfRoom(190.f);
            if(ImGui::Button("Reset appearance",{Px(190.f),0.f})){appearance=AppearanceSettings{};ImGui::CloseCurrentPopup();}
            ImGui::EndPopup();
        }
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar();
    }

    void GradientRect(ImDrawList* dl, ImVec2 min, ImVec2 max, const ImVec4& top, const ImVec4& bottom, float radius, ImDrawFlags corners)
    {
        // Bounded mesh tint only: no framebuffer copy, blur pass, textures or GPU waits.
        if(max.x<=min.x||max.y<=min.y)return;
        const int first=dl->VtxBuffer.Size;
        dl->AddRectFilled(min,max,IM_COL32_WHITE,radius,corners);
        for(int i=first;i<dl->VtxBuffer.Size;i++){
            auto& v=dl->VtxBuffer[i];const float t=fmaxf(0.f,fminf(1.f,.28f*(v.pos.x-min.x)/(max.x-min.x)+.72f*(v.pos.y-min.y)/(max.y-min.y)));
            v.col=ImGui::ColorConvertFloat4ToU32({top.x+(bottom.x-top.x)*t,top.y+(bottom.y-top.y)*t,top.z+(bottom.z-top.z)*t,top.w+(bottom.w-top.w)*t});
        }
    }
    void DrawGlassRect(ImDrawList* dl, ImVec2 min, ImVec2 max,
                       const ImVec4& fill, bool accentTop, bool innerHighlight)
    {
        (void)accentTop; (void)innerHighlight;
        const float radius=fminf(Px(9.f),fminf(max.x-min.x,max.y-min.y)*.5f);
        dl->AddRectFilled(min,max,ToU32(fill),radius);
        dl->AddRect(min,max,ToU32(palette.border),radius,0,Px(1.f));
    }

    ImU32 ToU32(const ImVec4& c)
    {
        return ImGui::ColorConvertFloat4ToU32(c);
    }

    float AnimBool(const char* id, bool target, float speed)
    {
        const ImGuiID hash = ImGui::GetID(id);
        float& v = s_anim[hash];
        const float dt = ImGui::GetIO().DeltaTime;
        const float goal = target ? 1.f : 0.f;
        v += (goal - v) * fminf(1.f, dt * speed);
        return v;
    }

    static const char* IconGlyph(Icon icon)
    {
        switch (icon)
        {
        case Icon::Visuals:  return "V";
        case Icon::Combat:   return "A";
        case Icon::MapHack:  return "M";
        case Icon::Skins:    return "S";
        case Icon::Settings: return "G";
        case Icon::Target:   return "T";
        case Icon::Spark:    return "*";
        case Icon::Layers:   return "L";
        case Icon::Palette:  return "C";
        case Icon::Bolt:     return "!";
        case Icon::Save:     return "+";
        case Icon::Load:     return ">";
        case Icon::Reset:    return "x";
        case Icon::Info:     return "i";
        case Icon::Keys:     return "K";
        default:             return "?";
        }
    }

    ImVec4 IconColor(Icon icon)
    {
        (void)icon;
        return palette.accentHi;
    }

    void DrawBrandMark(ImDrawList* dl, ImVec2 c, float radius)
    {
        const ImU32 color=ToU32(palette.accent);
        const ImVec2 diamond[]={{c.x,c.y-radius},{c.x+radius,c.y},{c.x,c.y+radius},{c.x-radius,c.y}};
        dl->AddPolyline(diamond,4,color,ImDrawFlags_Closed,Px(1.f));
        const float r=radius*.38f;
        dl->AddQuadFilled({c.x,c.y-r},{c.x+r,c.y},{c.x,c.y+r},{c.x-r,c.y},color);
    }

    void DrawIcon(ImDrawList* dl, Icon icon, ImVec2 c, float size)
    {
        const float h = size * .42f, t = Px(1.2f);
        const ImU32 col = ToU32(IconColor(icon));
        auto line = [&](float x1,float y1,float x2,float y2) {
            dl->AddLine({c.x+x1*h,c.y+y1*h},{c.x+x2*h,c.y+y2*h},col,t);
        };
        switch(icon)
        {
        case Icon::Visuals:
            dl->AddEllipse(c,{h,h*.62f},col,0.f,24,t);
            dl->AddCircle(c,h*.27f,col,16,t); break;
        case Icon::Combat: case Icon::Target:
            dl->AddCircle(c,h*.68f,col,20,t);
            line(-1,0,-.4f,0);line(.4f,0,1,0);line(0,-1,0,-.4f);line(0,.4f,0,1); break;
        case Icon::MapHack:
            line(-1,-.65f,-1,.9f);line(-1,.9f,-.33f,.6f);line(-1,-.65f,-.33f,-.95f);
            line(-.33f,-.95f,-.33f,.6f);line(-.33f,.6f,.33f,.95f);line(-.33f,-.95f,.33f,-.6f);
            line(.33f,-.6f,.33f,.95f);line(.33f,.95f,1,.65f);line(.33f,-.6f,1,-.9f);line(1,-.9f,1,.65f);break;
        case Icon::Skins:
            line(-.4f,-1,-1,-.6f);line(-1,-.6f,-.7f,0);line(-.7f,0,-.45f,-.2f);
            line(-.45f,-.2f,-.45f,1);line(-.45f,1,.45f,1);line(.45f,1,.45f,-.2f);
            line(.45f,-.2f,.7f,0);line(.7f,0,1,-.6f);line(1,-.6f,.4f,-1);line(-.4f,-1,.4f,-1);break;
        case Icon::Settings:
            dl->AddCircle(c,h*.65f,col,20,t);dl->AddCircle(c,h*.23f,col,16,t);
            for(int i=0;i<8;i++){float a=i*3.14159265f/4.f;dl->AddLine({c.x+cosf(a)*h*.65f,c.y+sinf(a)*h*.65f},{c.x+cosf(a)*h,c.y+sinf(a)*h},col,t);}break;
        case Icon::Layers:
            for(int y=0;y<2;y++)for(int x=0;x<2;x++){
                const ImVec2 a={c.x-h+x*h*1.25f,c.y-h+y*h*1.25f};
                dl->AddRect(a,{a.x+h*.65f,a.y+h*.65f},col,Px(1.f),0,t);
            }break;
        case Icon::Save:
            dl->AddRect({c.x-h,c.y-h},{c.x+h,c.y+h},col,2.f,0,t);line(-.5f,-1,-.5f,-.15f);line(-.5f,-.15f,.5f,-.15f);line(.5f,-.15f,.5f,-1);line(-.5f,.4f,.5f,.4f);break;
        case Icon::Load:
            line(0,-1,0,.4f);line(-.4f,0,0,.4f);line(0,.4f,.4f,0);line(-.9f,.4f,-.9f,1);line(-.9f,1,.9f,1);line(.9f,1,.9f,.4f);break;
        case Icon::Reset:
            dl->PathArcTo(c,h,0.4f,5.6f,22);dl->PathStroke(col,0,t);line(.75f,-.65f,.1f,-.65f);line(.1f,-.65f,.1f,-1.1f);break;
        case Icon::Palette:
            dl->AddCircle(c,h,col,24,t);dl->AddCircleFilled({c.x-h*.35f,c.y-h*.3f},h*.15f,col);dl->AddCircleFilled({c.x+h*.3f,c.y-h*.3f},h*.15f,col);dl->AddCircleFilled({c.x-h*.2f,c.y+h*.35f},h*.15f,col);break;
        case Icon::Bolt: case Icon::Spark:
            line(.25f,-1,-.55f,.15f);line(-.55f,.15f,.2f,.15f);line(.2f,.15f,-.15f,1);break;
        default:
            dl->AddCircle(c,h,col,24,t);line(0,-.15f,0,.55f);dl->AddCircleFilled({c.x,c.y-h*.5f},h*.1f,col);break;
        }
    }

    void DrawIconInline(Icon icon, float size)
    {
        ImVec2 pos = ImGui::GetCursorScreenPos();
        DrawIcon(ImGui::GetWindowDrawList(), icon, { pos.x + size * 0.5f, pos.y + size * 0.5f }, size);
        ImGui::Dummy({ size + 6.f, size });
    }

    void DrawWindowChrome(ImDrawList* dl, ImVec2 p, ImVec2 sz, float sidebarW)
    {
        const ImVec2 m={p.x+sz.x,p.y+sz.y};
        dl->AddRectFilled({p.x,p.y+Px(8.f)},{m.x,m.y+Px(8.f)},IM_COL32(0,0,0,32),CornerRadius);
        dl->AddRectFilled(p,m,ToU32(palette.bgDeep),CornerRadius);
        dl->AddRectFilled(p,{p.x+sidebarW,m.y},ToU32(palette.bgSidebar),CornerRadius,ImDrawFlags_RoundCornersLeft);
        dl->AddLine({p.x+sidebarW,p.y},{p.x+sidebarW,m.y},ToU32(palette.border),Px(1.f));
        dl->AddLine({p.x+sidebarW,p.y+Px(62.f)},{m.x,p.y+Px(62.f)},ToU32(palette.border),Px(1.f));
    }

    void DrawMenuOutline(ImDrawList* dl, ImVec2 min, ImVec2 max)
    {
        dl->AddRect(min,max,ToU32(palette.borderHi),CornerRadius,0,1.f);
    }

    void PushMenuClip(ImVec2 wpos, ImVec2 wsize)
    {
        const float pad = 1.f;
        ImGui::PushClipRect(
            { wpos.x + pad, wpos.y + pad },
            { wpos.x + wsize.x - pad, wpos.y + wsize.y - pad },
            true);
    }

    void PopMenuClip()
    {
        ImGui::PopClipRect();
    }

    void LoadFonts()
    {
        ImGuiIO& io = ImGui::GetIO();
        io.Fonts->Clear();

        ImFontConfig cfg{};
        cfg.OversampleH = 2;
        cfg.OversampleV = 1; // Density already pre-bakes the maximum menu scale.
        cfg.PixelSnapH = false;
        cfg.RasterizerDensity = s_displayScale * 1.5f;

        // The approved mockups use Arial, not Segoe UI or Apple's SF Pro.
        // Check files before calling ImGui: absent fonts must not trigger its assert.
        auto load = [&](const char* primary, const char* fallback, float size) -> ImFont* {
            ImFontConfig face = cfg;
            face.SizePixels = size;
            const char* paths[] = { primary, fallback };
            for (const char* path : paths) {
                FILE* file = nullptr;
                if (fopen_s(&file, path, "rb") != 0 || !file) continue;
                fclose(file);
                if (ImFont* font = io.Fonts->AddFontFromFileTTF(path, size, &face)) return font;
            }
            return io.Fonts->AddFontDefault(&face);
        };

        fontRegular = load("C:\\Windows\\Fonts\\arial.ttf", "C:\\Windows\\Fonts\\segoeui.ttf", 16.f);
        fontTitle   = load("C:\\Windows\\Fonts\\arialbd.ttf", "C:\\Windows\\Fonts\\segoeuib.ttf", 36.f);
        fontHeading = load("C:\\Windows\\Fonts\\arialbd.ttf", "C:\\Windows\\Fonts\\segoeuib.ttf", 18.f);
        fontBrand   = load("C:\\Windows\\Fonts\\arialbd.ttf", "C:\\Windows\\Fonts\\segoeuib.ttf", 18.f);
        fontSmall   = load("C:\\Windows\\Fonts\\arial.ttf", "C:\\Windows\\Fonts\\segoeui.ttf", 14.f);
        io.FontDefault = fontRegular;
    }

    void ApplyGlobalStyle()
    {
        ImGui::StyleColorsDark();
        ImGuiStyle& s = ImGui::GetStyle();

        s.FontScaleDpi = s_displayScale;
        s.AntiAliasedLines = true;
        s.AntiAliasedFill  = true;

        s.WindowRounding     = CornerRadius;
        s.ChildRounding      = 9.f;
        s.FrameRounding      = 6.f;
        s.PopupRounding      = 8.f;
        s.ScrollbarRounding  = CornerRadius;
        s.GrabRounding       = CornerRadius;

        s.WindowBorderSize   = 0.f;
        s.FrameBorderSize    = 1.f;
        s.ChildBorderSize    = 1.f;

        s.WindowPadding      = { 12.f, 12.f };
        s.FramePadding       = { 9.f, 6.f };
        s.ItemSpacing        = { 10.f, 7.f };
        s.ItemInnerSpacing   = { 6.f, 4.f };
        s.CellPadding        = { 9.f, 0.f };
        s.ScrollbarSize      = 6.f;
        s.DisabledAlpha      = .70f;
        s.GrabMinSize        = 8.f;

        RefreshAppearance();
    }

    static float SafeRange(float v, float lo, float hi, float fallback)
    {
        return std::isfinite(v) ? fmaxf(lo, fminf(hi, v)) : fallback;
    }

    void ApplyAppearancePreset(int preset)
    {
        const AppearanceSettings previous=appearance;
        appearance = AppearanceSettings{};
        appearance.Opacity=previous.Opacity;appearance.Rounding=previous.Rounding;appearance.BorderStrength=previous.BorderStrength;
        appearance.Preset = preset >= 0 && preset <= 4 ? preset : 4;
        switch (appearance.Preset)
        {
        case 0:
            appearance.Accent = { .451f, .678f, .953f, 1.f };
            appearance.Background = { .082f, .129f, .176f, 1.f };
            appearance.Surface = { .141f, .220f, .294f, 1.f };
            appearance.Sidebar = { .110f, .188f, .259f, 1.f };
            break;
        case 1:
            appearance.Accent={.718f,.635f,1.f,1.f};appearance.Background={.082f,.098f,.161f,1.f};
            appearance.Surface={.133f,.153f,.227f,1.f};appearance.Sidebar={.102f,.118f,.188f,1.f};break;
        case 2:
            appearance.Accent = { 0.30f, 0.82f, 0.64f, 1.f };
            appearance.Background = { 0.045f, 0.085f, 0.08f, 1.f };
            appearance.Surface = { 0.075f, 0.14f, 0.125f, 1.f };
            appearance.Sidebar = { 0.055f, 0.105f, 0.095f, 1.f };
            break;
        case 3:
            appearance.Accent = { 0.76f, 0.79f, 0.84f, 1.f };
            appearance.Background = { 0.075f, 0.08f, 0.09f, 1.f };
            appearance.Surface = { 0.13f, 0.14f, 0.16f, 1.f };
            appearance.Sidebar = { 0.095f, 0.10f, 0.115f, 1.f };
            break;
        default: break;
        }
    }

    void RefreshAppearance()
    {
        appearance.Opacity = SafeRange(appearance.Opacity, 0.65f, 1.f, 1.f);
        appearance.Rounding = SafeRange(appearance.Rounding, 0.f, 32.f, 14.f);
        appearance.BorderStrength = SafeRange(appearance.BorderStrength, 0.05f, 0.45f, 0.18f);
        if (appearance.Preset < 0 || appearance.Preset > 4) appearance.Preset = 4;
        auto clean = [](ESP::Color4& c) {
            c.r = SafeRange(c.r, 0.f, 1.f, 0.5f);
            c.g = SafeRange(c.g, 0.f, 1.f, 0.5f);
            c.b = SafeRange(c.b, 0.f, 1.f, 0.5f);
            c.a = 1.f;
        };
        clean(appearance.Accent); clean(appearance.Background);
        clean(appearance.Surface); clean(appearance.Sidebar); clean(appearance.Text);
        auto rgba = [](const ESP::Color4& c, float alpha) { return ImVec4(c.r, c.g, c.b, alpha); };
        auto mix = [](ImVec4 a, ImVec4 b, float t) {
            return ImVec4(a.x+(b.x-a.x)*t, a.y+(b.y-a.y)*t,
                          a.z+(b.z-a.z)*t, a.w+(b.w-a.w)*t);
        };
        const float o = appearance.Opacity;
        palette.accent = rgba(appearance.Accent, 1.f);
        palette.accentHi = mix(palette.accent, ImVec4(1,1,1,1), 0.18f);
        palette.accentSoft = rgba(appearance.Accent, 0.16f);
        palette.accentLine = rgba(appearance.Accent, 0.6f);
        palette.glassDeep = rgba(appearance.Background, o);
        palette.glassPanel = rgba(appearance.Surface, o);
        palette.glassCard = rgba(appearance.Surface, o);
        palette.glassSidebar = rgba(appearance.Sidebar, o);
        palette.glassHover = rgba(appearance.Accent, 0.12f);
        palette.bgDeep = palette.glassDeep;
        palette.bgPanel = palette.glassPanel;
        palette.bgCard = palette.glassCard;
        palette.bgSidebar = palette.glassSidebar;
        palette.bgCardHi = mix(rgba(appearance.Surface, 1.f), palette.accent, 0.055f);
        palette.text = rgba(appearance.Text, 1.f);
        palette.textDim = mix(palette.text, rgba(appearance.Surface, 1.f), 0.31f);
        palette.border = mix(rgba(appearance.Surface, 1.f), palette.text, appearance.BorderStrength * .63f);
        palette.borderHi = mix(rgba(appearance.Surface, 1.f), palette.text, appearance.BorderStrength * .92f);
        palette.lineHard = palette.borderHi;
        palette.lineSoft = palette.border;
        CornerRadius = appearance.Rounding;
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = CornerRadius;
        style.ChildRounding = fminf(CornerRadius, 9.f);
        style.FrameRounding = fminf(CornerRadius, 6.f);
        style.PopupRounding = fminf(CornerRadius, 8.f);
        style.ScrollbarRounding = style.GrabRounding = fminf(CornerRadius, 6.f);
        ImVec4* c = ImGui::GetStyle().Colors;
        c[ImGuiCol_TitleBg] = palette.bgSidebar;
        c[ImGuiCol_TitleBgActive] = palette.accentSoft;
        c[ImGuiCol_TitleBgCollapsed] = palette.bgSidebar;
        c[ImGuiCol_Text]                 = palette.text;
        c[ImGuiCol_TextDisabled]         = palette.textDim;
        c[ImGuiCol_WindowBg]             = { 0.f, 0.f, 0.f, 0.f };
        c[ImGuiCol_ChildBg]              = { 0.f, 0.f, 0.f, 0.f };
        c[ImGuiCol_PopupBg]              = { palette.glassPanel.x, palette.glassPanel.y, palette.glassPanel.z, 1.f };
        c[ImGuiCol_Border]               = palette.border;
        c[ImGuiCol_FrameBg]              = palette.bgCardHi;
        c[ImGuiCol_FrameBgHovered]       = palette.glassHover;
        c[ImGuiCol_FrameBgActive]        = palette.accentSoft;
        c[ImGuiCol_ScrollbarBg]          = palette.glassSidebar;
        c[ImGuiCol_ScrollbarGrab]        = palette.borderHi;
        c[ImGuiCol_ScrollbarGrabHovered] = palette.accentHi;
        c[ImGuiCol_ScrollbarGrabActive]  = palette.accent;
        c[ImGuiCol_CheckMark]            = palette.accentHi;
        c[ImGuiCol_TextSelectedBg]       = palette.accentSoft;
        c[ImGuiCol_SliderGrab]           = palette.accent;
        c[ImGuiCol_SliderGrabActive]     = palette.accentHi;
        c[ImGuiCol_Button]               = palette.bgCardHi;
        c[ImGuiCol_ButtonHovered]        = palette.glassHover;
        c[ImGuiCol_ButtonActive]         = palette.accentSoft;
        c[ImGuiCol_Header]               = palette.bgCardHi;
        c[ImGuiCol_HeaderHovered]        = palette.glassHover;
        c[ImGuiCol_HeaderActive]         = palette.accentSoft;
        c[ImGuiCol_Separator]            = palette.border;
        c[ImGuiCol_ResizeGrip]           = palette.accentSoft;
        c[ImGuiCol_ResizeGripHovered]    = palette.accent;
        c[ImGuiCol_ResizeGripActive]     = palette.accentHi;
    }

    static bool AppearanceColor(const char* label, ESP::Color4& color)
    {
        ImGui::PushID(label);
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(label);
        ImGui::SameLine();
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + fmaxf(0.f, ImGui::GetContentRegionAvail().x - 30.f));
        ImGui::SetNextItemWidth(30.f);
        float c[3] = { color.r, color.g, color.b };
        const bool changed = ImGui::ColorEdit3("##rgb", c, ImGuiColorEditFlags_NoInputs);
        if (changed) color = { c[0], c[1], c[2], 1.f };
        ImGui::PopID();
        return changed;
    }

    void DrawAppearanceSettings()
    {
        BeginCard("cfg_appearance", Icon::Palette, "Appearance", "Live preview. Use Save below to keep your changes.");
        const char* presets[] = { "Ocean", "Violet", "Emerald", "Graphite", "Midnight" };
        int selected = appearance.Preset;
        if (ComboRow("Theme preset (resets custom colors)", &selected, presets, 5))
            ApplyAppearancePreset(selected);
        ImGui::Spacing();
        if (ImGui::BeginTable("appearance_colors", 2, ImGuiTableFlags_SizingStretchSame))
        {
            ImGui::TableNextColumn(); AppearanceColor("Accent", appearance.Accent);
            ImGui::TableNextColumn(); AppearanceColor("Background", appearance.Background);
            ImGui::TableNextColumn(); AppearanceColor("Cards & controls", appearance.Surface);
            ImGui::TableNextColumn(); AppearanceColor("Sidebar", appearance.Sidebar);
            ImGui::TableNextColumn(); AppearanceColor("Text", appearance.Text);
            ImGui::EndTable();
        }
        ImGui::Spacing();
        SliderFloatRow("Background opacity", &appearance.Opacity, 0.65f, 1.f, "%.2f");
        SliderFloatRow("Corner rounding", &appearance.Rounding, 0.f, 32.f, "%.0f px");
        SliderFloatRow("Border contrast", &appearance.BorderStrength, 0.05f, 0.45f, "%.2f");
        if (ActionButton("reset_appearance", Icon::Reset, "Reset appearance", palette.accent, { 190.f, 32.f }))
            RequestAppearanceReset();
        EndCard();
    }

    void PushRegular() { if (fontRegular) ImGui::PushFont(fontRegular); }
    void PopRegular()  { if (fontRegular) ImGui::PopFont(); }

    bool NavButton(const char* id, Icon icon, const char* label, bool active)
    {
        ImGui::PushID(id);
        const ImVec2 p=ImGui::GetCursorScreenPos();
        const float w=ImGui::GetContentRegionAvail().x,h=Px(48.f);
        const bool clicked=ImGui::InvisibleButton("##nav",{w,h},ImGuiButtonFlags_EnableNav);
        auto* dl=ImGui::GetWindowDrawList();
        if(active||ImGui::IsItemHovered()){
            dl->AddRectFilled(p,{p.x+w,p.y+h},ToU32(active?palette.accentSoft:palette.glassHover),Px(6.f));
            if(active)dl->AddRect(p,{p.x+w,p.y+h},ToU32(palette.borderHi),Px(6.f));
        }
        const ImVec4 old=palette.accentHi;palette.accentHi=active?palette.accent:palette.textDim;
        DrawIcon(dl,icon,{p.x+Px(24.f),p.y+h*.5f},Px(18.f));palette.accentHi=old;
        dl->AddText({p.x+Px(46.f),p.y+(h-ImGui::GetFontSize())*.5f},ToU32(active?palette.text:palette.textDim),label);
        if(active)dl->AddCircleFilled({p.x+w-Px(16.f),p.y+h*.5f},Px(2.5f),ToU32(palette.accent));
        if(ImGui::IsItemFocused())dl->AddRect(p,{p.x+w,p.y+h},ToU32(palette.accent),Px(6.f));
        ImGui::PopID();return clicked;
    }

    struct SwitchVisual
    {
        float Position;
        float Stretch;
    };

    static SwitchVisual AdvanceSwitchAnimation(const char* id, bool target)
    {
        // Window/context-owned state: no global pointer cache or background timer.
        ImGui::PushID(id);
        const ImGuiID positionKey = ImGui::GetID("position");
        const ImGuiID fromKey = ImGui::GetID("from");
        const ImGuiID elapsedKey = ImGui::GetID("elapsed");
        const ImGuiID targetKey = ImGui::GetID("target");
        const ImGuiID frameKey = ImGui::GetID("frame");
        ImGui::PopID();
        ImGuiStorage* storage = ImGui::GetStateStorage();
        const int frame = ImGui::GetFrameCount();
        const int lastFrame = storage->GetInt(frameKey, -1);
        const float goal = target ? 1.f : 0.f;
        float position = storage->GetFloat(positionKey, goal);
        float from = storage->GetFloat(fromKey, goal);
        float elapsed = storage->GetFloat(elapsedKey, .42f);
        if (lastFrame < 0 || lastFrame < frame - 1)
        {
            // Opening a page must not animate every already-enabled setting.
            position = from = goal;
            elapsed = .42f;
        }
        else if (storage->GetInt(targetKey, target ? 1 : 0) != (target ? 1 : 0))
        {
            // Reversing mid-flight starts from the current visual position.
            from = position;
            elapsed = 0.f;
        }
        if (lastFrame != frame)
        {
            const float dt = ImGui::GetIO().DeltaTime;
            if (std::isfinite(dt) && dt > 0.f) elapsed = fminf(.42f, elapsed + dt);
        }
        const float progress = fmaxf(0.f, fminf(1.f, elapsed / .42f));
        const float remaining = 1.f - progress;
        position = from + (goal - from) * (1.f - remaining * remaining * remaining);
        const float stretch = progress < 1.f
            ? sinf(progress * 3.14159265f) * fabsf(goal - from) : 0.f;
        storage->SetFloat(positionKey, position);
        storage->SetFloat(fromKey, from);
        storage->SetFloat(elapsedKey, elapsed);
        storage->SetInt(targetKey, target ? 1 : 0);
        storage->SetInt(frameKey, frame);
        return { position, stretch };
    }

    static void DrawSmoothSwitch(const char* id, bool value, ImVec2 p, float width, float height)
    {
        const SwitchVisual visual = AdvanceSwitchAnimation(id, value);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec4 track = { .204f, .255f, .322f, 1.f };
        track.x += (palette.accent.x - track.x) * visual.Position;
        track.y += (palette.accent.y - track.y) * visual.Position;
        track.z += (palette.accent.z - track.z) * visual.Position;
        dl->AddRectFilled(p, { p.x + width, p.y + height }, ImGui::GetColorU32(track), height * .5f);
        const float radius = height * .5f - Px(3.f);
        const float stretch = Px(1.f) * visual.Stretch;
        const float centerX = p.x + height * .5f + (width - height) * visual.Position;
        const float centerY = p.y + height * .5f;
        // A tiny thumb shadow and subtle deformation; deliberately no click ripple.
        dl->AddRectFilled({ centerX - radius - stretch, centerY - radius + Px(1.f) },
            { centerX + radius + stretch, centerY + radius + Px(1.f) },
            ImGui::GetColorU32(ImVec4{ .03f, .06f, .12f, .18f }), radius);
        dl->AddRectFilled({ centerX - radius - stretch, centerY - radius + stretch * .25f },
            { centerX + radius + stretch, centerY + radius - stretch * .25f },
            ImGui::GetColorU32(ImVec4{ .65f+.29f*visual.Position, .71f+.25f*visual.Position, .79f+.21f*visual.Position, 1.f }), radius);
    }

    bool ToggleSwitch(const char* id, bool* value, float width)
    {
        const ImVec2 p=ImGui::GetCursorScreenPos();const float h=Px(19.f);
        width=Px(width);
        const bool changed=ImGui::InvisibleButton(id,{width,h},ImGuiButtonFlags_EnableNav);if(changed)*value=!*value;
        DrawSmoothSwitch(id, *value, p, width, h);
        return changed;
    }

    void FeatureMaster(Icon icon, const char* title, const char* subtitle, bool* enabled)
    {
        ImGui::PushID(title);
        const float w = ImGui::GetContentRegionAvail().x;
        const ImVec2 pos = ImGui::GetCursorScreenPos();
        const float textW = fmaxf(Px(60.f), w-Px(enabled?110.f:60.f));
        float subH=0.f;
        if(subtitle){if(fontSmall)ImGui::PushFont(fontSmall);subH=ImGui::CalcTextSize(subtitle,nullptr,false,textW).y;if(fontSmall)ImGui::PopFont();}
        const float h=Px(subtitle?48.f:56.f)+subH;
        auto* dl=ImGui::GetWindowDrawList();
        DrawGlassRect(dl,pos,{pos.x+w,pos.y+h},palette.glassCard,true);
        DrawIcon(dl,icon,{pos.x+Px(22.f),pos.y+h*.5f},Px(18.f));
        ImGui::SetCursorScreenPos({pos.x+Px(42.f),pos.y+Px(12.f)});
        if(fontBrand)ImGui::PushFont(fontBrand);ImGui::TextUnformatted(title);if(fontBrand)ImGui::PopFont();
        if(subtitle){ImGui::SetCursorScreenPos({pos.x+Px(42.f),pos.y+Px(35.f)});ImGui::PushTextWrapPos(ImGui::GetCursorPosX()+textW);InfoText(subtitle);ImGui::PopTextWrapPos();}
        if(enabled){ImGui::SetCursorScreenPos({pos.x+w-Px(52.f),pos.y+(h-Px(22.f))*.5f});ToggleSwitch("##master",enabled,40.f);HelpLastItem(title);}
        ImGui::SetCursorScreenPos({pos.x,pos.y+h});ImGui::Dummy({w,Px(8.f)});
        ImGui::PopID();
    }

    void BeginCard(const char* id, Icon icon, const char* title, const char* subtitle, float minHeight)
    {
        (void)icon; (void)minHeight;
        s_cardTitle=title;
        ImGui::PushID(id);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {Px(4.f),Px(4.f)});
        ImGui::BeginChild("##module_card", {0.f,0.f}, ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar);
        if(title) { ImGui::TextUnformatted(title); ImGui::Spacing(); }
        if(subtitle) { ImGui::TextWrapped("%s", subtitle); }

    }

    void EndCard()
    {
        ImGui::EndChild(); ImGui::PopStyleVar(); ImGui::PopID(); s_cardTitle=nullptr; ImGui::Spacing();
    }

    void InfoText(const char* text)
    {
        ImGui::PushStyleColor(ImGuiCol_Text, palette.textDim);
        if (fontSmall) ImGui::PushFont(fontSmall);
        ImGui::TextWrapped("%s", text);
        if (fontSmall) ImGui::PopFont();
        ImGui::PopStyleColor();
    }

    void Badge(const char* text, const ImVec4& color, bool pulse)
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        if (fontSmall) ImGui::PushFont(fontSmall);
        ImVec2 ts = ImGui::CalcTextSize(text);
        if (fontSmall) ImGui::PopFont();

        const float padX = 8.f, padY = 3.f;
        const ImVec2 size = { ts.x + padX * 2.f, ts.y + padY * 2.f };
        float alpha = pulse ? (0.70f + 0.30f * (0.5f + 0.5f * sinf((float)ImGui::GetTime() * 2.8f))) : 1.f;

        dl->AddRectFilled(pos, { pos.x + size.x, pos.y + size.y },
                          ToU32({ color.x, color.y, color.z, 0.10f * alpha }), CornerRadius);
        dl->AddRect(pos, { pos.x + size.x, pos.y + size.y },
                    ToU32({ color.x, color.y, color.z, 0.55f * alpha }), CornerRadius, 0, 1.f);
        ImGui::Dummy(size);
        ImGui::SetCursorScreenPos({ pos.x + padX, pos.y + padY });
        if (fontSmall) ImGui::PushFont(fontSmall);
        ImGui::TextColored({ color.x, color.y, color.z, alpha }, "%s", text);
        if (fontSmall) ImGui::PopFont();
        ImGui::SetCursorScreenPos({ pos.x, pos.y + size.y + ImGui::GetStyle().ItemSpacing.y });
    }

    bool SliderFloatRow(const char* label, float* v, float min, float max, const char* fmt)
    {
        ImGui::PushID(label); ImGui::TextUnformatted(label); HelpLastItem(label);
        const float width=fmaxf(Px(50.f),fminf(Px(250.f),ImGui::GetContentRegionAvail().x));
        ImGui::SetNextItemWidth(width);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive,ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_SliderGrab,ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,ImVec4(0,0,0,0));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize,0.f);
        const bool changed=ImGui::SliderFloat("##slider",v,min,max,"",ImGuiSliderFlags_AlwaysClamp);
        ImGui::PopStyleVar();
        const ImVec2 a=ImGui::GetItemRectMin(), b=ImGui::GetItemRectMax();
        auto* dl=ImGui::GetWindowDrawList(); float y=a.y+Px(3.f);
        dl->AddRectFilled({a.x,y},{b.x,y+Px(7.f)},IM_COL32(7,7,7,255));
        dl->AddRectFilled({a.x+Px(1.f),y+Px(1.f)},{b.x-Px(1.f),y+Px(6.f)},IM_COL32(65,65,65,255));
        const float t=fmaxf(0.f,fminf(1.f,(*v-min)/(max-min)));
        dl->AddRectFilled({a.x+Px(1.f),y+Px(1.f)},{a.x+Px(1.f)+(b.x-a.x-Px(2.f))*t,y+Px(6.f)},ToU32(palette.accent));
        char buf[80];snprintf(buf,sizeof(buf),fmt,*v);const float tw=ImGui::CalcTextSize(buf).x;
        dl->AddText({fmaxf(a.x,fminf(b.x-tw,a.x+(b.x-a.x)*t-tw*.5f)),y+Px(6.f)},ImGui::GetColorU32(ImGuiCol_Text),buf);
        HelpLastItem(label);ImGui::PopStyleColor(5); ImGui::Dummy({0.f,Px(5.f)}); ImGui::PopID();return changed;
    }

    bool ComboRow(const char* label, int* current, const char* const* items, int count)
    {
        ImGui::PushID(label);ImGui::TextUnformatted(label);HelpLastItem(label);
        ImGui::SetNextItemWidth(fmaxf(Px(50.f),fminf(Px(250.f),ImGui::GetContentRegionAvail().x)));
        const bool changed=ImGui::Combo("##combo",current,items,count);HelpLastItem(label);ImGui::PopID();return changed;
    }

    bool CheckboxRow(const char* label, bool* value)
    {
        ImGui::PushID(label);
        const ImVec2 p=ImGui::GetCursorScreenPos();
        const float box=Px(9.f), height=fmaxf(ImGui::GetTextLineHeight(),box)+Px(3.f);
        const float width=ImGui::GetContentRegionAvail().x;
        bool changed=ImGui::InvisibleButton("##check",{width,height},ImGuiButtonFlags_EnableNav);
        if(changed)*value=!*value;
        auto* dl=ImGui::GetWindowDrawList(); const float y=p.y+(height-box)*.5f;
        dl->AddRectFilled({p.x,y},{p.x+box,p.y+(height+box)*.5f},IM_COL32(8,8,8,255));
        dl->AddRectFilled({p.x+Px(1.f),y+Px(1.f)},{p.x+box-Px(1.f),y+box-Px(1.f)},*value?ToU32(palette.accent):IM_COL32(52,52,52,255));
        dl->AddText({p.x+Px(19.f),p.y+(height-ImGui::GetTextLineHeight())*.5f},ImGui::GetColorU32(ImGuiCol_Text),label);
        HelpLastItem(label);ImGui::PopID();return changed;
    }

    void ColorEditRow(const char* label, ESP::Color4& col)
    {
        ImGui::PushID(label);ImGui::AlignTextToFramePadding();ImGui::TextUnformatted(label);
        ImGui::SameLine();ImGui::SetCursorPosX(ImGui::GetCursorPosX()+fmaxf(0.f,ImGui::GetContentRegionAvail().x-Px(32.f)));
        float c[4]={col.r,col.g,col.b,col.a};
        if(ImGui::ColorEdit4("##color",c,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_AlphaPreviewHalf))
            col={c[0],c[1],c[2],c[3]};
        HelpLastItem(label, "Choose the display color. This changes appearance only.");
        ImGui::PopID();
    }

    bool KeybindButton(const char* id, int* key)
    {
        static bool capturing = false;
        static int* captureTarget = nullptr;

        char kname[32] = {};
        if (*key == VK_XBUTTON1) strcpy_s(kname, "M4");
        else if (*key == VK_XBUTTON2) strcpy_s(kname, "M5");
        else if (*key == VK_LBUTTON) strcpy_s(kname, "LMB");
        else if (*key == VK_RBUTTON) strcpy_s(kname, "RMB");
        else if (*key == VK_MBUTTON) strcpy_s(kname, "MMB");
        else GetKeyNameTextA(MapVirtualKeyA(*key, MAPVK_VK_TO_VSC) << 16, kname, sizeof(kname));

        char buf[64];
        snprintf(buf, sizeof(buf), "%s##kb_%s", kname[0] ? kname : "...", id);

        ImGui::PushStyleColor(ImGuiCol_Button, palette.bgCardHi);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, { 1.f, 1.f, 1.f, 0.06f });
        ImGui::PushStyleColor(ImGuiCol_Border, palette.border);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.f);
        const bool clicked = ImGui::Button(buf, { Px(90.f), fmaxf(Px(34.f), ImGui::GetFrameHeight()) });
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(3);

        if (clicked) { capturing = true; captureTarget = key; }

        if (capturing && captureTarget == key)
        {
            ImGui::SameLine();
            ImGui::TextColored(palette.warning, "Press key...");
            for (int vk = 1; vk < 256; vk++)
            {
                if (GetAsyncKeyState(vk) & 0x8000)
                {
                    if (vk == VK_ESCAPE) { capturing = false; return false; }
                    *key = vk;
                    capturing = false;
                    return true;
                }
            }
        }
        return false;
    }

    bool BindButton(const char* id, int* bindType, int* key, int* padDevice, int* padButton,
                    bool allowUnbound, float width)
    {
        static bool capturing = false;
        static int* capType = nullptr;
        static int* capKey = nullptr;
        static int* capPadDevice = nullptr;
        static int* capPadButton = nullptr;

        char label[96] = "...";
        if (*bindType == 0)
        {
            if (allowUnbound && *key == 0)
            {
                strcpy_s(label, "None");
            }
            else
            {
                char kname[32] = {};
                if (*key == VK_XBUTTON1) strcpy_s(kname, "M4");
                else if (*key == VK_XBUTTON2) strcpy_s(kname, "M5");
                else if (*key == VK_LBUTTON) strcpy_s(kname, "LMB");
                else if (*key == VK_RBUTTON) strcpy_s(kname, "RMB");
                else if (*key == VK_MBUTTON) strcpy_s(kname, "MMB");
                else GetKeyNameTextA(MapVirtualKeyA(*key, MAPVK_VK_TO_VSC) << 16, kname, sizeof(kname));
                if (kname[0])
                    strcpy_s(label, kname);
            }
        }
        else
        {
            GamepadInput::FormatBindingLabel(
                *padDevice,
                static_cast<GamepadInput::Button>(*padButton),
                label, sizeof(label));
        }

        char buf[128];
        snprintf(buf, sizeof(buf), "[%s]##bind_%s", label, id);

        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, { 1.f, 1.f, 1.f, 0.06f });
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0,0,0,0));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.f);
        const bool clicked = ImGui::Button(buf, { fminf(Px(width>0.f?width:80.f),ImGui::GetContentRegionAvail().x), ImGui::GetFrameHeight() });
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(3);

        HelpLastItem(id,"Click to capture a keyboard, mouse or controller binding. Escape cancels. Delete/Backspace clears optional bindings.");
        if (clicked)
        {
            capturing = true;
            capType = bindType;
            capKey = key;
            capPadDevice = padDevice;
            capPadButton = padButton;
        }

        if (capturing && capType == bindType && capKey == key &&
            capPadDevice == padDevice && capPadButton == padButton)
        {
            if (allowUnbound)
                ImGui::TextWrapped("Press key/button (Del = clear)...");
            else
                ImGui::TextColored(palette.warning, "Press key or button...");

            if (allowUnbound &&
                ((GetAsyncKeyState(VK_DELETE) & 0x8000) ||
                 (GetAsyncKeyState(VK_BACK) & 0x8000)))
            {
                *bindType = 0;
                *key = 0;
                *padDevice = 0;
                *padButton = 0;
                capturing = false;
                return true;
            }

            int devId = 0;
            GamepadInput::Button padBtn = GamepadInput::Button::LT;
            if (GamepadInput::CaptureAnyButton(&devId, &padBtn))
            {
                *bindType = 1;
                *padDevice = devId;
                *padButton = static_cast<int>(padBtn);
                capturing = false;
                return true;
            }

            for (int vk = 1; vk < 256; vk++)
            {
                if (GetAsyncKeyState(vk) & 0x8000)
                {
                    if (vk == VK_ESCAPE) { capturing = false; return false; }
                    *bindType = 0;
                    *key = vk;
                    capturing = false;
                    return true;
                }
            }
        }
        return false;
    }

    bool ActionButton(const char* id, Icon icon, const char* label,
                      const ImVec4& color, ImVec2 size)
    {
        (void)icon; (void)color; ImGui::PushID(id);
        if(size.x<=0.f)size.x=130.f;
        const float w=fminf(ImGui::GetContentRegionAvail().x,Px(size.x));
        bool result=ImGui::Button(label,{w,ImGui::GetFrameHeight()});HelpLastItem(label);ImGui::PopID();return result;
    }

    namespace
    {
        enum class PKind : int { Rain = 0, Bubble, Snow };

        struct MenuParticle
        {
            float x, y;
            float vx, vy;
            float size;
            float alpha;
            float phase;
            PKind kind;
        };

        static MenuParticle s_parts[140];
        static int   s_partCount   = 0;
        static ImVec2 s_partAreaMin{};
        static ImVec2 s_partAreaMax{};
        static bool  s_partsReady  = false;
        static int   s_lastMode    = -1;

        static float Rand01(int seed)
        {
            seed = (seed * 1103515245 + 12345) & 0x7fffffff;
            return (float)(seed & 0xffff) / 65535.f;
        }

        static bool PointInRoundRect(ImVec2 p, ImVec2 min, ImVec2 max, float r)
        {
            if (p.x < min.x || p.y < min.y || p.x > max.x || p.y > max.y)
                return false;

            const float r2 = r * r;
            if (p.x < min.x + r && p.y < min.y + r)
            {
                const float dx = p.x - (min.x + r);
                const float dy = p.y - (min.y + r);
                return dx * dx + dy * dy <= r2;
            }
            if (p.x > max.x - r && p.y < min.y + r)
            {
                const float dx = p.x - (max.x - r);
                const float dy = p.y - (min.y + r);
                return dx * dx + dy * dy <= r2;
            }
            if (p.x > max.x - r && p.y > max.y - r)
            {
                const float dx = p.x - (max.x - r);
                const float dy = p.y - (max.y - r);
                return dx * dx + dy * dy <= r2;
            }
            if (p.x < min.x + r && p.y > max.y - r)
            {
                const float dx = p.x - (min.x + r);
                const float dy = p.y - (max.y - r);
                return dx * dx + dy * dy <= r2;
            }
            return true;
        }

        static PKind ResolveKind(int mode, int index)
        {
            if (mode == 0) return PKind::Rain;
            if (mode == 1) return PKind::Bubble;
            if (mode == 2) return PKind::Snow;
            return (PKind)(index % 3);
        }

        static void SpawnParticle(MenuParticle& p, ImVec2 min, ImVec2 max,
                                  int mode, int index, bool randomY)
        {
            const float w = max.x - min.x;
            const float h = max.y - min.y;
            p.kind  = ResolveKind(mode, index);
            p.phase = Rand01(index * 17 + 3) * 6.28318f;
            p.x     = min.x + Rand01(index * 31 + 7) * w;
            p.y     = randomY ? (min.y + Rand01(index * 13 + 5) * h)
                              : min.y - Rand01(index * 19 + 1) * 48.f;

            switch (p.kind)
            {
            case PKind::Rain:
                p.size  = 0.8f + Rand01(index * 41) * 1.4f;
                p.vx    = -10.f + Rand01(index * 43) * 20.f;
                p.vy    = 95.f + Rand01(index * 47) * 130.f;
                p.alpha = 0.10f + Rand01(index * 53) * 0.24f;
                break;
            case PKind::Bubble:
                p.size  = 2.f + Rand01(index * 59) * 5.f;
                p.vx    = -14.f + Rand01(index * 61) * 28.f;
                p.vy    = -(20.f + Rand01(index * 67) * 34.f);
                p.alpha = 0.08f + Rand01(index * 71) * 0.20f;
                break;
            case PKind::Snow:
            default:
                p.size  = 1.f + Rand01(index * 73) * 2.2f;
                p.vx    = -14.f + Rand01(index * 79) * 28.f;
                p.vy    = 24.f + Rand01(index * 83) * 42.f;
                p.alpha = 0.12f + Rand01(index * 89) * 0.30f;
                break;
            }
        }

        static void EnsureParticles(ImVec2 min, ImVec2 max, int mode, float density)
        {
            if (s_lastMode != mode)
            {
                s_partsReady = false;
                s_lastMode = mode;
            }

            const float area = (max.x - min.x) * (max.y - min.y);
            const int target = (int)fminf(140.f, fmaxf(28.f, area * 0.000042f * density));

            if (s_partsReady && s_partCount == target &&
                s_partAreaMin.x == min.x && s_partAreaMin.y == min.y &&
                s_partAreaMax.x == max.x && s_partAreaMax.y == max.y)
                return;

            s_partAreaMin = min;
            s_partAreaMax = max;
            s_partCount   = target;
            for (int i = 0; i < s_partCount; ++i)
                SpawnParticle(s_parts[i], min, max, mode, i, true);
            s_partsReady = true;
        }

        static void UpdateParticle(MenuParticle& p, ImVec2 min, ImVec2 max,
                                   float dt, float speed, int mode, int index)
        {
            const float t = (float)ImGui::GetTime();
            p.x += p.vx * dt * speed;
            p.y += p.vy * dt * speed;

            if (p.kind == PKind::Bubble)
                p.x += sinf(t * 1.6f + p.phase) * 11.f * dt;
            else if (p.kind == PKind::Snow)
                p.x += sinf(t * 0.85f + p.phase) * 15.f * dt;

            bool respawn = false;
            if (p.kind == PKind::Bubble)
                respawn = (p.y < min.y - 16.f || p.x < min.x - 24.f || p.x > max.x + 24.f);
            else
                respawn = (p.y > max.y + 16.f || p.x < min.x - 24.f || p.x > max.x + 24.f);

            if (respawn)
                SpawnParticle(p, min, max, mode, index + (int)(t * 1000.f), false);
        }

        static void DrawOneParticle(ImDrawList* dl, const MenuParticle& p,
                                    ImVec2 areaMin, ImVec2 areaMax)
        {
            if (!PointInRoundRect({ p.x, p.y }, areaMin, areaMax, CornerRadius))
                return;

            const ImU32 col = IM_COL32(255, 255, 255, (int)(p.alpha * 255.f));
            switch (p.kind)
            {
            case PKind::Rain:
            {
                const float len = 7.f + p.size * 5.f;
                dl->AddLine({ p.x, p.y },
                            { p.x + p.vx * 0.012f, p.y + len }, col, 1.f);
                break;
            }
            case PKind::Bubble:
                dl->AddCircle({ p.x, p.y }, p.size, col, 12, 1.f);
                dl->AddCircleFilled({ p.x - p.size * 0.28f, p.y - p.size * 0.28f },
                                      fmaxf(1.f, p.size * 0.24f),
                                      IM_COL32(255, 255, 255, (int)(p.alpha * 80.f)));
                break;
            case PKind::Snow:
            default:
                dl->AddCircleFilled({ p.x, p.y }, p.size, col);
                break;
            }
        }
    }

    void DrawMenuParticles(ImDrawList* dl, ImVec2 min, ImVec2 max)
    {
        if (!menuFx.ParticlesEnabled)
        {
            s_partsReady = false;
            return;
        }

        const float dt = ImGui::GetIO().DeltaTime;
        EnsureParticles(min, max, menuFx.ParticleMode, menuFx.ParticleDensity);

        for (int i = 0; i < s_partCount; ++i)
        {
            UpdateParticle(s_parts[i], min, max, dt, menuFx.ParticleSpeed, menuFx.ParticleMode, i);
            DrawOneParticle(dl, s_parts[i], min, max);
        }
    }

    void DrawWatermark(bool menuOpen)
    {
        if (menuOpen) return;

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const ImVec2 ds = ImGui::GetIO().DisplaySize;

        const float pad = 10.f;
        const float markR = 10.f;
        const char* line1 = BrandName;
        const char* line2 = "INSERT";

        const ImVec2 ts1 = ImGui::CalcTextSize(line1);
        const ImVec2 ts2 = ImGui::CalcTextSize(line2);
        const float w = fmaxf(ts1.x, ts2.x) + pad * 2.f + markR * 2.f + 8.f;
        const float h = fmaxf(ts1.y + ts2.y + 6.f, markR * 2.f) + pad * 2.f;
        const ImVec2 min = { ds.x - w - 14.f, 14.f };
        const ImVec2 max = { min.x + w, min.y + h };

        dl->AddRectFilled(min, max, ToU32(palette.glassDeep), CornerRadius);
        dl->AddRect(min, max, ToU32(palette.borderHi), CornerRadius, 0, 1.f);
        dl->AddLine({ min.x + 1.f, min.y + 1.f }, { max.x - 1.f, min.y + 1.f }, ToU32(palette.lineSoft), 1.f);
        dl->AddLine({ min.x, min.y }, { max.x, min.y }, ToU32(palette.accentLine), 1.f);
        DrawBrandMark(dl, { min.x + pad + markR, min.y + h * 0.5f }, markR - 2.f);
        dl->AddText({ min.x + pad + markR * 2.f + 6.f, min.y + pad + 1.f }, ToU32(palette.accentHi), line1);
        dl->AddText({ min.x + pad + markR * 2.f + 6.f, min.y + pad + ts1.y + 3.f }, ToU32(palette.textDim), line2);
    }
}
