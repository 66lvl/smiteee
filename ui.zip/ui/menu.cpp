#include "../features/world_environment.h"
#include "../features/auto_laugh.h"
#include "../features/nox_quick_exit.h"
#include "../features/death_camera.h"
#include "../features/status_overlay.h"
#include "menu.h"
#include "theme.h"
#include "../core/performance.h"
#include "../imgui/imgui.h"
#include "../features/esp.h"
#include "../features/aimbot.h"
#include "../features/maphack.h"
#include "../features/config.h"
#include "../features/auto_dagger.h"
#include "../features/auto_pick.h"
#include "../features/skin_changer.h"
#include "../features/camera.h"
#include "../features/cooldown_window.h"
#include "../core/game_state.h"
#include "../core/gamepad_input.h"
#include "../core/sdk_helpers.h"
#include <Windows.h>
#include <cstdio>
#include <cmath>

namespace Menu
{
    bool IsOpen = false;

    enum class Page : int
    {
        Visuals = 0,
        CooldownHub,
        Combat,
        Radar,
        Skins,
        Settings,
        Camera,
        Automation
    };

    static Page s_page = Page::Visuals;
    static int s_section[8] = {};
    static bool s_fitMenu = false;
    static bool s_resetRequested = false;
    static bool s_resetAcknowledged = false;
    static Config::ResetTarget s_resetTarget = Config::ResetTarget::All;
    static const char* s_resetName = "All supported settings";
    static float S(float v) { return UITheme::Px(v); }

    static const char* s_configNotice = nullptr;
    static bool s_configNoticeOk = false;
    static double s_configNoticeUntil = 0.0;

    static void NotifyConfig(bool saving)
    {
        s_configNoticeOk = saving ? Config::Save() : Config::Load();
        s_configNotice = s_configNoticeOk
            ? (saving ? "Config saved" : "Config loaded")
            : (saving ? "Save failed - check file access" : "Load failed - check config file");
        s_configNoticeUntil = ImGui::GetTime() + 4.0;
    }


    bool WantsInput()
    {
        return IsOpen;
    }

    static void ClearInputOnMenuClose()
    {
        ImGuiIO& io = ImGui::GetIO();
        io.ClearInputMouse();
        io.ClearInputKeys();
        ImGui::SetNextFrameWantCaptureMouse(false);
        ImGui::SetNextFrameWantCaptureKeyboard(false);
        if (GetCapture() != nullptr)
            ReleaseCapture();
    }

    static void ApplyMenuInputMode()
    {
        ClipCursor(nullptr);
        if (GetCapture() != nullptr)
            ReleaseCapture();
    }

    static void CheckToggle()
    {
        static bool wasDown = false;
        bool isDown = ((GetAsyncKeyState(VK_INSERT) & 0x8000) != 0) ||
                      ((GetAsyncKeyState(VK_DELETE) & 0x8000) != 0) ||
                      ((GetAsyncKeyState(VK_HOME) & 0x8000) != 0);
        if (isDown && !wasDown)
        {
            IsOpen = !IsOpen;
            if (IsOpen)
                ApplyMenuInputMode();
            else
                ClearInputOnMenuClose();
        }
        wasDown = isDown;
    }

    static UITheme::Icon PageIcon(Page p)
    {
        switch (p)
        {
        case Page::Visuals:  return UITheme::Icon::Visuals;
        case Page::CooldownHub: return UITheme::Icon::Layers;
        case Page::Combat:   return UITheme::Icon::Combat;
        case Page::Radar:    return UITheme::Icon::MapHack;
        case Page::Skins:    return UITheme::Icon::Skins;
        case Page::Settings: return UITheme::Icon::Settings;
        default:             return UITheme::Icon::Info;
        }
    }

    static const char* PageTitle(Page p)
    {
        switch (p)
        {
        case Page::Visuals:  return "Visuals";
        case Page::CooldownHub: return "Cooldown Hub";
        case Page::Combat:   return "Combat";
        case Page::Radar:    return "Map";
        case Page::Skins:    return "Skins";
        case Page::Settings: return "Settings";
        default: return "";
        }
    }

    // Static previews use only ImDrawList primitives. No SDK queries, meshes or asset loading.
    static void DrawPreview(bool combat)
    {
        UITheme::BeginCard(combat?"aim_preview":"esp_preview",UITheme::Icon::Visuals,
                           combat?"Targeting preview":"Overlay preview",nullptr,334.f);
        const ImVec2 p=ImGui::GetCursorScreenPos();
        const float w=ImGui::GetContentRegionAvail().x,h=S(246.f);
        auto* dl=ImGui::GetWindowDrawList();
        const ImU32 grid=IM_COL32(35,46,60,90),ink=UITheme::ToU32(UITheme::palette.textDim);
        const ImU32 accent=UITheme::ToU32(UITheme::palette.accent);
        if(UITheme::fontSmall)ImGui::PushFont(UITheme::fontSmall);
        dl->AddText({p.x+w-ImGui::CalcTextSize("Static").x,p.y-S(34.f)},ink,"Static");
        if(UITheme::fontSmall)ImGui::PopFont();
        dl->AddRectFilled(p,{p.x+w,p.y+h},IM_COL32(17,25,34,255),S(6.f));
        dl->AddRect(p,{p.x+w,p.y+h},UITheme::ToU32(UITheme::palette.borderHi),S(6.f));
        for(float x=S(22.f);x<w;x+=S(22.f))dl->AddLine({p.x+x,p.y+S(1.f)},{p.x+x,p.y+h-S(1.f)},grid);
        for(float y=S(22.f);y<h;y+=S(22.f))dl->AddLine({p.x+S(1.f),p.y+y},{p.x+w-S(1.f),p.y+y},grid);
        const ImVec2 c={p.x+w*.5f,p.y+h*.5f};
        if(combat){
            const float r=fminf(w*.37f,S(83.f));
            dl->AddCircle(c,r,accent,64,S(1.f));dl->AddCircle(c,r*.62f,grid,48);
            dl->AddLine({c.x-S(12.f),c.y},{c.x+S(12.f),c.y},ink,S(1.f));
            dl->AddLine({c.x,c.y-S(12.f)},{c.x,c.y+S(12.f)},ink,S(1.f));
            const ImVec2 t={c.x+r*.5f,c.y-r*.4f};dl->AddCircle(t,S(9.f),accent,24,S(1.5f));
        }else{
            const float top=p.y+S(46.f),bottom=p.y+S(201.f),half=fminf(w*.22f,S(60.f));
            for(int x=0;x<2;x++)for(int y=0;y<2;y++){
                const ImVec2 q={c.x+(x?half:-half),y?bottom:top};
                dl->AddLine(q,{q.x+(x?-S(15.f):S(15.f)),q.y},accent,S(2.f));
                dl->AddLine(q,{q.x,q.y+(y?-S(12.f):S(12.f))},accent,S(2.f));
            }
            dl->AddLine({c.x-half-S(9.f),top},{c.x-half-S(9.f),bottom},UITheme::ToU32(UITheme::palette.success),S(3.f));
            const float head=p.y+S(72.f),neck=head+S(14.f),hip=p.y+S(144.f);
            dl->AddCircle({c.x,head},S(12.f),ink,28,S(1.8f));
            dl->AddLine({c.x,neck},{c.x,hip},ink,S(1.8f));
            dl->AddLine({c.x,p.y+S(104.f)},{c.x-S(30.f),p.y+S(130.f)},ink,S(1.8f));
            dl->AddLine({c.x,p.y+S(104.f)},{c.x+S(30.f),p.y+S(130.f)},ink,S(1.8f));
            dl->AddLine({c.x,hip},{c.x-S(22.f),p.y+S(182.f)},ink,S(1.8f));
            dl->AddLine({c.x,hip},{c.x+S(22.f),p.y+S(182.f)},ink,S(1.8f));
        }
        if(UITheme::fontSmall)ImGui::PushFont(UITheme::fontSmall);
        const char* label=combat?"Preview target":"Preview target";
        const float tw=ImGui::CalcTextSize(label).x;
        dl->AddText({c.x-tw*.5f,p.y+S(20.f)},UITheme::ToU32(UITheme::palette.text),label);
        const char* caption="Static layout preview";
        dl->AddText({c.x-ImGui::CalcTextSize(caption).x*.5f,p.y+h-S(30.f)},ink,caption);
        if(UITheme::fontSmall)ImGui::PopFont();
        ImGui::Dummy({w,h});UITheme::EndCard();
    }

    static void DrawThemeTiles()
    {
        UITheme::BeginCard("theme_studio",UITheme::Icon::Palette,"Theme studio");
        const char* names[]={"Midnight","Violet","Ocean","Graphite"};const int ids[]={4,1,0,3};
        const ImU32 accents[]={IM_COL32(169,194,242,255),IM_COL32(183,162,255,255),IM_COL32(115,173,243,255),IM_COL32(192,201,208,255)};
        const float avail=ImGui::GetContentRegionAvail().x;
        const int columns=avail>=S(720.f)?4:(avail>=S(360.f)?2:1);
        if(ImGui::BeginTable("theme_tiles",columns,ImGuiTableFlags_SizingStretchSame)){
            for(int i=0;i<4;i++){
                ImGui::TableNextColumn();ImGui::PushID(i);
                const float w=ImGui::GetContentRegionAvail().x,h=S(112.f);
                const ImVec2 p=ImGui::GetCursorScreenPos();const bool active=UITheme::appearance.Preset==ids[i];
                if(ImGui::InvisibleButton("##theme",{w,h},ImGuiButtonFlags_EnableNav))UITheme::ApplyAppearancePreset(ids[i]);
                auto* dl=ImGui::GetWindowDrawList();
                dl->AddRectFilled(p,{p.x+w,p.y+h},UITheme::ToU32(UITheme::palette.bgDeep),S(6.f));
                dl->AddRect(p,{p.x+w,p.y+h},active?accents[i]:UITheme::ToU32(UITheme::palette.border),S(6.f));
                dl->AddRectFilled({p.x+S(8.f),p.y+S(8.f)},{p.x+S(30.f),p.y+S(78.f)},IM_COL32(24,31,40,255),S(3.f));
                for(int j=0;j<4;j++)dl->AddLine({p.x+S(13.f),p.y+S(20.f+j*12.f)},{p.x+S(25.f),p.y+S(20.f+j*12.f)},j==1?accents[i]:IM_COL32(65,78,96,255),S(2.f));
                const float cw=(w-S(52.f))*.5f;
                for(int j=0;j<2;j++){
                    const float x=p.x+S(38.f)+j*(cw+S(6.f));
                    dl->AddRectFilled({x,p.y+S(24.f)},{x+cw,p.y+S(78.f)},IM_COL32(28,36,47,255),S(3.f));
                    dl->AddLine({x+S(6.f),p.y+S(38.f)},{x+cw-S(6.f),p.y+S(38.f)},IM_COL32(71,84,104,255),S(2.f));
                    dl->AddLine({x+S(6.f),p.y+S(56.f)},{x+cw*.7f,p.y+S(56.f)},accents[i],S(2.f));
                }
                dl->AddText({p.x+S(12.f),p.y+S(88.f)},UITheme::ToU32(UITheme::palette.text),names[i]);
                if(active)dl->AddCircleFilled({p.x+w-S(14.f),p.y+S(96.f)},S(3.f),accents[i]);
                if(ImGui::IsItemHovered())ImGui::SetTooltip("Apply %s (appearance colors only)",names[i]);
                ImGui::Dummy({0.f,S(5.f)});ImGui::PopID();
            }
            ImGui::EndTable();
        }
        UITheme::EndCard();
    }

    static void RequestReset(Config::ResetTarget target, const char* name)
    {
        s_resetTarget=target;s_resetName=name;s_resetAcknowledged=false;s_resetRequested=true;
    }
    static void ResetConfigButton()
    {
        if(UITheme::ActionButton("reset_all",UITheme::Icon::Reset,"Reset to defaults",UITheme::palette.textDim,{0.f,34.f}))
            RequestReset(Config::ResetTarget::All,"All supported settings");
    }
    static void DrawResetConfirmation()
    {
        if(s_resetRequested){ImGui::OpenPopup("Confirm reset##safe");s_resetRequested=false;}
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{S(18.f),S(18.f)});
        ImGui::PushStyleColor(ImGuiCol_WindowBg,{UITheme::palette.glassPanel.x,UITheme::palette.glassPanel.y,UITheme::palette.glassPanel.z,1.f});
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive,UITheme::palette.bgCardHi);
        ImGui::SetNextWindowSizeConstraints({0.f,0.f},{fmaxf(1.f,ImGui::GetIO().DisplaySize.x-20.f),fmaxf(1.f,ImGui::GetIO().DisplaySize.y-20.f)});
        if(ImGui::BeginPopupModal("Confirm reset##safe",nullptr,ImGuiWindowFlags_AlwaysAutoResize)){
            const bool all=s_resetTarget==Config::ResetTarget::All;
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX()+fminf(S(390.f),fmaxf(S(100.f),ImGui::GetIO().DisplaySize.x-S(60.f))));
            ImGui::TextWrapped("Reset: %s",s_resetName);ImGui::Separator();
            if(all)ImGui::TextWrapped("Resets Visuals, Cooldowns, Combat, Map, Environment, Camera, Automation, crosshair/HUD/death-camera settings and menu appearance to defaults. Applied skins and diagnostic recordings are not reset.");
            else ImGui::TextWrapped("Only this settings group will return to defaults. Other sections and menu appearance are kept.");
            ImGui::TextWrapped("The saved profile is NOT overwritten. To keep the reset, press Save separately. Load restores the saved profile.");
            ImGui::PopTextWrapPos();ImGui::Spacing();
            if(all)ImGui::Checkbox("I understand the reset scope",&s_resetAcknowledged);
            if(ImGui::Button("Cancel",{S(120.f),0.f})||ImGui::IsKeyPressed(ImGuiKey_Escape))ImGui::CloseCurrentPopup();
            ImGui::SetItemDefaultFocus();UITheme::SameLineIfRoom(190.f);
            ImGui::BeginDisabled(all&&!s_resetAcknowledged);
            if(ImGui::Button("Reset in memory",{S(190.f),0.f})){
                Config::ResetInMemory(s_resetTarget);
                s_configNotice="Reset applied - not saved";s_configNoticeOk=true;s_configNoticeUntil=ImGui::GetTime()+6.0;
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndDisabled();ImGui::EndPopup();
        }
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar();
    }
    static void DrawSectionReset()
    {
        Config::ResetTarget target=Config::ResetTarget::Visuals;const char* name=nullptr;
        switch(s_page){
        case Page::Visuals:target=s_section[0]==3?Config::ResetTarget::Camera:Config::ResetTarget::Visuals;name=s_section[0]==3?"Camera settings":"Visuals settings (all Visuals tabs except Camera)";break;
        case Page::CooldownHub:target=Config::ResetTarget::Cooldowns;name="Cooldown Hub settings (all tabs)";break;
        case Page::Combat:target=Config::ResetTarget::Combat;name="Combat settings (all tabs)";break;
        case Page::Radar:target=s_section[3]==1?Config::ResetTarget::Environment:Config::ResetTarget::Map;name=s_section[3]==1?"World / Environment (night look)":"Map filters";break;
        case Page::Settings:
            if(s_section[5]==1){target=Config::ResetTarget::Automation;name="Automation (Auto Dagger, Auto Pick and Auto Laugh)";}
            if(s_section[5]==3){target=Config::ResetTarget::Overlay;name="Overlay (crosshair, FPS, Ping, spectators and death camera)";}
            break;
        default:break;
        }
        if(!name)return;
        const ImVec2 p=ImGui::GetCursorScreenPos();
        if(ImGui::InvisibleButton("##reset_section",{S(26.f),S(30.f)},ImGuiButtonFlags_EnableNav))RequestReset(target,name);
        const ImVec4 old=UITheme::palette.accentHi;UITheme::palette.accentHi=UITheme::palette.textDim;
        UITheme::DrawIcon(ImGui::GetWindowDrawList(),UITheme::Icon::Reset,{p.x+S(13.f),p.y+S(15.f)},S(14.f));
        UITheme::palette.accentHi=old;
        UITheme::HelpLastItem("Reset this section","Opens a confirmation with the exact scope. Does not change the saved profile. Camera ownership is restored through the existing module when disabled.");
    }
    static void DrawComfortCard()
    {
        UITheme::BeginCard("menu_comfort",UITheme::Icon::Layers,"Interface comfort");
        if(ImGui::BeginTable("comfort_layout",ImGui::GetContentRegionAvail().x>=S(700.f)?2:1,ImGuiTableFlags_SizingStretchSame)){
            ImGui::TableNextColumn();
            float percent=UITheme::comfort.Scale*100.f;
            if(UITheme::SliderFloatRow("Menu scale",&percent,90.f,150.f,"%.0f %%"))UITheme::comfort.Scale=percent/100.f;
            if(UITheme::ActionButton("fit_menu",UITheme::Icon::Layers,"Fit menu to screen",UITheme::palette.accent,{210.f,34.f}))s_fitMenu=true;
            ImGui::TableNextColumn();
            UITheme::CheckboxRow("Show setting tooltips",&UITheme::comfort.Tooltips);
            UITheme::InfoText("Larger text by default: 16 px / hints 14 px at 100%. Cards stack automatically in narrower windows.");
            UITheme::InfoText("Ctrl+0: restore 100% and fit the menu. Drag the bottom-right corner to resize.");
            ImGui::EndTable();
        }
        UITheme::EndCard();
    }

    static void DrawProfileCard()
    {
        UITheme::BeginCard("local_profile",UITheme::Icon::Save,"Local configuration",nullptr,210.f);
        ImGui::TextUnformatted("Default profile");UITheme::InfoText("Stored on this computer. Save explicitly; END does not save unsaved changes.");
        ImGui::Dummy({0.f,10.f});
        if(UITheme::ActionButton("profile_save",UITheme::Icon::Save,"Save",UITheme::palette.accent,{90.f,32.f}))NotifyConfig(true);
        ImGui::SameLine();if(UITheme::ActionButton("profile_load",UITheme::Icon::Load,"Load",UITheme::palette.textDim,{90.f,32.f}))NotifyConfig(false);
        ResetConfigButton();UITheme::EndCard();
    }

    // Classic, two-column menu. Feature logic stays in its original modules.
    static void NavIcon(ImDrawList* dl, int i, ImVec2 c, float r, ImU32 col)
    {
        const float t=S(1.f); auto line=[&](float x,float y,float X,float Y){dl->AddLine({c.x+x*r,c.y+y*r},{c.x+X*r,c.y+Y*r},col,t);};
        auto circle=[&](float x,float y,float radius){dl->AddCircle({c.x+x*r,c.y+y*r},r*radius,col,32,t);};
        switch(i){
        case 0: circle(0,0,.70f);line(-1,0,-.45f,0);line(.45f,0,1,0);line(0,-1,0,-.45f);line(0,.45f,0,1);dl->AddCircleFilled(c,S(1.f),col);break;
        case 1: circle(0,0,.86f);circle(0,0,.45f);line(0,0,.64f,-.64f);dl->AddCircleFilled(c,S(1.2f),col);break;
        case 2: {ImVec2 p[]={{c.x-r,c.y},{c.x-r*.55f,c.y-r*.45f},{c.x,c.y-r*.62f},{c.x+r*.55f,c.y-r*.45f},{c.x+r,c.y},{c.x+r*.55f,c.y+r*.45f},{c.x,c.y+r*.62f},{c.x-r*.55f,c.y+r*.45f}};dl->AddPolyline(p,8,col,ImDrawFlags_Closed,t);circle(0,0,.28f);break;}
        case 3: dl->AddRect({c.x-r*.85f,c.y-r*.55f},{c.x+r*.4f,c.y+r*.55f},col,0,0,t);circle(-.25f,0,.20f);line(.4f,-.3f,.9f,-.55f);line(.9f,-.55f,.9f,.55f);line(.9f,.55f,.4f,.3f);break;
        case 4: circle(0,0,.62f);circle(0,0,.22f);for(int n=0;n<8;n++){float a=n*3.14159265f/4.f;line(cosf(a)*.62f,sinf(a)*.62f,cosf(a)*.95f,sinf(a)*.95f);}break;
        case 5: {ImVec2 p[]={{c.x-r*.45f,c.y-r*.8f},{c.x-r*.85f,c.y-r*.7f},{c.x-r,c.y-r*.4f},{c.x-r*.72f,c.y-r*.08f},{c.x-r*.46f,c.y-r*.20f},{c.x-r*.46f,c.y+r*.80f},{c.x+r*.46f,c.y+r*.80f},{c.x+r*.46f,c.y-r*.20f},{c.x+r*.72f,c.y-r*.08f},{c.x+r,c.y-r*.4f},{c.x+r*.85f,c.y-r*.7f},{c.x+r*.45f,c.y-r*.8f},{c.x+r*.22f,c.y-r*.52f},{c.x,c.y-r*.44f},{c.x-r*.22f,c.y-r*.52f}};dl->AddPolyline(p,15,col,ImDrawFlags_Closed,t);break;}
        case 6: circle(0,.12f,.72f);line(-.22f,-.92f,.22f,-.92f);line(0,-.92f,0,-.60f);line(.50f,-.63f,.67f,-.78f);line(0,-.35f,0,.12f);line(0,.12f,.28f,.30f);break;
        default: for(int n=0;n<3;n++){float y=-.55f+n*.55f;line(-.9f,y,.9f,y);float x=n==0?-.35f:n==1?.35f:-.15f;dl->AddRectFilled({c.x+(x-.08f)*r,c.y+(y-.18f)*r},{c.x+(x+.08f)*r,c.y+(y+.18f)*r},IM_COL32(11,11,11,255));dl->AddRect({c.x+(x-.08f)*r,c.y+(y-.18f)*r},{c.x+(x+.08f)*r,c.y+(y+.18f)*r},col,0,0,t);}break;
        }
    }
    static void DrawSidebar(float height)
    {
        const Page pages[]={Page::Combat,Page::Radar,Page::Visuals,Page::Camera,Page::Automation,Page::Skins,Page::CooldownHub,Page::Settings};
        const char* names[]={"Aimbot","Radar","Visuals","Camera","Automation","Skin changer","Cooldown Hub","Settings"};
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{S(4.f),S(10.f)});
        ImGui::BeginChild("##sidebar",{S(UITheme::SidebarWidth),height},ImGuiChildFlags_AlwaysUseWindowPadding,ImGuiWindowFlags_NoScrollbar);
        const float h=fmaxf(S(30.f),(ImGui::GetContentRegionAvail().y-ImGui::GetStyle().ItemSpacing.y*8.f)/8.f);
        for(int i=0;i<8;++i){
            ImGui::PushID(i);const ImVec2 p=ImGui::GetCursorScreenPos();const float w=ImGui::GetContentRegionAvail().x;
            if(ImGui::InvisibleButton("nav",{w,h},ImGuiButtonFlags_EnableNav))s_page=pages[i];
            const bool active=s_page==pages[i];auto* dl=ImGui::GetWindowDrawList();
            if(active){dl->AddRectFilled(p,{p.x+w,p.y+h},IM_COL32(17,17,17,255));dl->AddRect(p,{p.x+w,p.y+h},IM_COL32(40,40,40,255));}
            NavIcon(dl,i,{p.x+w*.5f,p.y+h*.5f},fminf(S(26.f),h*.33f),active?IM_COL32(195,195,195,255):IM_COL32(85,85,85,255));
            if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",names[i]);ImGui::PopID();
        }
        ImGui::EndChild();ImGui::PopStyleVar();
    }
    static void PanelStart(const char* id,const char* title,float height)
    {
        ImGui::PushID(id);ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{S(25.f),S(25.f)});
        ImGui::PushStyleColor(ImGuiCol_ChildBg,UITheme::palette.bgCard);
        ImGui::BeginChild("##panel",{0.f,height},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding,ImGuiWindowFlags_None);
        const ImVec2 pos=ImGui::GetWindowPos(), size=ImGui::GetWindowSize();
        ImDrawList* dl=ImGui::GetWindowDrawList();
        ImGui::PushClipRect(pos,{pos.x+size.x,pos.y+size.y},false);
        if(UITheme::fontHeading)ImGui::PushFont(UITheme::fontHeading);
        const ImVec2 text=ImGui::CalcTextSize(title);
        dl->AddRectFilled({pos.x+S(16.f),pos.y},{pos.x+S(24.f)+text.x,pos.y+text.y},UITheme::ToU32(UITheme::palette.bgCard));
        dl->AddText({pos.x+S(20.f),pos.y},ImGui::GetColorU32(ImGuiCol_Text),title);
        if(UITheme::fontHeading)ImGui::PopFont();
        ImGui::PopClipRect();
    }
    static void PanelEnd(){ImGui::EndChild();ImGui::PopStyleColor();ImGui::PopStyleVar();ImGui::PopID();}
    static void Bind(const char* label,const char* id,Aimbot::HoldBindType& type,int& key,int& device,int& button,int idx,bool optional)
    {
        static int types[3]={}; types[idx]=static_cast<int>(type);
        ImGui::PushID(id);ImGui::TextUnformatted(label);ImGui::SameLine();
        const float x=ImGui::GetCursorPosX()+fmaxf(0.f,ImGui::GetContentRegionAvail().x-S(85.f));ImGui::SetCursorPosX(x);
        UITheme::BindButton(id,&types[idx],&key,&device,&button,optional,80.f);type=static_cast<Aimbot::HoldBindType>(types[idx]);ImGui::PopID();
    }
    static void LeftColumn(float h)
    {
        switch(s_page){
        case Page::Combat: {
            PanelStart("combat_left","Aimbot",h);
            UITheme::CheckboxRow("Enabled",&Aimbot::cfg.Enabled);ImGui::Spacing();
            Bind("Hold to activate","aimbot_bind",Aimbot::cfg.HoldBind,Aimbot::cfg.HoldKey,Aimbot::cfg.HoldPadDevice,Aimbot::cfg.HoldPadButton,0,false);
            Bind("Toggle activation","aimbot_toggle_bind",Aimbot::cfg.ToggleBind,Aimbot::cfg.ToggleKey,Aimbot::cfg.TogglePadDevice,Aimbot::cfg.TogglePadButton,1,true);
            Bind("No prediction","aimbot_nopred_bind",Aimbot::cfg.NoPredBind,Aimbot::cfg.NoPredKey,Aimbot::cfg.NoPredPadDevice,Aimbot::cfg.NoPredPadButton,2,true);
            ImGui::Spacing();UITheme::CheckboxRow("Team check",&Aimbot::cfg.TeamCheck);UITheme::CheckboxRow("Hard lock",&Aimbot::cfg.HardLock);ImGui::Spacing();
            const char* modes[]={"Closest to crosshair","Lowest health"};int mode=(int)Aimbot::cfg.TargetPri;if(UITheme::ComboRow("Target selection",&mode,modes,2))Aimbot::cfg.TargetPri=static_cast<Aimbot::TargetMode>(mode);
            UITheme::SliderFloatRow("Field of view",&Aimbot::cfg.FovDeg,1.f,90.f,"%.0f deg");UITheme::SliderFloatRow("Smoothing",&Aimbot::cfg.Smoothing,1.f,20.f,"%.1f");
            if(Aimbot::IsToggleLatched())ImGui::TextUnformatted("AIM LATCHED");PanelEnd();break;}
        case Page::Visuals:{
            PanelStart("visual_left","Targets",h);UITheme::CheckboxRow("ESP enabled",&ESP::cfg.Enabled);ImGui::Spacing();
            UITheme::CheckboxRow("Enemy gods",&ESP::cfg.ShowEnemyGods);UITheme::CheckboxRow("Ally gods",&ESP::cfg.ShowAllyGods);UITheme::CheckboxRow("Minions",&ESP::cfg.ShowMinions);UITheme::CheckboxRow("Jungle camps",&ESP::cfg.ShowJungle);UITheme::CheckboxRow("Structures",&ESP::cfg.ShowStructures);UITheme::CheckboxRow("Wards",&ESP::cfg.ShowWards);ImGui::Spacing();
            UITheme::CheckboxRow("Enemy wards",&ESP::cfg.ShowEnemyWards);UITheme::CheckboxRow("Friendly wards",&ESP::cfg.ShowFriendlyWards);UITheme::CheckboxRow("Ward vision radius",&ESP::cfg.ShowWardRadius);ImGui::Spacing();UITheme::CheckboxRow("Visible check",&ESP::cfg.VisibleCheck);
            float meters=ESP::cfg.JungleMaxDistance*.01f;if(UITheme::SliderFloatRow("Camp range",&meters,20.f,800.f,"%.0f m"))ESP::cfg.JungleMaxDistance=meters*100.f;PanelEnd();break;}
        case Page::Radar:
            PanelStart("radar_left","Radar",h);UITheme::CheckboxRow("Enabled",&MapHack::cfg.Enabled);ImGui::Spacing();UITheme::CheckboxRow("Enemy gods",&MapHack::cfg.ShowEnemyGods);UITheme::CheckboxRow("Enemy wards",&MapHack::cfg.ShowEnemyWards);UITheme::CheckboxRow("Enemy familiars",&MapHack::cfg.ShowEnemyFamiliars);UITheme::CheckboxRow("Jungle camps",&MapHack::cfg.ShowJungle);PanelEnd();break;
        case Page::Camera:
            PanelStart("camera_left","Camera",h);UITheme::CheckboxRow("FOV changer",&Camera::cfg.EnableFov);UITheme::SliderFloatRow("Field of view",&Camera::cfg.FovValue,60.f,130.f,"%.0f");UITheme::CheckboxRow("Camera distance",&Camera::cfg.EnableDistance);UITheme::SliderFloatRow("Arm length",&Camera::cfg.DistanceValue,250.f,1200.f,"%.0f");UITheme::CheckboxRow("Disable arm collision",&Camera::cfg.NoArmCollision);ImGui::Spacing();DeathCamera::DrawSettings();PanelEnd();break;
        case Page::Automation:PanelStart("automation_left","Auto Pick",h);AutoPick::DrawSettings();PanelEnd();break;
        case Page::Skins:PanelStart("skins_left","Skin changer",h);SkinChanger::DrawMenu();PanelEnd();break;
        case Page::CooldownHub:
            PanelStart("cooldown_left","Cooldown Hub",h);UITheme::CheckboxRow("Enabled",&CooldownWindow::cfg.Enabled);ImGui::Spacing();UITheme::CheckboxRow("Show enemies",&CooldownWindow::cfg.ShowEnemies);UITheme::CheckboxRow("Show team",&CooldownWindow::cfg.ShowTeam);UITheme::CheckboxRow("Show self",&CooldownWindow::cfg.ShowSelf);UITheme::CheckboxRow("Split hubs",&CooldownWindow::cfg.SplitHubs);UITheme::CheckboxRow("Transparent background",&CooldownWindow::cfg.TransparentBackground);ImGui::Spacing();UITheme::CheckboxRow("Show god name",&CooldownWindow::cfg.ShowGodName);UITheme::CheckboxRow("Show distance",&CooldownWindow::cfg.ShowDistance);PanelEnd();break;
        case Page::Settings:{
            PanelStart("settings_left","Interface",h);UITheme::SliderFloatRow("Menu scale",&UITheme::comfort.Scale,.9f,1.5f,"%.2fx");UITheme::CheckboxRow("Show setting tooltips",&UITheme::comfort.Tooltips);
            UITheme::SliderFloatRow("Background opacity",&UITheme::appearance.Opacity,.65f,1.f,"%.2f");UITheme::SliderFloatRow("Corner radius",&UITheme::appearance.Rounding,0.f,32.f,"%.0f px");UITheme::SliderFloatRow("Border contrast",&UITheme::appearance.BorderStrength,.05f,.45f,"%.2f");
            if(ImGui::Button("Reset appearance..."))UITheme::RequestAppearanceReset();ImGui::Spacing();UITheme::CheckboxRow("Particles",&UITheme::menuFx.ParticlesEnabled);
            const char* effects[]={"Rain","Bubbles","Snow","Mixed"};UITheme::ComboRow("Particle style",&UITheme::menuFx.ParticleMode,effects,4);UITheme::SliderFloatRow("Density",&UITheme::menuFx.ParticleDensity,.35f,2.f,"%.1f");UITheme::SliderFloatRow("Speed",&UITheme::menuFx.ParticleSpeed,.5f,2.5f,"%.1f");
            if(ImGui::Button("Fit menu to screen"))s_fitMenu=true;PanelEnd();break;}
        }
    }
    static void RightColumn(float h)
    {
        switch(s_page){
        case Page::Combat:
            PanelStart("combat_right","Prediction",h);UITheme::SliderFloatRow("Range (meters)",&Aimbot::cfg.RangeMeters,5.f,120.f,"%.0f m");
            ImGui::BeginDisabled(Aimbot::cfg.UseRecommendedSpeed);UITheme::SliderFloatRow("Projectile speed",&Aimbot::cfg.ProjectileSpeed,500.f,5000.f,"%.0f cm/s");ImGui::EndDisabled();
            UITheme::SliderFloatRow("Lead scale",&Aimbot::cfg.LeadScale,.1f,5.f,"%.2f");UITheme::SliderFloatRow("Dynamic smooth",&Aimbot::cfg.DynamicSmoothScale,0.f,1.f,"%.2f");ImGui::Spacing();UITheme::CheckboxRow("Auto recommended speed",&Aimbot::cfg.UseRecommendedSpeed);UITheme::CheckboxRow("Show speed overlay",&Aimbot::cfg.ShowRecommendedSpeed);ImGui::Spacing();UITheme::CheckboxRow("FOV circle",&Aimbot::cfg.ShowFovCircle);UITheme::CheckboxRow("Impact marker",&Aimbot::cfg.ShowImpactOverlay);UITheme::CheckboxRow("Target info",&Aimbot::cfg.ShowTargetInfo);PanelEnd();break;
        case Page::Visuals:{
            PanelStart("visual_right","Display",h);UITheme::CheckboxRow("Box",&ESP::cfg.ShowBox);UITheme::CheckboxRow("Health bar",&ESP::cfg.ShowHealthBar);UITheme::CheckboxRow("Mana bar",&ESP::cfg.ShowManaBar);UITheme::CheckboxRow("Shield bar",&ESP::cfg.ShowShieldBar);UITheme::CheckboxRow("Name",&ESP::cfg.ShowName);UITheme::CheckboxRow("Distance",&ESP::cfg.ShowDistance);UITheme::CheckboxRow("Level",&ESP::cfg.ShowLevel);UITheme::CheckboxRow("Skeleton",&ESP::cfg.ShowSkeleton);UITheme::CheckboxRow("Snaplines",&ESP::cfg.ShowSnaplines);UITheme::CheckboxRow("CC indicator",&ESP::cfg.ShowCCIndicator);UITheme::CheckboxRow("Ability cooldowns",&ESP::cfg.ShowAbilityCooldowns);
            const char* modes[]={"Full box","Corner box","2D lines"};int mode=(int)ESP::cfg.BoxMode;if(UITheme::ComboRow("Box style",&mode,modes,3))ESP::cfg.BoxMode=static_cast<ESP::BoxStyle>(mode);
            UITheme::SliderFloatRow("Box thickness",&ESP::cfg.BoxThickness,.5f,5.f,"%.1f px");float meters=ESP::cfg.MaxDistance*.01f;if(UITheme::SliderFloatRow("Max distance",&meters,50.f,1000.f,"%.0f m"))ESP::cfg.MaxDistance=meters*100.f;
            UITheme::SliderFloatRow("Corner length",&ESP::cfg.CornerLength,3.f,30.f,"%.0f");if(ESP::cfg.ShowAbilityCooldowns)UITheme::SliderFloatRow("Cooldown ESP size",&ESP::cfg.AbilityCooldownScale,.5f,2.5f,"%.1fx");PanelEnd();break;}
        case Page::Radar:PanelStart("radar_right","World",h);WorldEnvironment::DrawSettings();PanelEnd();break;
        case Page::Camera:
            PanelStart("camera_right","ESP colors",h);UITheme::ColorEditRow("Enemy gods",ESP::cfg.EnemyColor);UITheme::ColorEditRow("Ally gods",ESP::cfg.AllyColor);UITheme::ColorEditRow("Minions",ESP::cfg.MinionColor);UITheme::ColorEditRow("Jungle",ESP::cfg.JungleColor);UITheme::ColorEditRow("Enemy wards",ESP::cfg.WardColor);UITheme::ColorEditRow("Friendly wards",ESP::cfg.FriendlyWardColor);UITheme::ColorEditRow("Structures",ESP::cfg.StructureColor);UITheme::ColorEditRow("Health bar",ESP::cfg.HealthColor);UITheme::ColorEditRow("Mana bar",ESP::cfg.ManaColor);UITheme::ColorEditRow("Shield bar",ESP::cfg.ShieldColor);UITheme::ColorEditRow("Skeleton",ESP::cfg.SkeletonColor);UITheme::ColorEditRow("Text",ESP::cfg.TextColor);PanelEnd();break;
        case Page::Automation:{
            PanelStart("automation_right","Auto Dagger",h);UITheme::CheckboxRow("Enabled",&AutoDagger::cfg.Enabled);ImGui::TextUnformatted("Health threshold");ImGui::TextUnformatted("499 HP");float retry=(float)AutoDagger::cfg.RetryIntervalMs;if(UITheme::SliderFloatRow("Retry interval",&retry,50.f,2000.f,"%.0f ms"))AutoDagger::cfg.RetryIntervalMs=(int)(retry+.5f);
            if(ImGui::Button("Print inventory"))AutoDagger::PrintInventory();ImGui::TextWrapped("Status: %s",AutoDagger::Status());ImGui::Spacing();AutoLaugh::DrawSettings();ImGui::Spacing();NoxQuickExit::DrawPanel();PanelEnd();break;}
        case Page::Skins:
            PanelStart("skins_right","Selected skin",h);ImGui::TextWrapped("Selection, Apply and status are provided by the skin module in the left panel.");ImGui::Spacing();ImGui::TextWrapped("An RPC message does not confirm server acceptance or a visible model change.");PanelEnd();break;
        case Page::CooldownHub:
            PanelStart("cooldown_right","Layout & slots",h);UITheme::CheckboxRow("Widget mode",&CooldownWindow::cfg.WidgetMode);UITheme::CheckboxRow("Vertical layout",&CooldownWindow::cfg.WidgetVerticalLayout);UITheme::SliderFloatRow("God name size",&CooldownWindow::cfg.WidgetGodNameSize,10.f,28.f,"%.0f px");UITheme::SliderFloatRow("Icon size",&CooldownWindow::cfg.HubTileSize,24.f,56.f,"%.0f px");ImGui::Spacing();UITheme::CheckboxRow("Ability 1",&CooldownWindow::cfg.ShowAbility1);UITheme::CheckboxRow("Ability 2",&CooldownWindow::cfg.ShowAbility2);UITheme::CheckboxRow("Ability 3",&CooldownWindow::cfg.ShowAbility3);UITheme::CheckboxRow("Ability 4",&CooldownWindow::cfg.ShowAbility4);UITheme::CheckboxRow("Relic",&CooldownWindow::cfg.ShowRelic);PanelEnd();break;
        case Page::Settings:{
            PanelStart("settings_right","Configuration",h);ImGui::TextUnformatted("Local configuration");if(ImGui::Button("Save"))NotifyConfig(true);ImGui::SameLine();if(ImGui::Button("Load"))NotifyConfig(false);if(ImGui::Button("Reset defaults..."))RequestReset(Config::ResetTarget::All,"All supported settings");
            if(s_configNotice&&ImGui::GetTime()<s_configNoticeUntil)ImGui::TextWrapped("%s",s_configNotice);
            ImGui::Spacing();UITheme::CheckboxRow("Performance diagnostics",&Performance::enabled);UITheme::CheckboxRow("Show timing overlay",&Performance::showOverlay);ImGui::Spacing();
            const char* themes[]={"Ocean","Violet","Emerald","Graphite","Classic"};int preset=UITheme::appearance.Preset;if(UITheme::ComboRow("Theme preset",&preset,themes,5))UITheme::ApplyAppearancePreset(preset);
            if(ImGui::Button("Apply classic colors")){UITheme::ApplyAppearancePreset(4);UITheme::appearance.Rounding=0.f;}
            UITheme::ColorEditRow("Accent",UITheme::appearance.Accent);UITheme::ColorEditRow("Background",UITheme::appearance.Background);UITheme::ColorEditRow("Cards",UITheme::appearance.Surface);UITheme::ColorEditRow("Sidebar",UITheme::appearance.Sidebar);UITheme::ColorEditRow("Text",UITheme::appearance.Text);
            ImGui::Spacing();StatusOverlay::DrawSettings();
            if(ImGui::CollapsingHeader("Reset individual section")){
                const char* sections[]={"Visuals","Cooldowns","Combat","Radar","Camera","Automation","Overlay","World"};
                const Config::ResetTarget targets[]={Config::ResetTarget::Visuals,Config::ResetTarget::Cooldowns,Config::ResetTarget::Combat,Config::ResetTarget::Map,Config::ResetTarget::Camera,Config::ResetTarget::Automation,Config::ResetTarget::Overlay,Config::ResetTarget::Environment};
                static int selected=0;UITheme::ComboRow("Section",&selected,sections,8);
                if(ImGui::Button("Reset selected section..."))RequestReset(targets[selected],sections[selected]);
            }
            PanelEnd();break;}
        }
    }
    static void DrawClassicContent(float height)
    {
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{S(20.f),S(20.f)});
        ImGui::BeginChild("##content_scroll",{0.f,height},ImGuiChildFlags_AlwaysUseWindowPadding,ImGuiWindowFlags_None);
        const float h=fmaxf(S(250.f),ImGui::GetContentRegionAvail().y-S(5.f));
        if(ImGui::BeginTable("classic_columns",2,ImGuiTableFlags_SizingStretchSame)){
            ImGui::TableNextColumn();LeftColumn(h);ImGui::TableNextColumn();RightColumn(h);ImGui::EndTable();
        }
        ImGui::EndChild();ImGui::PopStyleVar();
    }

    void Draw()
    {
        UITheme::RefreshAppearance();
        const bool openAtStart = IsOpen;
        CheckToggle();

        Performance::Measure(Performance::Part::Input, [&]() { GamepadInput::Tick(); });
        Performance::Measure(Performance::Part::State, [&]() { GameState::Tick(); });
        Performance::Measure(Performance::Part::AutoPick, [&]() { AutoPick::Service(); });

        if (CooldownWindow::cfg.Enabled)
            Performance::Measure(Performance::Part::Cooldowns, [&]() { CooldownWindow::Tick(); });

        if (GameState::IsPlayable())
        {
            Performance::Measure(Performance::Part::ESP, [&]() { ESP::Tick(); });
            Performance::Measure(Performance::Part::Aim, [&]() { Aimbot::Tick(); });
            Performance::Measure(Performance::Part::Map, [&]() { MapHack::Tick(); });
            Performance::Measure(Performance::Part::Camera, [&]() { Camera::Tick(); });
        }
        else
        {
            Aimbot::ResetState();
        }

        Performance::Measure(Performance::Part::Dagger, [&]() { AutoDagger::Tick(GameState::IsPlayable(), IsOpen); });

        Performance::Scope uiTiming(Performance::Part::UI);
        if (!IsOpen) Performance::DrawOverlay();
        AutoLaugh::Service(IsOpen || ImGui::GetIO().WantTextInput);
        NoxQuickExit::Service(IsOpen || ImGui::GetIO().WantTextInput || !GameState::IsPlayable());
        WorldEnvironment::Service();
        DeathCamera::Service();
        StatusOverlay::Service();
        StatusOverlay::Draw();
        UITheme::DrawWatermark(IsOpen);

        if (!IsOpen)
        {
            if (openAtStart)
                ClearInputOnMenuClose();
            return;
        }

        ApplyMenuInputMode();

        ImGuiIO& io = ImGui::GetIO();
        if(io.KeyCtrl&&!io.WantTextInput&&ImGui::IsKeyPressed(ImGuiKey_0)){UITheme::comfort.Scale=1.f;s_fitMenu=true;}
        UITheme::BeginMenuFrame();
        const ImVec2 maxSize={fmaxf(1.f,io.DisplaySize.x-20.f),fmaxf(1.f,io.DisplaySize.y-20.f)};
        const ImVec2 winSize={fminf(S(1100.f),maxSize.x),fminf(S(900.f),maxSize.y)};
        ImGui::SetNextWindowSizeConstraints({fminf(S(650.f),maxSize.x),fminf(S(500.f),maxSize.y)},maxSize);
        const ImGuiCond fit=s_fitMenu?ImGuiCond_Always:ImGuiCond_FirstUseEver;
        ImGui::SetNextWindowSize(winSize,fit);
        ImGui::SetNextWindowPos({(io.DisplaySize.x-winSize.x)*.5f,(io.DisplaySize.y-winSize.y)*.5f},fit);
        s_fitMenu=false;

        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0.f, 0.f });
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
        ImGui::Begin("##alwayslose_slate_studio", &IsOpen,
                     ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_NoScrollWithMouse);

        UITheme::PushRegular();

        ImVec2 wpos=ImGui::GetWindowPos();
        const ImVec2 clamped={fmaxf(0.f,fminf(wpos.x,io.DisplaySize.x-ImGui::GetWindowSize().x)),fmaxf(0.f,fminf(wpos.y,io.DisplaySize.y-ImGui::GetWindowSize().y))};
        if(clamped.x!=wpos.x||clamped.y!=wpos.y){ImGui::SetWindowPos(clamped);wpos=clamped;}
        const ImVec2 wsize = ImGui::GetWindowSize();
        ImDrawList* wdl = ImGui::GetWindowDrawList();
        const ImVec2 wmax = { wpos.x + wsize.x, wpos.y + wsize.y };

        // Menu-local style only. EndMenuFrame restores the caller's ImGui style.
        ImGuiStyle& classic=ImGui::GetStyle();
        const float radius=S(UITheme::appearance.Rounding);
        classic.WindowRounding=radius;classic.ChildRounding=fminf(radius,S(16.f));
        classic.FrameRounding=fminf(radius,S(6.f));classic.PopupRounding=fminf(radius,S(6.f));
        classic.WindowPadding={0.f,0.f};classic.FramePadding={S(5.f),S(3.f)};
        classic.ItemSpacing={S(8.f),S(5.f)};classic.CellPadding={S(8.f),0.f};
        classic.FrameBorderSize=1.f;classic.ChildBorderSize=1.f;
        classic.Colors[ImGuiCol_FrameBg]={.13f,.13f,.13f,1.f};
        classic.Colors[ImGuiCol_FrameBgHovered]={.18f,.18f,.18f,1.f};
        classic.Colors[ImGuiCol_FrameBgActive]={.22f,.22f,.22f,1.f};
        classic.Colors[ImGuiCol_Button]={.12f,.12f,.12f,1.f};
        classic.Colors[ImGuiCol_ButtonHovered]={.18f,.18f,.18f,1.f};
        classic.Colors[ImGuiCol_ButtonActive]={.23f,.23f,.23f,1.f};
        classic.Colors[ImGuiCol_Border]={.17f,.17f,.17f,1.f};
        wdl->AddRectFilled(wpos,wmax,UITheme::ToU32(UITheme::palette.bgDeep),radius);
        // Subtle woven lines, kept behind the solid panels and controls.
        for(float x=wpos.x+S(4.f);x<wmax.x-S(4.f);x+=S(4.f))
            wdl->AddLine({x,wpos.y+S(7.f)},{x,wmax.y-S(4.f)},IM_COL32(255,255,255,6));
        for(float y=wpos.y+S(7.f);y<wmax.y-S(4.f);y+=S(4.f))
            wdl->AddLine({wpos.x+S(4.f),y},{wmax.x-S(4.f),y},IM_COL32(0,0,0,18));
        wdl->AddRectFilled({wpos.x+S(4.f),wpos.y+S(5.f)},{wpos.x+S(UITheme::SidebarWidth),wmax.y-S(4.f)},UITheme::ToU32(UITheme::palette.bgSidebar));
        wdl->AddRect(wpos,wmax,IM_COL32(60,60,60,255),radius);
        const float left=wpos.x+S(5.f),right=wmax.x-S(5.f),top=wpos.y+S(5.f),mid=(left+right)*.5f;
        wdl->AddRectFilledMultiColor({left,top},{mid,top+S(2.f)},IM_COL32(151,46,211,255),IM_COL32(58,111,232,255),IM_COL32(58,111,232,255),IM_COL32(151,46,211,255));
        wdl->AddRectFilledMultiColor({mid,top},{right,top+S(2.f)},IM_COL32(58,111,232,255),IM_COL32(44,211,80,255),IM_COL32(44,211,80,255),IM_COL32(58,111,232,255));
        UITheme::PushMenuClip(wpos,wsize);
        UITheme::DrawMenuParticles(wdl,wpos,wmax);
        ImGui::SetCursorPos({0.f,S(8.f)}); const float bodyH=wsize.y-S(12.f);
        DrawSidebar(bodyH); ImGui::SameLine(0.f,0.f); DrawClassicContent(bodyH);

        DrawResetConfirmation();
        UITheme::DrawAppearanceResetConfirmation();
        UITheme::PopMenuClip();
        wdl->AddRect(wpos,wmax,IM_COL32(62,62,62,255),radius);

        UITheme::PopRegular();
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
        UITheme::EndMenuFrame();

        ImGui::SetNextFrameWantCaptureMouse(true);
        ImGui::SetNextFrameWantCaptureKeyboard(true);

        if (openAtStart && !IsOpen)
            ClearInputOnMenuClose();
    }
}
