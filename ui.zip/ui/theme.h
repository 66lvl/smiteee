#pragma once
#include "../imgui/imgui.h"
#include "../features/esp.h"

namespace UITheme
{
    inline constexpr float SidebarWidth = 120.f;
    inline float CornerRadius = 14.f;

    inline constexpr const char* BrandName     = "ALWAYSLOSE";
    inline constexpr const char* BrandSubtitle = "SMITE 2 INTERNAL";

    enum class Icon : int
    {
        Visuals,
        Combat,
        MapHack,
        Skins,
        Settings,
        Target,
        Spark,
        Layers,
        Palette,
        Bolt,
        Save,
        Load,
        Reset,
        Info,
        Keys
    };

    struct Palette
    {
        ImVec4 accent       = { .663f, .761f, .949f, 1.f };
        ImVec4 accentHi     = { .737f, .816f, .980f, 1.f };
        ImVec4 accentSoft   = { .663f, .761f, .949f, .14f };
        ImVec4 accentLine   = { .663f, .761f, .949f, .6f };
        ImVec4 glassDeep    = { .063f, .082f, .110f, 1.f };
        ImVec4 glassPanel   = { .063f, .082f, .110f, 1.f };
        ImVec4 glassCard    = { .094f, .122f, .157f, 1.f };
        ImVec4 glassSidebar = { .055f, .075f, .102f, 1.f };
        ImVec4 glassHover   = { .663f, .761f, .949f, .08f };
        ImVec4 lineHard     = { .184f, .235f, .298f, 1.f };
        ImVec4 lineSoft     = { .184f, .235f, .298f, .85f };
        ImVec4 bgDeep       = glassDeep;
        ImVec4 bgPanel      = glassPanel;
        ImVec4 bgCard       = glassCard;
        ImVec4 bgCardHi     = { .125f, .165f, .216f, 1.f };
        ImVec4 bgSidebar    = glassSidebar;
        ImVec4 border       = { .184f, .235f, .298f, 1.f };
        ImVec4 borderHi     = { .227f, .290f, .369f, 1.f };
        ImVec4 text         = { .910f, .925f, .949f, 1.f };
        ImVec4 textDim      = { .647f, .710f, .788f, 1.f };
        ImVec4 success      = { .478f, .788f, .682f, 1.f };
        ImVec4 danger       = { .949f, .475f, .510f, 1.f };
        ImVec4 warning      = { .910f, .745f, .482f, 1.f };
    };

    struct AppearanceSettings
    {
        int Preset = 4; // Ocean=0, Violet=1, Emerald=2, Graphite=3, Midnight=4 (stable IDs)
        ESP::Color4 Accent = { .608f, .776f, .145f, 1.f };
        ESP::Color4 Background = { .055f, .055f, .055f, 1.f };
        ESP::Color4 Surface = { .086f, .086f, .086f, 1.f };
        ESP::Color4 Sidebar = { .043f, .043f, .043f, 1.f };
        ESP::Color4 Text = { .80f, .80f, .80f, 1.f };
        float Opacity = 1.f;
        float Rounding = 0.f;
        float BorderStrength = 0.18f;
    };
    struct ComfortSettings
    {
        float Scale = 1.f; // Menu only, combined with monitor DPI. 90..150%.
        bool Tooltips = true;
    };
    extern ComfortSettings comfort;
    void SanitizeComfort();
    void BeginMenuFrame();
    void EndMenuFrame();
    float Px(float logicalPixels); // Uses the frozen scale of the current menu frame.
    void SameLineIfRoom(float nextLogicalWidth);
    void HelpLastItem(const char* label, const char* explanation = nullptr);
    void RequestAppearanceReset();
    void DrawAppearanceResetConfirmation();
    extern AppearanceSettings appearance;
    void ApplyAppearancePreset(int preset);
    void RefreshAppearance();
    void DrawAppearanceSettings();

    extern Palette palette;
    extern ImFont* fontRegular;
    extern ImFont* fontTitle;
    extern ImFont* fontHeading;
    extern ImFont* fontSmall;
    extern ImFont* fontBrand;

    void LoadFonts();
    void ApplyGlobalStyle();
    void SetDisplayScale(float scale);
    float DisplayScale();
    float UiScale();
    void PushRegular();
    void PopRegular();

    ImU32 ToU32(const ImVec4& c);
    ImVec4 IconColor(Icon icon);
    float AnimBool(const char* id, bool target, float speed = 14.f);

    void DrawBrandMark(ImDrawList* dl, ImVec2 center, float radius);
    void DrawIcon(ImDrawList* dl, Icon icon, ImVec2 center, float size);
    void DrawIconInline(Icon icon, float size = 15.f);

    struct MenuFxSettings
    {
        bool  ParticlesEnabled = false;
        int   ParticleMode     = 0; // 0 Rain, 1 Bubbles, 2 Snow, 3 Mixed
        float ParticleDensity  = 1.f;
        float ParticleSpeed    = 1.f;
    };

    extern MenuFxSettings menuFx;

    void GradientRect(ImDrawList* dl, ImVec2 min, ImVec2 max, const ImVec4& top, const ImVec4& bottom, float radius, ImDrawFlags corners = ImDrawFlags_RoundCornersAll);
    void DrawGlassRect(ImDrawList* dl, ImVec2 min, ImVec2 max,
                       const ImVec4& fill, bool accentTop = false, bool innerHighlight = true);
    void DrawWindowChrome(ImDrawList* dl, ImVec2 wpos, ImVec2 wsize, float sidebarW);
    void DrawMenuOutline(ImDrawList* dl, ImVec2 min, ImVec2 max);
    void PushMenuClip(ImVec2 wpos, ImVec2 wsize);
    void PopMenuClip();
    void DrawMenuParticles(ImDrawList* dl, ImVec2 min, ImVec2 max);

    bool NavButton(const char* id, Icon icon, const char* label, bool active);
    bool ToggleSwitch(const char* id, bool* value, float width = 32.f);
    void FeatureMaster(Icon icon, const char* title, const char* subtitle, bool* enabled = nullptr);

    void BeginCard(const char* id, Icon icon, const char* title, const char* subtitle = nullptr, float minHeight = 0.f);
    void EndCard();

    void InfoText(const char* text);
    void Badge(const char* text, const ImVec4& color, bool pulse = false);

    bool SliderFloatRow(const char* label, float* v, float min, float max, const char* fmt = "%.1f");
    bool ComboRow(const char* label, int* current, const char* const* items, int count);
    bool CheckboxRow(const char* label, bool* v);
    void ColorEditRow(const char* label, ESP::Color4& col);
    bool KeybindButton(const char* id, int* key);
    bool BindButton(const char* id, int* bindType, int* key, int* padDevice, int* padButton,
                    bool allowUnbound = false, float width = 0.f);

    bool ActionButton(const char* id, Icon icon, const char* label,
                      const ImVec4& color, ImVec2 size = { 0.f, 30.f });

    void DrawWatermark(bool menuOpen);
}
